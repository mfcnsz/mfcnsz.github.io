<?php
/**
 * SEOKILLER ACTION Utilities
 * 
 * @package SEOKILLER_ACTION
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Utilities class for the SEOKILLER ACTION plugin
 */
class SEOKILLER_Action_Utils {
    
    /**
     * Log file path
     */
    private static $log_file = null;
    
    /**
     * Initialize the logger
     */
    public static function init_logger() {
        try {
            if (is_null(self::$log_file)) {
                $upload_dir = wp_upload_dir();
                if (!isset($upload_dir['basedir']) || empty($upload_dir['basedir'])) {
                    return false;
                }
                
                $log_dir = trailingslashit($upload_dir['basedir']) . 'seokiller-action-logs';
                
                // Create logs directory if it doesn't exist
                if (!file_exists($log_dir)) {
                    if (!wp_mkdir_p($log_dir)) {
                        return false;
                    }
                    
                    // Create .htaccess file to protect logs
                    $htaccess_file = $log_dir . '/.htaccess';
                    if (!file_exists($htaccess_file)) {
                        $htaccess_content = "Order deny,allow\nDeny from all";
                        @file_put_contents($htaccess_file, $htaccess_content);
                    }
                    
                    // Create index.php file to prevent directory listing
                    $index_file = $log_dir . '/index.php';
                    if (!file_exists($index_file)) {
                        $index_content = "<?php\n// Silence is golden.";
                        @file_put_contents($index_file, $index_content);
                    }
                }
                
                // Set log file
                if (is_dir($log_dir) && is_writable($log_dir)) {
                    self::$log_file = $log_dir . '/seokiller-action-' . date('Y-m-d') . '.log';
                    return true;
                }
            } else {
                return true; // Log file already initialized
            }
        } catch (Exception $e) {
            error_log('SEOKILLER ACTION: Error initializing logger - ' . $e->getMessage());
            return false;
        }
        
        return false;
    }
    
    /**
     * Log message to file
     * 
     * @param string $message Message to log
     * @param string $level Log level (info, error, warning, debug)
     * @return bool Success or failure
     */
    public static function log($message, $level = 'info') {
        try {
            // Initialize logger if not already initialized
            if (!self::init_logger() || !self::$log_file) {
                return false;
            }
            
            // Format log message
            $log_entry = sprintf(
                "[%s] [%s] %s" . PHP_EOL,
                date('Y-m-d H:i:s'),
                strtoupper($level),
                $message
            );
            
            // Write to log file
            return (bool)@file_put_contents(self::$log_file, $log_entry, FILE_APPEND);
        } catch (Exception $e) {
            error_log('SEOKILLER ACTION: Error writing to log - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Log API request details
     * 
     * @param string $site_url Target site URL
     * @param string $endpoint API endpoint
     * @param string $method HTTP method
     * @param int $status HTTP status code
     * @param array $data Request data (optional)
     * @return bool Success or failure
     */
    public static function log_api_request($site_url, $endpoint, $method, $status, $data = null) {
        try {
            $message = sprintf(
                "%s request to %s/%s - Status: %s",
                $method,
                $site_url,
                $endpoint,
                $status
            );
            
            // Add data if available (but sanitize sensitive information)
            if (!is_null($data)) {
                // Clone data to avoid modifying the original
                $sanitized_data = json_decode(json_encode($data), true);
                
                // Sanitize sensitive fields if present
                if (isset($sanitized_data['secret_pass'])) {
                    $sanitized_data['secret_pass'] = '***REDACTED***';
                }
                if (isset($sanitized_data['password'])) {
                    $sanitized_data['password'] = '***REDACTED***';
                }
                
                $message .= " - Data: " . json_encode($sanitized_data);
            }
            
            // Log with appropriate level based on status code
            if ($status >= 200 && $status < 300) {
                return self::log($message, 'info');
            } elseif ($status >= 400 && $status < 500) {
                return self::log($message, 'warning');
            } elseif ($status >= 500) {
                return self::log($message, 'error');
            } else {
                return self::log($message, 'debug');
            }
        } catch (Exception $e) {
            error_log('SEOKILLER ACTION: Error logging API request - ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * Sanitize incoming request data
     * 
     * @param array $data Request data
     * @return array Sanitized data
     */
    public static function sanitize_request_data($data) {
        $sanitized = array();
        
        if (empty($data) || !is_array($data)) {
            return $sanitized;
        }
        
        foreach ($data as $key => $value) {
            // Process arrays recursively
            if (is_array($value)) {
                $sanitized[$key] = self::sanitize_request_data($value);
                continue;
            }
            
            // Sanitize based on key name
            switch ($key) {
                case 'site_url':
                    $sanitized[$key] = esc_url_raw($value);
                    break;
                    
                case 'secret_pass':
                    $sanitized[$key] = sanitize_text_field($value);
                    break;
                    
                case 'post_content':
                case 'product_description':
                    $sanitized[$key] = wp_kses_post($value);
                    break;
                    
                case 'post_title':
                case 'product_name':
                case 'category_name':
                    $sanitized[$key] = sanitize_text_field($value);
                    break;
                    
                case 'post_status':
                    $sanitized[$key] = in_array($value, array('publish', 'draft', 'pending', 'private')) ? $value : 'draft';
                    break;
                    
                case 'post_id':
                case 'product_id':
                case 'category_id':
                case 'author_id':
                    $sanitized[$key] = intval($value);
                    break;
                    
                case 'price':
                    $sanitized[$key] = floatval($value);
                    break;
                    
                default:
                    // For all other fields, use sanitize_text_field as a safe default
                    $sanitized[$key] = is_string($value) ? sanitize_text_field($value) : $value;
                    break;
            }
        }
        
        return $sanitized;
    }
    
    /**
     * Generate error response with OpenAI Actions compatibility
     * 
     * @param string $message Error message
     * @param int $status HTTP status code
     * @param string $code Error code (optional)
     * @return WP_Error Error object
     */
    public static function error_response($message, $status = 400, $code = 'seokiller_action_error') {
        $error_data = array('status' => $status);
        
        // Add detail field for OpenAI Actions compatibility
        if (isset($GLOBALS['seokiller_openai_request']) && $GLOBALS['seokiller_openai_request']) {
            $error_data['detail'] = $message;
            $error_data['openai_compatible'] = true;
            
            // Add specific error context for OpenAI
            switch ($status) {
                case 401:
                    $error_data['type'] = 'authentication_error';
                    $error_data['hint'] = 'Please check your X-SEOKILLER-API-KEY header';
                    break;
                case 400:
                    $error_data['type'] = 'invalid_request_error';
                    $error_data['hint'] = 'Please check your request parameters';
                    break;
                case 429:
                    $error_data['type'] = 'rate_limit_error';
                    $error_data['hint'] = 'Please wait before making another request';
                    break;
                case 500:
                    $error_data['type'] = 'api_error';
                    $error_data['hint'] = 'Internal server error occurred';
                    break;
            }
        }
        
        return new WP_Error($code, $message, $error_data);
    }
    
    /**
     * Format successful response with OpenAI Actions compatibility
     * 
     * @param mixed $data Response data
     * @param string $message Success message
     * @param array $meta Additional metadata
     * @return array Formatted response
     */
    public static function success_response($data, $message = 'Success', $meta = array()) {
        $response = array(
            'success' => true,
            'message' => $message,
            'data' => $data
        );
        
        // Add OpenAI-specific formatting if it's an OpenAI request
        if (isset($GLOBALS['seokiller_openai_request']) && $GLOBALS['seokiller_openai_request']) {
            $response['status'] = 'success';
            $response['openai_compatible'] = true;
            $response['timestamp'] = current_time('mysql');
            
            // Add metadata if provided
            if (!empty($meta)) {
                $response['meta'] = $meta;
            }
        }
        
        return $response;
    }
    
    /**
     * Create OpenAI-specific error response
     * 
     * @param string $message Error message
     * @param int $status HTTP status code
     * @param array $details Additional error details
     * @return WP_REST_Response
     */
    public static function openai_error_response($message, $status = 400, $details = array()) {
        $response_data = array(
            'error' => array(
                'message' => $message,
                'type' => $details['type'] ?? 'api_error',
                'code' => $details['code'] ?? 'seokiller_error'
            ),
            'detail' => $message,
            'status' => $status,
            'timestamp' => current_time('mysql'),
            'openai_compatible' => true
        );
        
        // Add additional details if provided
        if (!empty($details)) {
            $response_data['error'] = array_merge($response_data['error'], $details);
        }
        
        return new WP_REST_Response($response_data, $status);
    }
    
    /**
     * Create OpenAI-specific success response
     * 
     * @param mixed $data Response data
     * @param string $message Success message
     * @param array $meta Additional metadata
     * @return WP_REST_Response
     */
    public static function openai_success_response($data, $message = 'Success', $meta = array()) {
        $response_data = array(
            'status' => 'success',
            'message' => $message,
            'data' => $data,
            'timestamp' => current_time('mysql'),
            'openai_compatible' => true
        );
        
        // Add metadata if provided
        if (!empty($meta)) {
            $response_data['meta'] = $meta;
        }
        
        return new WP_REST_Response($response_data, 200);
    }
    
    /**
     * Check if the request exceeds rate limits
     * 
     * @param string $api_key API key used for the request
     * @return bool|WP_Error True if within rate limits, error object otherwise
     */
    public static function check_rate_limits($api_key) {
        if (empty($api_key)) {
            return self::error_response('Invalid API key', 401);
        }
        
        try {
            // Get current request counts
            $rate_limits = get_option('seokiller_action_rate_limits', array());
            $current_time = time();
            $ip_address = self::get_client_ip();
            
            // Initialize rate limits for this key if not already set
            if (!isset($rate_limits[$api_key])) {
                $rate_limits[$api_key] = array(
                    'minute' => array(
                        'count' => 0,
                        'reset' => $current_time + 60
                    ),
                    'hour' => array(
                        'count' => 0,
                        'reset' => $current_time + 3600
                    ),
                    'day' => array(
                        'count' => 0,
                        'reset' => $current_time + 86400
                    ),
                    'ip_addresses' => array($ip_address => true)
                );
            }
            
            // Check if rate limits need reset
            if ($current_time > $rate_limits[$api_key]['minute']['reset']) {
                $rate_limits[$api_key]['minute'] = array(
                    'count' => 0,
                    'reset' => $current_time + 60
                );
            }
            
            if ($current_time > $rate_limits[$api_key]['hour']['reset']) {
                $rate_limits[$api_key]['hour'] = array(
                    'count' => 0,
                    'reset' => $current_time + 3600
                );
            }
            
            if ($current_time > $rate_limits[$api_key]['day']['reset']) {
                $rate_limits[$api_key]['day'] = array(
                    'count' => 0,
                    'reset' => $current_time + 86400
                );
            }
            
            // Update IP address list
            $rate_limits[$api_key]['ip_addresses'][$ip_address] = true;
            
            // Check rate limits
            // Default limits: 60/minute, 300/hour, 1000/day
            $minute_limit = apply_filters('seokiller_action_rate_limit_minute', 60);
            $hour_limit = apply_filters('seokiller_action_rate_limit_hour', 300);
            $day_limit = apply_filters('seokiller_action_rate_limit_day', 1000);
            
            if ($rate_limits[$api_key]['minute']['count'] >= $minute_limit) {
                // Log rate limit exceeded
                self::log(
                    sprintf('Rate limit exceeded (minute) for API key: %s, IP: %s', substr($api_key, 0, 8) . '...', $ip_address),
                    'warning'
                );
                
                return self::error_response(
                    sprintf('Rate limit exceeded. Try again in %d seconds.', 
                        $rate_limits[$api_key]['minute']['reset'] - $current_time
                    ),
                    429
                );
            }
            
            if ($rate_limits[$api_key]['hour']['count'] >= $hour_limit) {
                // Log rate limit exceeded
                self::log(
                    sprintf('Rate limit exceeded (hour) for API key: %s, IP: %s', substr($api_key, 0, 8) . '...', $ip_address),
                    'warning'
                );
                
                return self::error_response(
                    sprintf('Rate limit exceeded. Try again in %d minutes.', 
                        ceil(($rate_limits[$api_key]['hour']['reset'] - $current_time) / 60)
                    ),
                    429
                );
            }
            
            if ($rate_limits[$api_key]['day']['count'] >= $day_limit) {
                // Log rate limit exceeded
                self::log(
                    sprintf('Rate limit exceeded (day) for API key: %s, IP: %s', substr($api_key, 0, 8) . '...', $ip_address),
                    'warning'
                );
                
                return self::error_response(
                    sprintf('Rate limit exceeded. Try again in %d hours.', 
                        ceil(($rate_limits[$api_key]['day']['reset'] - $current_time) / 3600)
                    ),
                    429
                );
            }
            
            // Increment request counts
            $rate_limits[$api_key]['minute']['count']++;
            $rate_limits[$api_key]['hour']['count']++;
            $rate_limits[$api_key]['day']['count']++;
            
            // Save updated rate limits
            update_option('seokiller_action_rate_limits', $rate_limits);
            
            return true;
        } catch (Exception $e) {
            self::log('Error checking rate limits: ' . $e->getMessage(), 'error');
            return true; // Default to allowing the request if there's an error checking limits
        }
    }
    
    /**
     * Get client IP address
     * 
     * @return string IP address
     */
    public static function get_client_ip() {
        // Check for proxy headers
        $headers = array(
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        );
        
        foreach ($headers as $header) {
            if (!isset($_SERVER[$header])) {
                continue;
            }
            
            // Extract IP from header
            $ips = explode(',', $_SERVER[$header]);
            $ip = trim($ips[0]);
            
            // Validate IP
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return $ip;
            }
        }
        
        // Default fallback
        return '0.0.0.0';
    }
} 