# JSON Test Endpoint Kullanımı

JSON test endpoint'i başarıyla eklendi. Bu endpoint JSON verisinin çözümlenip çözümlenmediğini test etmek için kullanılabilir.

## Test Komutu

```bash
curl -X POST https://your-site.com/wp-json/seokiller/v1/json-test \n  -H "Content-Type: application/json" \n  -d '{
    "title": "JSON Test",
    "content": "JSON Test içeriği",
    "site_auth": {
      "site_url": "https://appmysite.online",
      "secret_pass": "your_secret_pass_here"
    }
  }'
```

Bu komut, JSON verilerinin doğru çözümlenip çözümlenmediğini ve site_auth formatının doğru algılanıp algılanmadığını gösterecektir.

