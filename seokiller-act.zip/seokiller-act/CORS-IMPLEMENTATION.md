# SEOKILLER ACTION - CORS Implementation Guide

## Overview

The SEOKILLER ACTION plugin now includes comprehensive CORS (Cross-Origin Resource Sharing) support to allow OpenAI GPT Actions to access the API endpoints. This implementation supports both `https://chat.openai.com` and `https://chatgpt.com` domains.

## Features

- ✅ Support for both OpenAI domains (chat.openai.com and chatgpt.com)
- ✅ Handles OPTIONS preflight requests properly
- ✅ Configurable allowed origins via WordPress admin
- ✅ Early CORS header injection for better compatibility
- ✅ Compatible with WordPress REST API standards
- ✅ Does not interfere with existing authentication

## Implementation Details

### 1. Plugin-Level CORS (Recommended)

The plugin now includes built-in CORS handling with the following features:

#### Early CORS Headers
```php
add_action('init', 'seokiller_add_early_cors_headers', 1);
```
- Runs very early in WordPress lifecycle
- Only applies to `/wp-json/seokiller/v1/` endpoints
- Handles preflight OPTIONS requests
- Exits early for OPTIONS to prevent authentication checks

#### REST API CORS Headers
```php
add_filter('rest_pre_serve_request', 'seokiller_add_cors_headers', 10, 4);
```
- Adds CORS headers to REST API responses
- Only applies to SEOKILLER endpoints
- Maintains compatibility with other plugins

#### Configurable Origins
- Default origins: `https://chat.openai.com` and `https://chatgpt.com`
- Additional origins can be added via WordPress admin
- Go to: WordPress Admin → SEOKILLER ACTION → CORS Settings

### 2. Server-Level CORS (Alternative)

If the plugin-level CORS doesn't work due to server configuration, use these alternatives:

#### Apache (.htaccess)

Add to your WordPress root `.htaccess` file:

```apache
<IfModule mod_headers.c>
    SetEnvIf Request_URI "^/wp-json/seokiller/v1/" IS_SEOKILLER_API
    SetEnvIf Origin "^https://(chat\.openai\.com|chatgpt\.com)$" ALLOWED_ORIGIN=$0
    
    Header always set Access-Control-Allow-Origin "%{ALLOWED_ORIGIN}e" env=ALLOWED_ORIGIN
    Header always set Access-Control-Allow-Methods "GET, POST, OPTIONS" env=IS_SEOKILLER_API
    Header always set Access-Control-Allow-Headers "Content-Type, X-SEOKILLER-API-KEY, Authorization" env=IS_SEOKILLER_API
    Header always set Access-Control-Allow-Credentials "true" env=IS_SEOKILLER_API
    Header always set Access-Control-Max-Age "86400" env=IS_SEOKILLER_API
    
    RewriteEngine On
    RewriteCond %{REQUEST_METHOD} OPTIONS
    RewriteCond %{REQUEST_URI} ^/wp-json/seokiller/v1/
    RewriteRule ^(.*)$ $1 [R=204,L]
</IfModule>
```

#### Nginx

Add to your server block:

```nginx
map $http_origin $cors_origin {
    default "";
    "https://chat.openai.com" $http_origin;
    "https://chatgpt.com" $http_origin;
}

location ~ ^/wp-json/seokiller/v1/ {
    if ($cors_origin != "") {
        add_header 'Access-Control-Allow-Origin' $cors_origin always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'Content-Type, X-SEOKILLER-API-KEY, Authorization' always;
        add_header 'Access-Control-Allow-Credentials' 'true' always;
        add_header 'Access-Control-Max-Age' '86400' always;
    }
    
    if ($request_method = 'OPTIONS') {
        add_header 'Access-Control-Allow-Origin' $cors_origin always;
        add_header 'Access-Control-Allow-Methods' 'GET, POST, OPTIONS' always;
        add_header 'Access-Control-Allow-Headers' 'Content-Type, X-SEOKILLER-API-KEY, Authorization' always;
        add_header 'Access-Control-Allow-Credentials' 'true' always;
        add_header 'Access-Control-Max-Age' '86400' always;
        add_header 'Content-Type' 'text/plain charset=UTF-8';
        add_header 'Content-Length' '0';
        return 204;
    }
    
    try_files $uri $uri/ /index.php?$args;
}
```

## Testing CORS

### 1. Browser Console Test

```javascript
fetch('https://api.seokiller.net/wp-json/seokiller/v1/debug', {
    method: 'GET',
    headers: {
        'Origin': 'https://chat.openai.com'
    }
})
.then(response => {
    console.log('CORS Headers:', response.headers.get('Access-Control-Allow-Origin'));
    return response.json();
})
.then(data => console.log('Response:', data))
.catch(error => console.error('Error:', error));
```

### 2. cURL Test

```bash
# Test preflight request
curl -X OPTIONS \
  -H "Origin: https://chat.openai.com" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: X-SEOKILLER-API-KEY, Content-Type" \
  -v https://api.seokiller.net/wp-json/seokiller/v1/get-site-info

# Test actual request
curl -X POST \
  -H "Origin: https://chat.openai.com" \
  -H "X-SEOKILLER-API-KEY: your-api-key" \
  -H "Content-Type: application/json" \
  -d '{"site_auth":{"site_url":"https://example.com","secret_pass":"secret"}}' \
  https://api.seokiller.net/wp-json/seokiller/v1/get-site-info
```

### 3. OpenAI Actions Test

Use the `/openai-test` endpoint to verify OpenAI compatibility:

```bash
curl -X GET \
  -H "Origin: https://chat.openai.com" \
  -H "User-Agent: ChatGPT/1.0" \
  https://api.seokiller.net/wp-json/seokiller/v1/openai-test
```

## Troubleshooting

### CORS Headers Not Appearing

1. **Check WordPress Debug Log**
   ```php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   ```

2. **Verify Plugin Order**
   - SEOKILLER ACTION should load before other plugins that might interfere
   - Check for conflicting CORS plugins

3. **Server Configuration**
   - Some hosts may strip headers
   - CloudFlare or other proxies may interfere
   - Try server-level configuration instead

### Preflight Requests Failing

1. **Ensure OPTIONS Method is Allowed**
   - Check server allows OPTIONS requests
   - Verify no authentication on OPTIONS

2. **Check Headers**
   - All requested headers must be in Access-Control-Allow-Headers
   - Case-sensitive header names

### Authentication Issues with CORS

1. **API Key in Header**
   - Use `X-SEOKILLER-API-KEY` header
   - Not in request body for CORS requests

2. **Credentials Flag**
   - `Access-Control-Allow-Credentials: true` is set
   - Client must send `credentials: 'include'`

## Security Considerations

1. **Origin Validation**
   - Only configured origins are allowed
   - No wildcard (*) origins for security

2. **Credential Handling**
   - API keys should be kept secure
   - Use HTTPS only

3. **Rate Limiting**
   - OpenAI requests get higher rate limits
   - Monitor for abuse

## Adding Custom Origins

1. Go to WordPress Admin → SEOKILLER ACTION
2. Find "CORS İzin Verilen Kaynaklar" section
3. Add one origin per line
4. Save settings

Example:
```
https://chat.openai.com
https://chatgpt.com
https://your-custom-domain.com
```

## Integration with OpenAI Actions

1. **Import the OpenAPI Schema**
   - URL: `https://api.seokiller.net/openai-schema.json`

2. **Configure Authentication**
   - Type: API Key
   - Header: X-SEOKILLER-API-KEY
   - Value: Your API key from admin panel

3. **Test Connection**
   - Use the debug endpoint first
   - Check browser network tab for CORS headers

## Support

For issues with CORS implementation:
1. Check the troubleshooting section above
2. Enable WordPress debug logging
3. Test with cURL commands
4. Contact support with debug information 