# Alternatif Endpoint'ler Dokümantasyonu

SEOKILLER ACTION eklentisi için tüm alternatif endpoint'leri bu dosyada bulabilirsiniz. Bu alternatif endpoint'ler, standart WordPress REST API endpoint'lerine göre daha güvenilir çalışmak üzere tasarlanmıştır. Özellikle OpenAI GPT ile entegrasyonlarda yaşanan parametre çözümleme sorunlarını gidermek için geliştirilmiştir.

## Alternatif Endpoint'lerin Özellikleri

1. Doğrudan ham JSON verisini (php://input) işler
2. API key doğrulaması direkt endpoint içinde yapılır
3. JSON çözümleme hatası olursa net bir hata mesajı döner
4. Her adımda ayrıntılı hatalar log dosyasına yazılır
5. Hem site_auth formatını hem de doğrudan parametre formatını destekler

## Kullanılabilir Alternatif Endpoint'ler

### 1. İçerik Oluşturma
```
/wp-json/seokiller/v1/create-content-alt
```

### 2. Kategorileri Alma
```
/wp-json/seokiller/v1/get-categories-alt
```

### 3. Yazarları Alma
```
/wp-json/seokiller/v1/get-authors-alt
```

### 4. Yazıları Listeleme
```
/wp-json/seokiller/v1/get-posts-alt
```

### 5. Belirli Bir Yazıyı Alma
```
/wp-json/seokiller/v1/get-post-alt/{postId}
```

### 6. Yazı Silme
```
/wp-json/seokiller/v1/delete-post-alt/{postId}
```

### 7. Site Bilgisi Alma
```
/wp-json/seokiller/v1/get-site-info-alt
```

### 8. WooCommerce Ürün Oluşturma
```
/wp-json/seokiller/v1/create-product-alt
```

### 9. WooCommerce Ürün Güncelleme
```
/wp-json/seokiller/v1/update-product-alt/{productId}
```

### 10. WooCommerce Ürünleri Listeleme
```
/wp-json/seokiller/v1/get-products-alt
```

## Kullanım Örnekleri

### İçerik Oluşturma

```bash
curl -X POST https://your-site.com/wp-json/seokiller/v1/create-content-alt \
  -H "Content-Type: application/json" \
  -H "X-SEOKILLER-API-KEY: c16460beaa1b454c089af9123727d9cc" \
  -d '{
    "title": "Test İçerik",
    "content": "Bu bir test içeriğidir.",
    "site_auth": {
      "site_url": "https://client-site.com",
      "secret_pass": "your_secret_pass_here"
    }
  }'
```

### Yazıları Listeleme

```bash
curl -X POST https://your-site.com/wp-json/seokiller/v1/get-posts-alt \
  -H "Content-Type: application/json" \
  -H "X-SEOKILLER-API-KEY: c16460beaa1b454c089af9123727d9cc" \
  -d '{
    "site_auth": {
      "site_url": "https://client-site.com",
      "secret_pass": "your_secret_pass_here"
    },
    "per_page": 10,
    "page": 1
  }'
```

### Belirli Bir Yazıyı Alma

```bash
curl -X POST https://your-site.com/wp-json/seokiller/v1/get-post-alt/123 \
  -H "Content-Type: application/json" \
  -H "X-SEOKILLER-API-KEY: c16460beaa1b454c089af9123727d9cc" \
  -d '{
    "site_auth": {
      "site_url": "https://client-site.com",
      "secret_pass": "your_secret_pass_here"
    }
  }'
```

## Parametre Formatları

Alternatif endpoint'ler iki farklı parametre formatını destekler:

### Format 1: Doğrudan parametreler
```json
{
  "site_url": "https://client-site.com",
  "secret_pass": "your_secret_pass_here",
  ... diğer parametreler ...
}
```

### Format 2: Nested site_auth
```json
{
  "site_auth": {
    "site_url": "https://client-site.com",
    "secret_pass": "your_secret_pass_here"
  },
  ... diğer parametreler ...
}
```

## Hata Ayıklama

Tüm alternatif endpoint'ler, WordPress debug.log dosyasında ayrıntılı günlük tutar. Prefix olarak endpoint adını kullanırlar:

```
GET_POSTS_ALT: Raw data: ...
GET_POSTS_ALT: site_auth format detected
GET_POSTS_ALT: Sending request to: ...
```

WP_DEBUG'ı etkinleştirmek için wp-config.php dosyasına şu satırları ekleyin:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
``` 