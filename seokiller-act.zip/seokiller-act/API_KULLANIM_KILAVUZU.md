# SEOKILLER ACTION API Kullanım Kılavuzu

## 📋 İçindekiler

1. [Genel Bakış](#genel-bakış)
2. [Kurulum ve Yapılandırma](#kurulum-ve-yapılandırma)
3. [API Kütüphanesi Kullanımı](#api-kütüphanesi-kullanımı)
4. [SEOKILLER WP Eklentisi Bağlantısı](#seokiller-wp-eklentisi-bağlantısı)
5. [OpenAI GPT Entegrasyonu](#openai-gpt-entegrasyonu)
6. [API Endpoint'leri](#api-endpointleri)
7. [Güvenlik ve İzinler](#güvenlik-ve-izinler)
8. [Hata Yönetimi](#hata-yönetimi)
9. [En İyi Uygulamalar](#en-i̇yi-uygulamalar)
10. [Örnekler](#örnekler)

---

## 🎯 Genel Bakış

SEOKILLER ACTION eklentisi, OpenAI GPT modelleri ile WordPress siteleri arasında güvenli bir köprü görevi görür. Bu eklenti:

- **WordPress merkezli sitede** kurulur (proxy server)
- **Client WordPress sitelerle** SEOKILLER WP eklentisi üzerinden iletişim kurar
- **OpenAI GPT'lerin** WordPress içerik yönetimi yapmasını sağlar
- **WooCommerce desteği** ile e-ticaret işlevleri sunar

### Mimari Yapı

```
OpenAI GPT ←→ SEOKILLER ACTION (Proxy) ←→ Client Site (SEOKILLER WP)
```

---

## ⚙️ Kurulum ve Yapılandırma

### 1. SEOKILLER ACTION Eklentisi Kurulumu

```bash
# WordPress sitesine plugin yükleme
1. WordPress Admin → Eklentiler → Yeni Ekle
2. seokiller-action.zip dosyasını yükle
3. Eklentiyi etkinleştir
```

### 2. API Key Konfigürasyonu

```php
// WordPress Admin'de yapılandırma
WordPress Admin → SEOKILLER ACTION → API Key Yönetimi
```

#### API Key Özellikleri:
- ✅ **Otomatik oluşturulur** plugin aktivasyonunda
- 🔄 **Yeniden oluşturulabilir** admin panelinden
- 🔒 **32 karakter** uzunluğunda güvenli key
- 📋 **Kopyalanabilir** tek tıkla

### 3. Client Site Hazırlığı

Client WordPress sitesinde **SEOKILLER WP eklentisi** kurulmalı:

```bash
1. SEOKILLER WP plugin'ini client sitesine kur
2. Secret password belirle
3. API endpoint'lerini etkinleştir
```

---

## 📚 API Kütüphanesi Kullanımı

### Temel API Çağrısı Formatı

```javascript
// Temel yapı
const response = await fetch('https://your-site.com/wp-json/seokiller/v1/{endpoint}', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-SEOKILLER-API-KEY': 'your_api_key_here'
  },
  body: JSON.stringify({
    // Authentication (İki format desteklenir)
    // Format 1: Direct
    site_url: 'https://client-site.com',
    secret_pass: 'client_secret_password',
    
    // Format 2: Nested (Önerilen)
    site_auth: {
      site_url: 'https://client-site.com',
      secret_pass: 'client_secret_password'
    },
    
    // Diğer parametreler...
  })
});
```

### Authentication Formatları

#### Format 1: Direct Parameters
```json
{
  "site_url": "https://example.com",
  "secret_pass": "your_secret_password",
  "title": "Blog Post Title",
  "content": "Post content here..."
}
```

#### Format 2: Nested site_auth (Önerilen)
```json
{
  "site_auth": {
    "site_url": "https://example.com",
    "secret_pass": "your_secret_password"
  },
  "title": "Blog Post Title",
  "content": "Post content here..."
}
```

### Python Örneği

```python
import requests
import json

class SEOKillerAPI:
    def __init__(self, base_url, api_key):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.headers = {
            'Content-Type': 'application/json',
            'X-SEOKILLER-API-KEY': api_key
        }
    
    def make_request(self, endpoint, data):
        url = f"{self.base_url}/wp-json/seokiller/v1/{endpoint}"
        response = requests.post(url, headers=self.headers, json=data)
        return response.json()
    
    def get_site_info(self, client_url, secret_pass):
        data = {
            "site_auth": {
                "site_url": client_url,
                "secret_pass": secret_pass
            }
        }
        return self.make_request('get-site-info', data)
    
    def create_content(self, client_url, secret_pass, title, content, **kwargs):
        data = {
            "site_auth": {
                "site_url": client_url,
                "secret_pass": secret_pass
            },
            "title": title,
            "content": content,
            **kwargs
        }
        return self.make_request('create-content', data)

# Kullanım
api = SEOKillerAPI(
    base_url='https://your-proxy-site.com',
    api_key='your_32_character_api_key'
)

# Site bilgilerini al
info = api.get_site_info(
    client_url='https://client-site.com',
    secret_pass='client_secret'
)
```

### JavaScript/Node.js Örneği

```javascript
class SEOKillerAPI {
    constructor(baseUrl, apiKey) {
        this.baseUrl = baseUrl.replace(/\/$/, '');
        this.apiKey = apiKey;
        this.headers = {
            'Content-Type': 'application/json',
            'X-SEOKILLER-API-KEY': apiKey
        };
    }
    
    async makeRequest(endpoint, data) {
        const response = await fetch(`${this.baseUrl}/wp-json/seokiller/v1/${endpoint}`, {
            method: 'POST',
            headers: this.headers,
            body: JSON.stringify(data)
        });
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }
        
        return await response.json();
    }
    
    async getSiteInfo(clientUrl, secretPass) {
        return await this.makeRequest('get-site-info', {
            site_auth: {
                site_url: clientUrl,
                secret_pass: secretPass
            }
        });
    }
    
    async createContent(clientUrl, secretPass, contentData) {
        return await this.makeRequest('create-content', {
            site_auth: {
                site_url: clientUrl,
                secret_pass: secretPass
            },
            ...contentData
        });
    }
}

// Kullanım
const api = new SEOKillerAPI(
    'https://your-proxy-site.com',
    'your_32_character_api_key'
);

// Örnek kullanım
(async () => {
    try {
        const result = await api.createContent(
            'https://client-site.com',
            'client_secret',
            {
                title: 'Yeni Blog Yazısı',
                content: '<p>Bu bir test yazısıdır.</p>',
                status: 'publish',
                categories: [1, 5],
                tags: ['seo', 'blog'],
                meta_title: 'SEO Başlığı',
                meta_description: 'SEO açıklaması'
            }
        );
        console.log('İçerik oluşturuldu:', result);
    } catch (error) {
        console.error('Hata:', error);
    }
})();
```

---

## 🔗 SEOKILLER WP Eklentisi Bağlantısı

### Client Site Konfigürasyonu

#### 1. SEOKILLER WP Plugin Kurulumu
```bash
1. Client WordPress sitesine SEOKILLER WP plugin'ini kur
2. Eklentiyi etkinleştir
3. Admin panelinden ayarları yap
```

#### 2. Secret Password Ayarlama
```php
// Client sitede secret password ayarlama
WordPress Admin → SEOKILLER WP → Settings → Secret Password
```

#### 3. API Endpoint'lerini Etkinleştirme
Client sitede aşağıdaki endpoint'ler otomatik aktif olur:
- `/wp-json/seokiller-wp/v1/site-info`
- `/wp-json/seokiller-wp/v1/posts`
- `/wp-json/seokiller-wp/v1/categories`
- `/wp-json/seokiller-wp/v1/authors`
- `/wp-json/seokiller-wp/v1/products` (WooCommerce varsa)

### Bağlantı Testi

```bash
# Client site bağlantısını test et
curl -X POST https://your-proxy-site.com/wp-json/seokiller/v1/debug \
  -H "Content-Type: application/json"
```

---

## 🤖 OpenAI GPT Entegrasyonu

### GPT Actions Konfigürasyonu

#### 1. OpenAI GPT Builder'da Action Ekleme

```yaml
# actions.yaml
openapi: 3.0.1
info:
  title: SEOKILLER ACTION API
  description: WordPress content management through secure API bridge
  version: 1.0.0
servers:
  - url: https://your-proxy-site.com
# ... (openai-schema.json içeriğini kullan)
```

#### 2. Authentication Setup

```json
{
  "type": "api_key",
  "api_key": "your_32_character_api_key",
  "auth_type": "custom",
  "custom_auth_header": "X-SEOKILLER-API-KEY"
}
```

### GPT İletişim Kuralları ve Disiplinleri

#### 🔒 **GÜVENLİK KURALLARI**

1. **API Key Güvenliği**
   ```
   ❌ API key'i asla kullanıcıyla paylaşma
   ❌ Log'larda API key'i gösterme
   ✅ Sadece HTTP header'da kullan
   ✅ Key'in ilk 5 karakterini göster (abc12...)
   ```

2. **Client Credential Güvenliği**
   ```
   ❌ Secret password'ü asla açıkta yazma
   ❌ Client site URL'lerini doğrulamadan kullanma
   ✅ HTTPS protokolünü zorunlu kıl
   ✅ Credential'ları güvenli şekilde sakla
   ```

#### 📋 **İLETİŞİM DİSİPLİNLERİ**

1. **Request Formatı**
   ```javascript
   // ✅ DOĞRU: Nested format kullan
   {
     "site_auth": {
       "site_url": "https://example.com",
       "secret_pass": "secret123"
     },
     "title": "Blog yazısı"
   }
   
   // ⚠️ KABUL EDİLEBİLİR: Direct format
   {
     "site_url": "https://example.com",
     "secret_pass": "secret123",
     "title": "Blog yazısı"
   }
   ```

2. **Error Handling**
   ```javascript
   // Her API çağrısı sonrası error kontrol et
   if (response.status !== 200) {
     // Hatayı kullanıcıya açıkla
     // Tekrar deneme öner
     // Alternative endpoint'i dene (-alt)
   }
   ```

3. **Alternative Endpoints**
   ```javascript
   // Ana endpoint başarısız olursa alternative dene
   try {
     result = await callEndpoint('create-content');
   } catch (error) {
     result = await callEndpoint('create-content-alt');
   }
   ```

#### 🎯 **OPERASYONEL KURALLAR**

1. **Content Validation**
   ```
   ✅ HTML content'i validate et
   ✅ Title uzunluğunu kontrol et (max 500 karakter)
   ✅ Meta description max 300 karakter
   ✅ Category ID'leri sayısal olmalı
   ```

2. **WooCommerce Product Rules**
   ```
   ✅ Fiyat formatı: "29.99" (string olarak)
   ✅ SKU max 100 karakter
   ✅ Stock quantity pozitif tamsayı
   ✅ Product type: simple|grouped|external|variable
   ```

3. **Rate Limiting Awareness**
   ```
   ⚠️ Dakikada max 60 request
   ⚠️ Saatte max 300 request
   ⚠️ Günde max 1000 request
   🔄 Rate limit aşımında bekle ve tekrar dene
   ```

#### 🗣️ **KULLANICI İLETİŞİMİ**

1. **Başarılı İşlemler**
   ```
   ✅ "İçerik başarıyla oluşturuldu"
   ✅ Post ID ve URL'yi paylaş
   ✅ Yapılan işlemi özetle
   ```

2. **Hata Durumları**
   ```
   ❌ Teknik detayları kullanıcıyla paylaşma
   ✅ Anlaşılır hata mesajları ver
   ✅ Çözüm önerileri sun
   ✅ Alternative yöntemler öner
   ```

3. **Progress Reporting**
   ```
   🔄 "Site bilgileri alınıyor..."
   🔄 "İçerik oluşturuluyor..."
   ✅ "İşlem tamamlandı!"
   ```

#### 📊 **PERFORMANS OPTİMİZASYONU**

1. **Batch Operations**
   ```javascript
   // ❌ Tek tek kategori al
   for (category in categories) {
     await getCategory(category.id);
   }
   
   // ✅ Toplu kategoriler al
   const allCategories = await getCategories();
   ```

2. **Caching Strategy**
   ```
   ✅ Site bilgilerini cache'le (5 dakika)
   ✅ Kategori listesini cache'le (1 saat)
   ✅ Author listesini cache'le (30 dakika)
   ```

3. **Connection Timeout**
   ```
   ⏱️ Timeout: 45 saniye
   🔄 Retry: 3 defa
   ⚡ Alternative endpoint dene
   ```

---

## 🌐 API Endpoint'leri

### Debug & Testing Endpoints

#### 1. **Debug Status Check**
```bash
GET /wp-json/seokiller/v1/debug
# Authentication: Gerekli değil
```

**Kullanım:**
```javascript
const status = await fetch('https://your-site.com/wp-json/seokiller/v1/debug');
```

#### 2. **Diagnostic Check**
```bash
POST /wp-json/seokiller/v1/diagnostic
# Authentication: API Key gerekli
```

**Kullanım:**
```javascript
const diagnostic = await api.makeRequest('diagnostic', {
  test_data: "any data for testing"
});
```

#### 3. **JSON Test**
```bash
POST /wp-json/seokiller/v1/json-test
# Authentication: API Key gerekli
```

### Site Management Endpoints

#### 1. **Get Site Info**
```bash
POST /wp-json/seokiller/v1/get-site-info
POST /wp-json/seokiller/v1/get-site-info-alt
```

**Örnek:**
```javascript
const siteInfo = await api.makeRequest('get-site-info', {
  site_auth: {
    site_url: 'https://client.com',
    secret_pass: 'secret123'
  }
});
```

### Content Management Endpoints

#### 1. **Get Categories**
```bash
POST /wp-json/seokiller/v1/get-categories
POST /wp-json/seokiller/v1/get-categories-alt
```

#### 2. **Get Authors**
```bash
POST /wp-json/seokiller/v1/get-authors
POST /wp-json/seokiller/v1/get-authors-alt
```

#### 3. **Get Posts**
```bash
POST /wp-json/seokiller/v1/get-posts
POST /wp-json/seokiller/v1/get-posts-alt
```

**Parameters:**
```javascript
{
  site_auth: { /* auth info */ },
  per_page: 10,        // 1-100 arası
  page: 1,             // Sayfa numarası
  category: 5,         // Kategori ID
  search: "arama",     // Arama terimi
  post_status: "publish", // publish|draft|pending|private|any
  author: 2,           // Yazar ID
  order: "DESC",       // ASC|DESC
  orderby: "date"      // date|title|modified|menu_order|rand
}
```

#### 4. **Get Single Post**
```bash
POST /wp-json/seokiller/v1/get-post/{postId}
POST /wp-json/seokiller/v1/get-post-alt/{postId}
```

#### 5. **Create Content**
```bash
POST /wp-json/seokiller/v1/create-content
POST /wp-json/seokiller/v1/create-content-alt
```

**Örnek:**
```javascript
const newPost = await api.makeRequest('create-content', {
  site_auth: { /* auth info */ },
  title: "Blog Yazı Başlığı",
  content: "<p>Blog yazı içeriği buraya gelir.</p>",
  excerpt: "Kısa özet",
  status: "publish",        // draft|publish|pending|future|private
  post_type: "post",        // post|page|custom_post_type
  categories: [1, 5, 8],    // Kategori ID'leri
  tags: ["seo", "blog"],    // Tag isimleri
  author: 1,                // Yazar ID
  featured_image: "https://example.com/image.jpg",
  
  // SEO Fields
  meta_title: "SEO Başlık (max 150 karakter)",
  meta_description: "SEO açıklama (max 300 karakter)",
  focus_keyword: "ana anahtar kelime",
  
  // Scheduling
  published_date: "2024-01-15T14:30:00Z", // ISO 8601
  
  // Custom Fields
  custom_fields: {
    custom_field_1: "değer1",
    custom_field_2: "değer2"
  }
});
```

#### 6. **Update Content**
```bash
POST /wp-json/seokiller/v1/update-content/{postId}
POST /wp-json/seokiller/v1/update-content-alt/{postId}
```

#### 7. **Delete Post**
```bash
POST /wp-json/seokiller/v1/delete-post/{postId}
POST /wp-json/seokiller/v1/delete-post-alt/{postId}
```

**Parameters:**
```javascript
{
  site_auth: { /* auth info */ },
  force: false  // true = kalıcı sil, false = çöp kutusuna gönder
}
```

### WooCommerce Endpoints

#### 1. **Get Products**
```bash
POST /wp-json/seokiller/v1/get-products
POST /wp-json/seokiller/v1/get-products-alt
```

**Parameters:**
```javascript
{
  site_auth: { /* auth info */ },
  per_page: 10,
  page: 1,
  category_id: 5,      // Ürün kategori ID
  search: "ürün adı",
  status: "publish",   // publish|draft|pending|private
  stock_status: "instock", // instock|outofstock|onbackorder
  type: "simple"       // simple|grouped|external|variable
}
```

#### 2. **Get Single Product**
```bash
POST /wp-json/seokiller/v1/get-product/{productId}
```

#### 3. **Create Product**
```bash
POST /wp-json/seokiller/v1/create-product
POST /wp-json/seokiller/v1/create-product-alt
```

**Örnek:**
```javascript
const newProduct = await api.makeRequest('create-product', {
  site_auth: { /* auth info */ },
  name: "Ürün Adı",
  description: "<p>Ürün açıklaması</p>",
  short_description: "Kısa açıklama",
  type: "simple",              // simple|grouped|external|variable
  status: "publish",           // draft|publish|pending|private
  regular_price: "29.99",      // String formatında
  sale_price: "19.99",         // String formatında
  sku: "PRODUCT-001",          // Max 100 karakter
  
  // Stock Management
  manage_stock: true,
  stock_quantity: 100,
  stock_status: "instock",     // instock|outofstock|onbackorder
  
  // Physical Properties
  weight: "1.5",
  dimensions: {
    length: "10",
    width: "5",
    height: "3"
  },
  
  // Taxonomies
  category_ids: [1, 5],        // Kategori ID'leri
  tag_ids: [2, 7],            // Tag ID'leri
  
  // Images
  images: [
    {
      src: "https://example.com/image1.jpg",
      alt: "Ürün resmi 1",
      position: 0
    },
    {
      src: "https://example.com/image2.jpg",
      alt: "Ürün resmi 2", 
      position: 1
    }
  ],
  
  // Attributes (Variable products için)
  attributes: [
    {
      name: "Renk",
      options: ["Kırmızı", "Mavi", "Yeşil"],
      visible: true,
      variation: true
    },
    {
      name: "Beden",
      options: ["S", "M", "L", "XL"],
      visible: true,
      variation: true
    }
  ],
  
  // SEO
  meta_title: "Ürün SEO Başlığı",
  meta_description: "Ürün SEO açıklaması"
});
```

#### 4. **Update Product**
```bash
POST /wp-json/seokiller/v1/update-product/{productId}
POST /wp-json/seokiller/v1/update-product-alt/{productId}
```

#### 5. **Delete Product**
```bash
POST /wp-json/seokiller/v1/delete-product/{productId}
POST /wp-json/seokiller/v1/delete-product-alt/{productId}
```

---

## 🔒 Güvenlik ve İzinler

### API Key Güvenliği

```php
// API Key özellikleri
- 32 karakter uzunluğunda
- Alfanümerik karakterler
- Otomatik oluşturulur
- Admin panelinden yeniden oluşturulabilir
```

### Rate Limiting

```yaml
# Varsayılan limitler
Dakika: 60 request
Saat: 300 request
Gün: 1000 request

# Limit aşımında HTTP 429 döner
```

### İzin Kontrolü

```php
// WordPress Capabilities
manage_options: Admin paneli erişimi
edit_posts: İçerik düzenleme
edit_products: Ürün düzenleme (WooCommerce)
```

### Secret Password

```bash
# Client site için güvenlik
- Minimum 8 karakter
- İsteğe bağlı karmaşıklık kuralları
- SEOKILLER WP plugin'inde ayarlanır
```

---

## ⚠️ Hata Yönetimi

### HTTP Status Codes

```yaml
200: İşlem başarılı
400: Eksik veya hatalı parametreler
401: API key geçersiz veya eksik
403: İzin yok
404: Endpoint bulunamadı
429: Rate limit aşıldı
500: Sunucu hatası
```

### Error Response Format

```json
{
  "code": "api_key_missing",
  "message": "API key is missing",
  "data": {
    "status": 401,
    "params": ["site_url", "secret_pass"]
  }
}
```

### Common Errors

#### 1. **Authentication Errors**
```javascript
// API key eksik
{
  "code": "api_key_missing",
  "message": "API key is missing"
}

// API key geçersiz
{
  "code": "api_key_invalid", 
  "message": "Invalid API key"
}

// Client site kimlik bilgileri hatalı
{
  "code": "missing_required_params",
  "message": "Missing required parameter(s): site_url, secret_pass"
}
```

#### 2. **Connection Errors**
```javascript
// Client site bağlantı hatası
{
  "code": "wp_request_failed",
  "message": "Failed to connect to the WordPress site: Connection timeout"
}
```

#### 3. **Validation Errors**
```javascript
// Geçersiz post ID
{
  "code": "invalid_post_id",
  "message": "Invalid post ID"
}

// JSON format hatası
{
  "code": "invalid_json",
  "message": "Invalid JSON data"
}
```

### Error Handling Best Practices

```javascript
async function handleAPICall(endpoint, data) {
  try {
    const response = await api.makeRequest(endpoint, data);
    
    // Response status kontrolü
    if (response.status !== 200) {
      throw new Error(`API Error: ${response.status}`);
    }
    
    return response.body;
    
  } catch (error) {
    // Rate limit hatası
    if (error.status === 429) {
      console.log('Rate limit aşıldı, 60 saniye bekle...');
      await sleep(60000);
      return handleAPICall(endpoint, data); // Tekrar dene
    }
    
    // Alternative endpoint dene
    if (endpoint.includes('-alt')) {
      throw error; // Alt endpoint da başarısız
    }
    
    const altEndpoint = endpoint + '-alt';
    console.log(`Ana endpoint başarısız, alternative deneniyor: ${altEndpoint}`);
    return handleAPICall(altEndpoint, data);
  }
}
```

---

## 🏆 En İyi Uygulamalar

### 1. **Performance Optimization**

```javascript
// ✅ Batch operations kullan
const categories = await api.getCategories(); // Tek seferde al
const authors = await api.getAuthors();       // Tek seferde al

// ❌ Döngüde tek tek çağrı yapma
for (let i = 0; i < posts.length; i++) {
  const post = await api.getPost(posts[i].id); // Yavaş
}
```

### 2. **Caching Strategy**

```javascript
class SEOKillerAPIWithCache extends SEOKillerAPI {
  constructor(baseUrl, apiKey) {
    super(baseUrl, apiKey);
    this.cache = new Map();
    this.cacheTimeout = {
      'site-info': 5 * 60 * 1000,    // 5 dakika
      'categories': 60 * 60 * 1000,  // 1 saat
      'authors': 30 * 60 * 1000      // 30 dakika
    };
  }
  
  async getCachedData(key, fetcher, timeout) {
    const cached = this.cache.get(key);
    if (cached && Date.now() - cached.timestamp < timeout) {
      return cached.data;
    }
    
    const data = await fetcher();
    this.cache.set(key, {
      data,
      timestamp: Date.now()
    });
    
    return data;
  }
  
  async getSiteInfo(clientUrl, secretPass) {
    const cacheKey = `site-info-${clientUrl}`;
    return this.getCachedData(
      cacheKey,
      () => super.getSiteInfo(clientUrl, secretPass),
      this.cacheTimeout['site-info']
    );
  }
}
```

### 3. **Content Validation**

```javascript
function validateContent(contentData) {
  const errors = [];
  
  // Başlık kontrolü
  if (!contentData.title || contentData.title.length === 0) {
    errors.push('Title boş olamaz');
  }
  if (contentData.title && contentData.title.length > 500) {
    errors.push('Title max 500 karakter olabilir');
  }
  
  // İçerik kontrolü
  if (!contentData.content || contentData.content.length === 0) {
    errors.push('Content boş olamaz');
  }
  
  // SEO alanları kontrolü
  if (contentData.meta_title && contentData.meta_title.length > 150) {
    errors.push('Meta title max 150 karakter olabilir');
  }
  if (contentData.meta_description && contentData.meta_description.length > 300) {
    errors.push('Meta description max 300 karakter olabilir');
  }
  
  // Kategori kontrolü
  if (contentData.categories) {
    if (!Array.isArray(contentData.categories)) {
      errors.push('Categories array olmalı');
    } else {
      const invalidCats = contentData.categories.filter(cat => 
        !Number.isInteger(cat) || cat <= 0
      );
      if (invalidCats.length > 0) {
        errors.push('Category ID\'leri pozitif tamsayı olmalı');
      }
    }
  }
  
  return errors;
}

// Kullanım
const content = {
  title: 'Blog Yazısı',
  content: '<p>İçerik buraya</p>',
  categories: [1, 5]
};

const validationErrors = validateContent(content);
if (validationErrors.length > 0) {
  console.error('Validation hatası:', validationErrors);
  return;
}
```

### 4. **Progress Reporting**

```javascript
async function createContentWithProgress(clientUrl, secretPass, contentData) {
  try {
    console.log('🔄 Site bilgileri kontrol ediliyor...');
    await api.getSiteInfo(clientUrl, secretPass);
    
    console.log('📝 İçerik validate ediliyor...');
    const errors = validateContent(contentData);
    if (errors.length > 0) {
      throw new Error(`Validation hatası: ${errors.join(', ')}`);
    }
    
    console.log('⬆️ İçerik oluşturuluyor...');
    const result = await api.createContent(clientUrl, secretPass, contentData);
    
    if (result.status === 200 && result.body.success) {
      console.log('✅ İçerik başarıyla oluşturuldu!');
      console.log(`📄 Post ID: ${result.body.data.id}`);
      console.log(`🔗 URL: ${result.body.data.link}`);
      return result.body.data;
    } else {
      throw new Error(`İçerik oluşturulamadı: ${result.body.message}`);
    }
    
  } catch (error) {
    console.error('❌ Hata:', error.message);
    throw error;
  }
}
```

### 5. **WordPress Site Types Detection**

```javascript
async function detectSiteCapabilities(clientUrl, secretPass) {
  const siteInfo = await api.getSiteInfo(clientUrl, secretPass);
  const capabilities = {
    isWordPress: false,
    hasWooCommerce: false,
    hasYoastSEO: false,
    hasRankMath: false,
    wpVersion: null,
    activePlugins: []
  };
  
  if (siteInfo.status === 200 && siteInfo.body) {
    const data = siteInfo.body.data || siteInfo.body;
    
    capabilities.isWordPress = true;
    capabilities.wpVersion = data.wp_version;
    capabilities.activePlugins = data.active_plugins || [];
    
    // WooCommerce kontrolü
    capabilities.hasWooCommerce = capabilities.activePlugins.some(plugin => 
      plugin.includes('woocommerce')
    );
    
    // SEO plugin kontrolü
    capabilities.hasYoastSEO = capabilities.activePlugins.some(plugin => 
      plugin.includes('wordpress-seo')
    );
    capabilities.hasRankMath = capabilities.activePlugins.some(plugin => 
      plugin.includes('seo-by-rank-math')
    );
  }
  
  return capabilities;
}
```

---

## 💡 Örnekler

### Örnek 1: Blog Yazısı Oluşturma

```javascript
async function createBlogPost() {
  const api = new SEOKillerAPI(
    'https://your-proxy-site.com',
    'your_api_key_here'
  );
  
  try {
    // Site yeteneklerini kontrol et
    const capabilities = await detectSiteCapabilities(
      'https://client-site.com',
      'client_secret'
    );
    
    console.log('Site yetenekleri:', capabilities);
    
    // Kategorileri al
    const categoriesResponse = await api.makeRequest('get-categories', {
      site_auth: {
        site_url: 'https://client-site.com',
        secret_pass: 'client_secret'
      }
    });
    
    const categories = categoriesResponse.body.data || [];
    console.log('Mevcut kategoriler:', categories);
    
    // Blog yazısı oluştur
    const blogPost = {
      title: 'WordPress SEO Rehberi 2024',
      content: `
        <h2>WordPress SEO Nedir?</h2>
        <p>WordPress SEO, web sitenizin arama motorlarında daha iyi sıralanmasını sağlayan teknikler bütünüdür.</p>
        
        <h3>Temel SEO Adımları</h3>
        <ul>
          <li>Anahtar kelime araştırması</li>
          <li>İçerik optimizasyonu</li>
          <li>Teknik SEO</li>
          <li>Link building</li>
        </ul>
        
        <h3>WordPress SEO Eklentileri</h3>
        <p>En popüler WordPress SEO eklentileri:</p>
        <ol>
          <li>Yoast SEO</li>
          <li>Rank Math</li>
          <li>All in One SEO Pack</li>
        </ol>
      `,
      excerpt: 'WordPress SEO hakkında bilmeniz gereken her şey. 2024 yılı için güncel SEO stratejileri.',
      status: 'publish',
      categories: [1], // "SEO" kategorisi
      tags: ['wordpress', 'seo', '2024', 'rehber'],
      
      // SEO optimizasyonu
      meta_title: 'WordPress SEO Rehberi 2024 - Kapsamlı Kılavuz',
      meta_description: 'WordPress SEO optimizasyonu için kapsamlı rehber. Anahtar kelime araştırmasından teknik SEO\'ya kadar tüm detaylar.',
      focus_keyword: 'wordpress seo',
      
      // Özel alanlar
      custom_fields: {
        reading_time: '5 dakika',
        difficulty_level: 'Başlangıç',
        last_updated: '2024-01-15'
      }
    };
    
    const result = await createContentWithProgress(
      'https://client-site.com',
      'client_secret',
      blogPost
    );
    
    console.log('Blog yazısı oluşturuldu:', result);
    
  } catch (error) {
    console.error('Hata:', error);
  }
}

// Çalıştır
createBlogPost();
```

### Örnek 2: WooCommerce Ürün Oluşturma

```javascript
async function createWooCommerceProduct() {
  const api = new SEOKillerAPI(
    'https://your-proxy-site.com', 
    'your_api_key_here'
  );
  
  try {
    // WooCommerce kontrolü
    const capabilities = await detectSiteCapabilities(
      'https://client-store.com',
      'store_secret'
    );
    
    if (!capabilities.hasWooCommerce) {
      throw new Error('Client sitede WooCommerce aktif değil');
    }
    
    // Ürün kategorilerini al
    const categoriesResponse = await api.makeRequest('get-categories', {
      site_auth: {
        site_url: 'https://client-store.com',
        secret_pass: 'store_secret'
      }
    });
    
    // Yeni ürün oluştur
    const product = {
      name: 'Premium WordPress Teması',
      description: `
        <h3>Özellikler</h3>
        <ul>
          <li>Responsive tasarım</li>
          <li>SEO optimized</li>
          <li>Hızlı yükleme</li>
          <li>E-ticaret uyumlu</li>
          <li>Çoklu dil desteği</li>
        </ul>
        
        <h3>Teknik Özellikler</h3>
        <ul>
          <li>WordPress 6.0+ uyumlu</li>
          <li>WooCommerce desteği</li>
          <li>Elementor uyumlu</li>
          <li>Child theme dahil</li>
        </ul>
      `,
      short_description: 'Profesyonel WordPress teması. E-ticaret ve blog siteleri için optimize edilmiş.',
      type: 'simple',
      status: 'publish',
      
      // Fiyatlandırma
      regular_price: '99.00',
      sale_price: '79.00',
      
      // Ürün bilgileri
      sku: 'WP-THEME-PREMIUM-001',
      manage_stock: true,
      stock_quantity: 999,
      stock_status: 'instock',
      
      // Dijital ürün (ağırlık yok)
      weight: '',
      
      // Kategoriler (Digital products)
      category_ids: [15],
      tag_ids: [5, 12, 18], // wordpress, tema, premium
      
      // Ürün görselleri
      images: [
        {
          src: 'https://example.com/theme-preview-1.jpg',
          alt: 'WordPress tema önizleme',
          position: 0
        },
        {
          src: 'https://example.com/theme-preview-2.jpg', 
          alt: 'WordPress tema mobile görünüm',
          position: 1
        }
      ],
      
      // SEO
      meta_title: 'Premium WordPress Teması - E-ticaret Uyumlu',
      meta_description: 'Profesyonel WordPress teması. SEO optimized, hızlı ve e-ticaret uyumlu. Şimdi %20 indirimle!'
    };
    
    console.log('🛍️ WooCommerce ürünü oluşturuluyor...');
    
    const result = await api.makeRequest('create-product', {
      site_auth: {
        site_url: 'https://client-store.com',
        secret_pass: 'store_secret'
      },
      ...product
    });
    
    if (result.status === 200 && result.body.success) {
      console.log('✅ Ürün başarıyla oluşturuldu!');
      console.log(`🆔 Ürün ID: ${result.body.data.id}`);
      console.log(`🔗 Ürün URL: ${result.body.data.permalink}`);
      console.log(`💰 Fiyat: ${result.body.data.price}₺`);
    } else {
      throw new Error(`Ürün oluşturulamadı: ${result.body.message}`);
    }
    
  } catch (error) {
    console.error('❌ Hata:', error);
  }
}

// Çalıştır
createWooCommerceProduct();
```

### Örnek 3: Bulk Content Operations

```javascript
async function bulkContentOperations() {
  const api = new SEOKillerAPIWithCache(
    'https://your-proxy-site.com',
    'your_api_key_here'
  );
  
  const clientUrl = 'https://client-site.com';
  const secretPass = 'client_secret';
  
  try {
    // Site bilgilerini cache'le
    console.log('📊 Site bilgileri alınıyor...');
    const siteInfo = await api.getSiteInfo(clientUrl, secretPass);
    
    // Kategorileri cache'le
    console.log('📂 Kategoriler alınıyor...');
    const categoriesResponse = await api.makeRequest('get-categories', {
      site_auth: { site_url: clientUrl, secret_pass: secretPass }
    });
    const categories = categoriesResponse.body.data || [];
    
    // Yazarları cache'le
    console.log('👥 Yazarlar alınıyor...');
    const authorsResponse = await api.makeRequest('get-authors', {
      site_auth: { site_url: clientUrl, secret_pass: secretPass }
    });
    const authors = authorsResponse.body.data || [];
    
    // Toplu içerik oluşturma
    const contentSeries = [
      {
        title: 'WordPress Güvenlik Rehberi',
        category: 'Güvenlik',
        tags: ['wordpress', 'güvenlik', 'backup']
      },
      {
        title: 'WordPress Performans Optimizasyonu',
        category: 'Performans', 
        tags: ['wordpress', 'hız', 'optimizasyon']
      },
      {
        title: 'WordPress Plugin Geliştirme',
        category: 'Geliştirme',
        tags: ['wordpress', 'plugin', 'development']
      }
    ];
    
    console.log(`📝 ${contentSeries.length} içerik oluşturuluyor...`);
    
    const results = [];
    
    for (let i = 0; i < contentSeries.length; i++) {
      const item = contentSeries[i];
      
      // Kategori ID'sini bul
      const category = categories.find(cat => 
        cat.name.toLowerCase().includes(item.category.toLowerCase())
      );
      const categoryId = category ? category.id : 1; // Default category
      
      // Random yazar seç
      const randomAuthor = authors[Math.floor(Math.random() * authors.length)];
      
      const content = {
        title: item.title,
        content: `
          <h2>${item.title}</h2>
          <p>Bu ${item.category.toLowerCase()} ile ilgili kapsamlı bir rehberdir.</p>
          
          <h3>İçerik Başlıkları</h3>
          <ul>
            <li>Giriş ve Temel Kavramlar</li>
            <li>Adım Adım Uygulama</li>
            <li>En İyi Uygulamalar</li>
            <li>Sık Karşılaşılan Sorunlar</li>
            <li>Sonuç ve Öneriler</li>
          </ul>
          
          <p>Detaylı bilgi için rehberi okumaya devam edin...</p>
        `,
        excerpt: `${item.category} hakkında detaylı rehber ve pratik çözümler.`,
        status: 'draft', // İlk önce draft olarak oluştur
        categories: [categoryId],
        tags: item.tags,
        author: randomAuthor.id,
        meta_title: `${item.title} - Kapsamlı Rehber`,
        meta_description: `${item.title} için detaylı rehber. Adım adım uygulama ve en iyi uygulamalar.`
      };
      
      try {
        console.log(`📄 ${i + 1}/${contentSeries.length}: "${item.title}" oluşturuluyor...`);
        
        const result = await api.createContent(clientUrl, secretPass, content);
        
        if (result.status === 200 && result.body.success) {
          results.push({
            title: item.title,
            id: result.body.data.id,
            url: result.body.data.link,
            status: 'success'
          });
          console.log(`✅ Başarılı: ${item.title}`);
        } else {
          results.push({
            title: item.title,
            status: 'error',
            error: result.body.message
          });
          console.log(`❌ Hata: ${item.title} - ${result.body.message}`);
        }
        
        // Rate limiting için bekleme
        await sleep(1000); // 1 saniye bekle
        
      } catch (error) {
        results.push({
          title: item.title,
          status: 'error',
          error: error.message
        });
        console.log(`❌ Hata: ${item.title} - ${error.message}`);
      }
    }
    
    // Özet rapor
    console.log('\n📊 BULK İŞLEM RAPORU:');
    console.log('='.repeat(50));
    
    const successful = results.filter(r => r.status === 'success');
    const failed = results.filter(r => r.status === 'error');
    
    console.log(`✅ Başarılı: ${successful.length}`);
    console.log(`❌ Başarısız: ${failed.length}`);
    console.log(`📈 Başarı Oranı: ${((successful.length / results.length) * 100).toFixed(1)}%`);
    
    if (successful.length > 0) {
      console.log('\n🎉 BAŞARILI İÇERİKLER:');
      successful.forEach(item => {
        console.log(`  📄 ${item.title} (ID: ${item.id})`);
        console.log(`      🔗 ${item.url}`);
      });
    }
    
    if (failed.length > 0) {
      console.log('\n⚠️ BAŞARISIZ İÇERİKLER:');
      failed.forEach(item => {
        console.log(`  ❌ ${item.title}: ${item.error}`);
      });
    }
    
  } catch (error) {
    console.error('❌ Bulk işlem hatası:', error);
  }
}

// Yardımcı fonksiyon
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Çalıştır
bulkContentOperations();
```

---

## 🎯 Sonuç

Bu kılavuz, SEOKILLER ACTION eklentisinin tüm yönlerini kapsamlı şekilde açıklamaktadır. Eklentiyi kullanırken:

### ✅ **Unutmayın:**
- API key'inizi güvenli tutun
- Rate limiting kurallarına uyun
- Alternative endpoint'leri kullanın
- Hata yönetimini doğru uygulayın
- Content validation yapın

### 🚀 **Öneriler:**
- Cache stratejisi kullanın
- Progress reporting uygulayın
- Bulk operations için beklemeler ekleyin
- Site yeteneklerini kontrol edin
- Güvenli authentication yöntemlerini tercih edin

### 🛠️ **Destek:**
- API test endpoint'lerini kullanın
- Debug mode'u etkinleştirin
- Log dosyalarını inceleyin
- Diagnostic endpoint'i ile sorun giderin

Bu kılavuz sayesinde SEOKILLER ACTION eklentisini profesyonel şekilde kullanabilir ve WordPress sitelerinizi OpenAI GPT modelleri aracılığıyla etkili bir şekilde yönetebilirsiniz. 