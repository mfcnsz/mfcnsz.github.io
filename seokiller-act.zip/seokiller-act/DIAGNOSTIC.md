# Diagnostic Endpoint Kurulumu

Tanılama endpoint'i başarıyla eklendi. Bu endpoint API sorunlarında kullanılabilir.

## Test Komutu

```bash
curl -X POST https://your-site.com/wp-json/seokiller/v1/diagnostic \n  -H "Content-Type: application/json" \n  -d '{"test": "veri", "site_auth": {"site_url": "https://test.com", "secret_pass": "123"}}'
```

Bu komut, API'ye gönderilen veriyi ve sunucunun aldığı tüm bilgileri gösterecektir.

