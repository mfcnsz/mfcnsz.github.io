# Alternatif İçerik Oluşturma Endpoint'i

Yeni bir içerik oluşturma endpoint'i eklendi: /create-content-alt

## Özellikleri

1. Doğrudan ham JSON verisini (php://input) işler
2. API key doğrulaması direkt endpoint içinde yapılır
3. JSON çözümleme hatası olursa net bir hata mesajı döner
4. Her adımda ayrıntılı hatalar log dosyasına yazılır
5. Hem site_auth formatını hem de doğrudan parametre formatını destekler

## Kullanım

```bash
curl -X POST https://your-site.com/wp-json/seokiller/v1/create-content-alt \n  -H "Content-Type: application/json" \n  -H "X-SEOKILLER-API-KEY: c16460beaa1b454c089af9123727d9cc" \n  -d '{
    "title": "Alternatif Endpoint Testi",
    "content": "Bu içerik alternatif endpoint ile oluşturuldu.",
    "site_auth": {
      "site_url": "https://appmysite.online",
      "secret_pass": "your_secret_pass_here"
    }
  }'
```

## Normal Endpoint ile Farkları

- Sınıf metodu yerine doğrudan callback fonksiyonu kullanır
- permission_callback yerine içeride API key kontrolü yapar
- JSON çözümleme hatası olduğunda daha net hata mesajları verir
- Debug loglarında "CREATE_ALT:" öneki kullanır

Bu endpoint OpenAI ile yapılan entegrasyonlarda daha güvenilir çalışacak şekilde tasarlanmıştır.

