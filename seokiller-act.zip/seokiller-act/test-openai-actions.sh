#!/bin/bash

# SEOKILLER ACTION - OpenAI Actions Test Script
# This script tests all OpenAI Actions compatibility features

# Configuration
BASE_URL="${1:-https://your-domain.com}"
API_KEY="${2:-your-api-key-here}"
CLIENT_SITE="${3:-https://client-site.com}"
CLIENT_SECRET="${4:-client-secret}"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Test counter
TESTS_TOTAL=0
TESTS_PASSED=0
TESTS_FAILED=0

# Helper functions
print_header() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}$1${NC}"
    echo -e "${BLUE}========================================${NC}\n"
}

print_test() {
    echo -e "${YELLOW}Testing: $1${NC}"
    TESTS_TOTAL=$((TESTS_TOTAL + 1))
}

print_success() {
    echo -e "${GREEN}✓ PASS: $1${NC}"
    TESTS_PASSED=$((TESTS_PASSED + 1))
}

print_error() {
    echo -e "${RED}✗ FAIL: $1${NC}"
    TESTS_FAILED=$((TESTS_FAILED + 1))
}

print_info() {
    echo -e "${BLUE}ℹ INFO: $1${NC}"
}

# Check if required tools are available
check_dependencies() {
    print_header "Checking Dependencies"
    
    if ! command -v curl &> /dev/null; then
        print_error "curl is required but not installed"
        exit 1
    fi
    
    if ! command -v jq &> /dev/null; then
        print_info "jq is not installed - JSON pretty printing disabled"
        JQ_AVAILABLE=false
    else
        JQ_AVAILABLE=true
    fi
    
    print_success "Dependencies check completed"
}

# Test basic connectivity
test_basic_connectivity() {
    print_header "Basic Connectivity Tests"
    
    print_test "Basic HTTPS connectivity"
    if curl -s -I "$BASE_URL" | grep -q "HTTP"; then
        print_success "HTTPS connection established"
    else
        print_error "Cannot establish HTTPS connection"
        return 1
    fi
    
    print_test "WordPress REST API availability"
    if curl -s "$BASE_URL/wp-json/" | grep -q "wordpress"; then
        print_success "WordPress REST API is available"
    else
        print_error "WordPress REST API is not available"
        return 1
    fi
}

# Test debug endpoint
test_debug_endpoint() {
    print_header "Debug Endpoint Tests"
    
    print_test "Debug endpoint accessibility"
    RESPONSE=$(curl -s "$BASE_URL/wp-json/seokiller/v1/debug")
    
    if echo "$RESPONSE" | grep -q "success"; then
        print_success "Debug endpoint is accessible"
        
        if [ "$JQ_AVAILABLE" = true ]; then
            VERSION=$(echo "$RESPONSE" | jq -r '.version')
            print_info "Plugin version: $VERSION"
        fi
    else
        print_error "Debug endpoint failed"
        echo "Response: $RESPONSE"
    fi
}

# Test OpenAI test endpoint
test_openai_endpoint() {
    print_header "OpenAI Test Endpoint"
    
    print_test "OpenAI test endpoint (GET)"
    RESPONSE=$(curl -s \
        -H "Origin: https://chat.openai.com" \
        -H "User-Agent: ChatGPT/1.0" \
        "$BASE_URL/wp-json/seokiller/v1/openai-test")
    
    if echo "$RESPONSE" | grep -q "OpenAI Actions connection test successful"; then
        print_success "OpenAI test endpoint (GET) working"
        
        if [ "$JQ_AVAILABLE" = true ]; then
            IS_DETECTED=$(echo "$RESPONSE" | jq -r '.request_info.is_openai_detected')
            if [ "$IS_DETECTED" = "true" ]; then
                print_success "OpenAI request detection working"
            else
                print_error "OpenAI request detection failed"
            fi
        fi
    else
        print_error "OpenAI test endpoint (GET) failed"
        echo "Response: $RESPONSE"
    fi
    
    print_test "OpenAI test endpoint (POST)"
    RESPONSE=$(curl -s -X POST \
        -H "Origin: https://chat.openai.com" \
        -H "User-Agent: ChatGPT/1.0" \
        -H "Content-Type: application/json" \
        -d '{"test": "data"}' \
        "$BASE_URL/wp-json/seokiller/v1/openai-test")
    
    if echo "$RESPONSE" | grep -q "OpenAI Actions connection test successful"; then
        print_success "OpenAI test endpoint (POST) working"
    else
        print_error "OpenAI test endpoint (POST) failed"
        echo "Response: $RESPONSE"
    fi
}

# Test CORS preflight
test_cors_preflight() {
    print_header "CORS Preflight Tests"
    
    print_test "OPTIONS preflight request"
    RESPONSE=$(curl -s -I -X OPTIONS \
        -H "Origin: https://chat.openai.com" \
        -H "Access-Control-Request-Method: POST" \
        -H "Access-Control-Request-Headers: X-SEOKILLER-API-KEY, Content-Type" \
        "$BASE_URL/wp-json/seokiller/v1/get-site-info")
    
    if echo "$RESPONSE" | grep -q "Access-Control-Allow-Origin"; then
        print_success "CORS preflight headers present"
        
        if echo "$RESPONSE" | grep -q "https://chat.openai.com"; then
            print_success "Correct CORS origin allowed"
        else
            print_error "Incorrect CORS origin"
        fi
    else
        print_error "CORS preflight headers missing"
        echo "Response headers:"
        echo "$RESPONSE"
    fi
}

# Test authentication
test_authentication() {
    print_header "Authentication Tests"
    
    if [ "$API_KEY" = "your-api-key-here" ]; then
        print_info "Skipping authentication tests - no API key provided"
        print_info "Usage: $0 <base_url> <api_key> [client_site] [client_secret]"
        return
    fi
    
    print_test "Authentication with X-SEOKILLER-API-KEY header"
    RESPONSE=$(curl -s \
        -H "X-SEOKILLER-API-KEY: $API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"site_auth\":{\"site_url\":\"$CLIENT_SITE\",\"secret_pass\":\"$CLIENT_SECRET\"}}" \
        "$BASE_URL/wp-json/seokiller/v1/get-site-info")
    
    if echo "$RESPONSE" | grep -q "success\|Failed to connect"; then
        print_success "Authentication with X-SEOKILLER-API-KEY working"
    else
        if echo "$RESPONSE" | grep -q "api_key"; then
            print_error "Authentication failed - check API key"
        else
            print_error "Unexpected authentication response"
        fi
        echo "Response: $RESPONSE"
    fi
    
    print_test "Authentication with Authorization Bearer header"
    RESPONSE=$(curl -s \
        -H "Authorization: Bearer $API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"site_auth\":{\"site_url\":\"$CLIENT_SITE\",\"secret_pass\":\"$CLIENT_SECRET\"}}" \
        "$BASE_URL/wp-json/seokiller/v1/get-site-info")
    
    if echo "$RESPONSE" | grep -q "success\|Failed to connect"; then
        print_success "Authentication with Authorization Bearer working"
    else
        if echo "$RESPONSE" | grep -q "api_key"; then
            print_error "Bearer authentication failed"
        else
            print_error "Unexpected bearer authentication response"
        fi
    fi
}

# Test JSON parsing
test_json_parsing() {
    print_header "JSON Parsing Tests"
    
    if [ "$API_KEY" = "your-api-key-here" ]; then
        print_info "Skipping JSON parsing tests - no API key provided"
        return
    fi
    
    print_test "JSON parsing with nested site_auth"
    RESPONSE=$(curl -s \
        -H "X-SEOKILLER-API-KEY: $API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"site_auth\":{\"site_url\":\"$CLIENT_SITE\",\"secret_pass\":\"$CLIENT_SECRET\"}}" \
        "$BASE_URL/wp-json/seokiller/v1/json-test")
    
    if echo "$RESPONSE" | grep -q "site_auth_found.*Yes"; then
        print_success "Nested site_auth format parsing working"
    else
        print_error "Nested site_auth format parsing failed"
        echo "Response: $RESPONSE"
    fi
    
    print_test "JSON parsing with direct parameters"
    RESPONSE=$(curl -s \
        -H "X-SEOKILLER-API-KEY: $API_KEY" \
        -H "Content-Type: application/json" \
        -d "{\"site_url\":\"$CLIENT_SITE\",\"secret_pass\":\"$CLIENT_SECRET\"}" \
        "$BASE_URL/wp-json/seokiller/v1/json-test")
    
    if echo "$RESPONSE" | grep -q "Success"; then
        print_success "Direct parameters parsing working"
    else
        print_error "Direct parameters parsing failed"
        echo "Response: $RESPONSE"
    fi
}

# Test error responses
test_error_responses() {
    print_header "Error Response Tests"
    
    print_test "Missing API key error"
    RESPONSE=$(curl -s \
        -H "Content-Type: application/json" \
        -d '{}' \
        "$BASE_URL/wp-json/seokiller/v1/get-site-info")
    
    if echo "$RESPONSE" | grep -q "api_key_missing"; then
        print_success "Missing API key error handled correctly"
    else
        print_error "Missing API key error not handled correctly"
        echo "Response: $RESPONSE"
    fi
    
    if [ "$API_KEY" != "your-api-key-here" ]; then
        print_test "Missing parameters error"
        RESPONSE=$(curl -s \
            -H "X-SEOKILLER-API-KEY: $API_KEY" \
            -H "Content-Type: application/json" \
            -d '{}' \
            "$BASE_URL/wp-json/seokiller/v1/get-site-info")
        
        if echo "$RESPONSE" | grep -q "missing_required_params\|Missing required parameter"; then
            print_success "Missing parameters error handled correctly"
        else
            print_error "Missing parameters error not handled correctly"
            echo "Response: $RESPONSE"
        fi
    fi
}

# Test rate limiting (basic)
test_rate_limiting() {
    print_header "Rate Limiting Tests"
    
    if [ "$API_KEY" = "your-api-key-here" ]; then
        print_info "Skipping rate limiting tests - no API key provided"
        return
    fi
    
    print_test "Rate limiting behavior"
    print_info "Sending 5 rapid requests to test rate limiting..."
    
    for i in {1..5}; do
        RESPONSE=$(curl -s \
            -H "X-SEOKILLER-API-KEY: $API_KEY" \
            -H "Content-Type: application/json" \
            -d "{\"site_auth\":{\"site_url\":\"$CLIENT_SITE\",\"secret_pass\":\"$CLIENT_SECRET\"}}" \
            "$BASE_URL/wp-json/seokiller/v1/get-site-info")
        
        if echo "$RESPONSE" | grep -q "rate.*limit"; then
            print_info "Rate limiting triggered on request $i"
            break
        fi
        sleep 0.1
    done
    
    print_success "Rate limiting test completed"
}

# Performance test
test_performance() {
    print_header "Performance Tests"
    
    print_test "Response time measurement"
    TOTAL_TIME=0
    REQUESTS=5
    
    for i in $(seq 1 $REQUESTS); do
        TIME=$(curl -o /dev/null -s -w "%{time_total}" "$BASE_URL/wp-json/seokiller/v1/debug")
        TOTAL_TIME=$(echo "$TOTAL_TIME + $TIME" | bc -l 2>/dev/null || echo "$TOTAL_TIME")
        print_info "Request $i: ${TIME}s"
    done
    
    if command -v bc &> /dev/null; then
        AVG_TIME=$(echo "scale=3; $TOTAL_TIME / $REQUESTS" | bc)
        print_info "Average response time: ${AVG_TIME}s"
        
        if (( $(echo "$AVG_TIME < 2.0" | bc -l) )); then
            print_success "Response time acceptable (< 2s)"
        else
            print_error "Response time slow (> 2s)"
        fi
    else
        print_info "bc not available - cannot calculate average"
        print_success "Performance test completed"
    fi
}

# SSL/TLS test
test_ssl() {
    print_header "SSL/TLS Tests"
    
    print_test "SSL certificate validity"
    if curl -s -I "$BASE_URL" | grep -q "HTTP/"; then
        print_success "SSL certificate is valid"
    else
        print_error "SSL certificate issue detected"
    fi
    
    print_test "HTTPS enforcement"
    HTTP_URL=$(echo "$BASE_URL" | sed 's/https:/http:/')
    HTTP_RESPONSE=$(curl -s -I "$HTTP_URL" 2>/dev/null || echo "")
    
    if echo "$HTTP_RESPONSE" | grep -q "301\|302"; then
        print_success "HTTP to HTTPS redirect working"
    else
        print_info "HTTP redirect test inconclusive"
    fi
}

# Main test execution
main() {
    echo -e "${BLUE}SEOKILLER ACTION - OpenAI Actions Compatibility Test${NC}"
    echo -e "${BLUE}====================================================${NC}"
    echo ""
    echo "Base URL: $BASE_URL"
    echo "API Key: ${API_KEY:0:8}..."
    echo "Client Site: $CLIENT_SITE"
    echo ""
    
    check_dependencies
    test_basic_connectivity
    test_ssl
    test_debug_endpoint
    test_openai_endpoint
    test_cors_preflight
    test_authentication
    test_json_parsing
    test_error_responses
    test_rate_limiting
    test_performance
    
    # Summary
    print_header "Test Summary"
    echo -e "Total Tests: $TESTS_TOTAL"
    echo -e "${GREEN}Passed: $TESTS_PASSED${NC}"
    echo -e "${RED}Failed: $TESTS_FAILED${NC}"
    
    if [ $TESTS_FAILED -eq 0 ]; then
        echo -e "\n${GREEN}🎉 All tests passed! OpenAI Actions compatibility confirmed.${NC}"
        exit 0
    else
        echo -e "\n${RED}⚠️  Some tests failed. Please review the issues above.${NC}"
        exit 1
    fi
}

# Run tests
main 