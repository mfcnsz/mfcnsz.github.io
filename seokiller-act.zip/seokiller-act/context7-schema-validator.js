#!/usr/bin/env node

/**
 * CONTEXT7 OpenAI Schema Validator
 * Comprehensive validation tool for SEOKILLER ACTION OpenAI schema
 * Tests structure, endpoints, compatibility, and contextual accuracy
 */

const https = require('https');
const fs = require('fs');

// Configuration
const CONFIG = {
    BASE_URL: 'https://api.seokiller.net',
    SCHEMA_FILE: './openai-schema.json',
    TIMEOUT: 10000,
    COLORS: {
        GREEN: '\x1b[32m',
        RED: '\x1b[31m',
        YELLOW: '\x1b[33m',
        BLUE: '\x1b[34m',
        CYAN: '\x1b[36m',
        RESET: '\x1b[0m',
        BOLD: '\x1b[1m'
    }
};

class Context7Validator {
    constructor() {
        this.results = {
            total: 0,
            passed: 0,
            failed: 0,
            warnings: 0,
            tests: []
        };
        this.schema = null;
    }

    log(message, type = 'info') {
        const colors = CONFIG.COLORS;
        const timestamp = new Date().toISOString();
        
        switch(type) {
            case 'success':
                console.log(`${colors.GREEN}✓${colors.RESET} ${message}`);
                break;
            case 'error':
                console.log(`${colors.RED}✗${colors.RESET} ${message}`);
                break;
            case 'warning':
                console.log(`${colors.YELLOW}⚠${colors.RESET} ${message}`);
                break;
            case 'info':
                console.log(`${colors.BLUE}ℹ${colors.RESET} ${message}`);
                break;
            case 'header':
                console.log(`\n${colors.BOLD}${colors.CYAN}${'='.repeat(60)}${colors.RESET}`);
                console.log(`${colors.BOLD}${colors.CYAN} ${message}${colors.RESET}`);
                console.log(`${colors.BOLD}${colors.CYAN}${'='.repeat(60)}${colors.RESET}\n`);
                break;
        }
    }

    async loadSchema() {
        try {
            const schemaContent = fs.readFileSync(CONFIG.SCHEMA_FILE, 'utf8');
            this.schema = JSON.parse(schemaContent);
            this.log('Schema loaded successfully', 'success');
            return true;
        } catch (error) {
            this.log(`Failed to load schema: ${error.message}`, 'error');
            return false;
        }
    }

    addTest(name, status, details = '', context = '') {
        this.results.total++;
        const test = { name, status, details, context, timestamp: new Date().toISOString() };
        
        if (status === 'passed') {
            this.results.passed++;
            this.log(`${name}: ${details}`, 'success');
        } else if (status === 'failed') {
            this.results.failed++;
            this.log(`${name}: ${details}`, 'error');
        } else if (status === 'warning') {
            this.results.warnings++;
            this.log(`${name}: ${details}`, 'warning');
        }
        
        this.results.tests.push(test);
    }

    // Context7 Test 1: Schema Structure Validation
    validateSchemaStructure() {
        this.log('CONTEXT7 TEST 1: Schema Structure Validation', 'header');
        
        // OpenAPI version check
        if (this.schema.openapi === '3.0.1') {
            this.addTest('OpenAPI Version', 'passed', 'Using OpenAPI 3.0.1');
        } else {
            this.addTest('OpenAPI Version', 'failed', `Expected 3.0.1, got ${this.schema.openapi}`);
        }

        // Version check
        if (this.schema.info?.version === '1.2.0') {
            this.addTest('API Version', 'passed', 'Current version 1.2.0');
        } else {
            this.addTest('API Version', 'warning', `Version is ${this.schema.info?.version}, expected 1.2.0`);
        }

        // OpenAI compatibility markers
        if (this.schema.info?.['x-openai-compatible'] === true) {
            this.addTest('OpenAI Compatibility Flag', 'passed', 'Schema marked as OpenAI compatible');
        } else {
            this.addTest('OpenAI Compatibility Flag', 'failed', 'Missing OpenAI compatibility flag');
        }

        // CORS configuration
        if (this.schema.info?.['x-cors-enabled'] === true) {
            this.addTest('CORS Configuration', 'passed', 'CORS enabled in schema');
        } else {
            this.addTest('CORS Configuration', 'failed', 'CORS not configured in schema');
        }

        // Authentication methods
        const authMethods = this.schema.info?.['x-authentication-types'];
        if (authMethods && authMethods.includes('X-SEOKILLER-API-KEY')) {
            this.addTest('Authentication Methods', 'passed', `Supports: ${authMethods.join(', ')}`);
        } else {
            this.addTest('Authentication Methods', 'failed', 'Missing X-SEOKILLER-API-KEY authentication');
        }
    }

    // Context7 Test 2: Critical Endpoints Validation
    validateCriticalEndpoints() {
        this.log('CONTEXT7 TEST 2: Critical Endpoints Validation', 'header');
        
        const requiredEndpoints = [
            '/wp-json/seokiller/v1/debug',
            '/wp-json/seokiller/v1/openai-test',
            '/wp-json/seokiller/v1/get-site-info',
            '/wp-json/seokiller/v1/get-posts',
            '/wp-json/seokiller/v1/create-content'
        ];

        const paths = this.schema.paths || {};
        
        requiredEndpoints.forEach(endpoint => {
            if (paths[endpoint]) {
                this.addTest(`Endpoint ${endpoint}`, 'passed', 'Defined in schema');
                
                // Check HTTP methods
                const methods = Object.keys(paths[endpoint]);
                if (methods.length > 0) {
                    this.addTest(`${endpoint} Methods`, 'passed', `Supports: ${methods.join(', ')}`);
                } else {
                    this.addTest(`${endpoint} Methods`, 'failed', 'No HTTP methods defined');
                }
            } else {
                this.addTest(`Endpoint ${endpoint}`, 'failed', 'Missing from schema');
            }
        });

        // OpenAI test endpoint specific validation
        const openaiTest = paths['/wp-json/seokiller/v1/openai-test'];
        if (openaiTest) {
            const requiredMethods = ['get', 'post', 'options'];
            requiredMethods.forEach(method => {
                if (openaiTest[method]) {
                    this.addTest(`OpenAI Test ${method.toUpperCase()}`, 'passed', 'Method available');
                } else {
                    this.addTest(`OpenAI Test ${method.toUpperCase()}`, 'failed', 'Method missing');
                }
            });
        }
    }

    // Context7 Test 3: Live Endpoint Testing
    async validateLiveEndpoints() {
        this.log('CONTEXT7 TEST 3: Live Endpoint Testing', 'header');
        
        // Test debug endpoint
        try {
            const debugResponse = await this.makeRequest('/wp-json/seokiller/v1/debug');
            if (debugResponse && debugResponse.status === 'success') {
                this.addTest('Debug Endpoint Live', 'passed', `Version: ${debugResponse.version}`);
            } else {
                this.addTest('Debug Endpoint Live', 'failed', 'Endpoint not responding correctly');
            }
        } catch (error) {
            this.addTest('Debug Endpoint Live', 'failed', `Request failed: ${error.message}`);
        }

        // Test OpenAI endpoint with proper headers
        try {
            const openaiResponse = await this.makeRequest('/wp-json/seokiller/v1/openai-test', {
                'Origin': 'https://chat.openai.com',
                'User-Agent': 'ChatGPT/1.0'
            });
            
            if (openaiResponse && openaiResponse.status === 'success') {
                this.addTest('OpenAI Test Endpoint Live', 'passed', 'OpenAI detection working');
                
                if (openaiResponse.request_info?.is_openai_detected) {
                    this.addTest('OpenAI Detection', 'passed', 'OpenAI request properly detected');
                } else {
                    this.addTest('OpenAI Detection', 'failed', 'OpenAI request not detected');
                }
            } else {
                this.addTest('OpenAI Test Endpoint Live', 'failed', 'Endpoint not responding correctly');
            }
        } catch (error) {
            this.addTest('OpenAI Test Endpoint Live', 'failed', `Request failed: ${error.message}`);
        }
    }

    // Context7 Test 4: Schema Components Validation
    validateSchemaComponents() {
        this.log('CONTEXT7 TEST 4: Schema Components Validation', 'header');
        
        const components = this.schema.components || {};
        
        // Security schemes
        if (components.securitySchemes?.ApiKeyAuth) {
            this.addTest('Security Scheme', 'passed', 'ApiKeyAuth defined');
        } else {
            this.addTest('Security Scheme', 'failed', 'ApiKeyAuth missing');
        }

        // Required schemas
        const requiredSchemas = [
            'DebugResponse',
            'OpenAITestResponse',
            'SiteAuthRequest',
            'PostRequest',
            'ContentRequest'
        ];

        const schemas = components.schemas || {};
        requiredSchemas.forEach(schemaName => {
            if (schemas[schemaName]) {
                this.addTest(`Schema ${schemaName}`, 'passed', 'Defined');
            } else {
                this.addTest(`Schema ${schemaName}`, 'warning', 'Not found - may be optional');
            }
        });
    }

    // Context7 Test 5: OpenAI Actions Compatibility
    async validateOpenAICompatibility() {
        this.log('CONTEXT7 TEST 5: OpenAI Actions Compatibility', 'header');
        
        // Test CORS preflight
        try {
            const corsResponse = await this.makeRequest('/wp-json/seokiller/v1/get-site-info', {
                'Origin': 'https://chat.openai.com',
                'Access-Control-Request-Method': 'POST',
                'Access-Control-Request-Headers': 'X-SEOKILLER-API-KEY, Content-Type'
            }, 'OPTIONS');
            
            this.addTest('CORS Preflight', 'passed', 'OPTIONS request handled');
        } catch (error) {
            this.addTest('CORS Preflight', 'failed', `CORS preflight failed: ${error.message}`);
        }

        // Validate server URL
        const servers = this.schema.servers || [];
        const hasValidServer = servers.some(server => 
            server.url.includes('seokiller.net') || server.url.includes('api.seokiller.net')
        );
        
        if (hasValidServer) {
            this.addTest('Server URL', 'passed', 'Valid server URL configured');
        } else {
            this.addTest('Server URL', 'failed', 'Invalid or missing server URL');
        }

        // Check operation IDs for OpenAI Actions
        const paths = this.schema.paths || {};
        let validOperationIds = 0;
        let totalOperations = 0;
        
        Object.values(paths).forEach(pathMethods => {
            Object.values(pathMethods).forEach(operation => {
                if (operation.operationId) {
                    totalOperations++;
                    if (operation.operationId.match(/^[a-zA-Z][a-zA-Z0-9_]*$/)) {
                        validOperationIds++;
                    }
                }
            });
        });
        
        if (validOperationIds === totalOperations && totalOperations > 0) {
            this.addTest('Operation IDs', 'passed', `All ${totalOperations} operation IDs valid`);
        } else {
            this.addTest('Operation IDs', 'warning', `${validOperationIds}/${totalOperations} operation IDs valid`);
        }
    }

    // Context7 Test 6: Performance and Reliability
    async validatePerformanceReliability() {
        this.log('CONTEXT7 TEST 6: Performance and Reliability', 'header');
        
        const startTime = Date.now();
        
        try {
            await this.makeRequest('/wp-json/seokiller/v1/debug');
            const responseTime = Date.now() - startTime;
            
            if (responseTime < 2000) {
                this.addTest('Response Time', 'passed', `${responseTime}ms - Good performance`);
            } else if (responseTime < 5000) {
                this.addTest('Response Time', 'warning', `${responseTime}ms - Acceptable performance`);
            } else {
                this.addTest('Response Time', 'failed', `${responseTime}ms - Poor performance`);
            }
        } catch (error) {
            this.addTest('Response Time', 'failed', `Failed to measure: ${error.message}`);
        }

        // Test multiple concurrent requests
        try {
            const promises = Array(3).fill().map(() => 
                this.makeRequest('/wp-json/seokiller/v1/debug')
            );
            
            const results = await Promise.allSettled(promises);
            const successful = results.filter(r => r.status === 'fulfilled').length;
            
            if (successful === 3) {
                this.addTest('Concurrent Requests', 'passed', 'All 3 concurrent requests successful');
            } else {
                this.addTest('Concurrent Requests', 'warning', `${successful}/3 concurrent requests successful`);
            }
        } catch (error) {
            this.addTest('Concurrent Requests', 'failed', `Concurrent testing failed: ${error.message}`);
        }
    }

    // Context7 Test 7: Security and Authentication
    async validateSecurity() {
        this.log('CONTEXT7 TEST 7: Security and Authentication', 'header');
        
        // Test without API key (should fail for protected endpoints)
        try {
            const response = await this.makeRequest('/wp-json/seokiller/v1/get-site-info', {
                'Content-Type': 'application/json'
            }, 'POST', JSON.stringify({
                site_auth: {
                    site_url: 'https://test.com',
                    secret_pass: 'test'
                }
            }));
            
            if (response && response.code && response.code.includes('api_key')) {
                this.addTest('Authentication Required', 'passed', 'Protected endpoint properly requires authentication');
            } else {
                this.addTest('Authentication Required', 'failed', 'Protected endpoint accessible without authentication');
            }
        } catch (error) {
            this.addTest('Authentication Required', 'passed', 'Protected endpoint properly blocked');
        }

        // Test HTTPS requirement
        if (CONFIG.BASE_URL.startsWith('https://')) {
            this.addTest('HTTPS Required', 'passed', 'API uses HTTPS');
        } else {
            this.addTest('HTTPS Required', 'failed', 'API does not use HTTPS');
        }
    }

    makeRequest(path, headers = {}, method = 'GET', body = null) {
        return new Promise((resolve, reject) => {
            const url = new URL(path, CONFIG.BASE_URL);
            
            const options = {
                hostname: url.hostname,
                port: url.port || 443,
                path: url.pathname + url.search,
                method: method,
                headers: {
                    'User-Agent': 'Context7-Validator/1.0',
                    ...headers
                },
                timeout: CONFIG.TIMEOUT
            };

            const req = https.request(options, (res) => {
                let data = '';
                
                res.on('data', (chunk) => {
                    data += chunk;
                });
                
                res.on('end', () => {
                    try {
                        if (data.trim()) {
                            const jsonData = JSON.parse(data);
                            resolve(jsonData);
                        } else {
                            resolve({ status: 'empty_response', statusCode: res.statusCode });
                        }
                    } catch (error) {
                        resolve({ status: 'parse_error', data: data, statusCode: res.statusCode });
                    }
                });
            });

            req.on('error', (error) => {
                reject(error);
            });

            req.on('timeout', () => {
                req.destroy();
                reject(new Error('Request timeout'));
            });

            if (body) {
                req.write(body);
            }
            
            req.end();
        });
    }

    generateReport() {
        this.log('CONTEXT7 VALIDATION REPORT', 'header');
        
        const passRate = this.results.total > 0 ? 
            ((this.results.passed / this.results.total) * 100).toFixed(1) : 0;
        
        this.log(`Total Tests: ${this.results.total}`, 'info');
        this.log(`Passed: ${this.results.passed}`, 'success');
        this.log(`Failed: ${this.results.failed}`, 'error');
        this.log(`Warnings: ${this.results.warnings}`, 'warning');
        this.log(`Pass Rate: ${passRate}%`, 'info');
        
        // Overall assessment
        if (this.results.failed === 0) {
            this.log('\n🎉 EXCELLENT: Schema is fully OpenAI Actions compatible!', 'success');
        } else if (this.results.failed <= 2) {
            this.log('\n✅ GOOD: Schema is mostly compatible with minor issues', 'warning');
        } else {
            this.log('\n❌ NEEDS WORK: Schema has significant compatibility issues', 'error');
        }

        // Save detailed report
        const reportData = {
            timestamp: new Date().toISOString(),
            summary: this.results,
            schema_version: this.schema?.info?.version || 'unknown',
            base_url: CONFIG.BASE_URL
        };

        fs.writeFileSync('context7-validation-report.json', JSON.stringify(reportData, null, 2));
        this.log('\n📄 Detailed report saved to: context7-validation-report.json', 'info');
    }

    async run() {
        this.log('Starting Context7 OpenAI Schema Validation', 'header');
        
        // Load schema
        if (!await this.loadSchema()) {
            return;
        }

        // Run all validation tests
        this.validateSchemaStructure();
        this.validateCriticalEndpoints();
        await this.validateLiveEndpoints();
        this.validateSchemaComponents();
        await this.validateOpenAICompatibility();
        await this.validatePerformanceReliability();
        await this.validateSecurity();
        
        // Generate report
        this.generateReport();
    }
}

// Run the validator
if (require.main === module) {
    const validator = new Context7Validator();
    validator.run().catch(error => {
        console.error('Validation failed:', error);
        process.exit(1);
    });
}

module.exports = Context7Validator; 