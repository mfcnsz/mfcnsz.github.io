<?php
// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Check user permissions
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.', 'seokiller-action'));
}

// Process form submissions
$message = '';
$message_type = '';

// Check if API key regeneration was requested
if (isset($_POST['regenerate_api_key']) && isset($_POST['seokiller_admin_password'])) {
    // Verify nonce for security
    if (!isset($_POST['seokiller_action_nonce']) || !wp_verify_nonce($_POST['seokiller_action_nonce'], 'seokiller_action_regenerate_key')) {
        $message = __('Security verification failed. Please try again.', 'seokiller-action');
        $message_type = 'error';
    } else {
        $admin_password = sanitize_text_field($_POST['seokiller_admin_password']);
        $stored_password_hash = get_option('seokiller_action_admin_password');
        
        // Verify admin password
        if (wp_check_password($admin_password, $stored_password_hash)) {
            // Regenerate the API key
            $new_api_key = SEOKILLER_Action::get_instance()->generate_api_key();
            $message = __('API key regenerated successfully.', 'seokiller-action');
            $message_type = 'success';
        } else {
            $message = __('Invalid admin password. API key not regenerated.', 'seokiller-action');
            $message_type = 'error';
        }
    }
}

// Check if admin password update was requested
if (isset($_POST['update_admin_password']) && 
    isset($_POST['current_admin_password']) && 
    isset($_POST['new_admin_password']) && 
    isset($_POST['confirm_admin_password'])) {
    
    // Verify nonce for security
    if (!isset($_POST['seokiller_action_nonce']) || !wp_verify_nonce($_POST['seokiller_action_nonce'], 'seokiller_action_update_password')) {
        $message = __('Security verification failed. Please try again.', 'seokiller-action');
        $message_type = 'error';
    } else {
        $current_password = sanitize_text_field($_POST['current_admin_password']);
        $new_password = sanitize_text_field($_POST['new_admin_password']);
        $confirm_password = sanitize_text_field($_POST['confirm_admin_password']);
        $stored_password_hash = get_option('seokiller_action_admin_password');
        
        // Verify current password
        if (wp_check_password($current_password, $stored_password_hash)) {
            // Check if new password and confirmation match
            if ($new_password === $confirm_password) {
                // Update the admin password
                update_option('seokiller_action_admin_password', wp_hash_password($new_password));
                $message = __('Admin password updated successfully.', 'seokiller-action');
                $message_type = 'success';
            } else {
                $message = __('New password and confirmation do not match.', 'seokiller-action');
                $message_type = 'error';
            }
        } else {
            $message = __('Current password is incorrect. Admin password not updated.', 'seokiller-action');
            $message_type = 'error';
        }
    }
}

// Get current API key
$api_key = get_option('seokiller_action_api_key');
if (empty($api_key)) {
    // Generate API key if it doesn't exist
    $api_key = SEOKILLER_Action::get_instance()->generate_api_key();
}
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <?php if ($message): ?>
        <div class="notice notice-<?php echo $message_type; ?> is-dismissible">
            <p><?php echo esc_html($message); ?></p>
        </div>
    <?php endif; ?>
    
    <div class="seokiller-action-admin">
        <div class="card">
            <h2><?php _e('API Key Management', 'seokiller-action'); ?></h2>
            <p><?php _e('Your API key is used to authenticate requests from the SEOKILLER GPT to your WordPress site.', 'seokiller-action'); ?></p>
            
            <div class="api-key-display">
                <h3><?php _e('Your Current API Key', 'seokiller-action'); ?></h3>
                <div class="api-key-container">
                    <input type="text" readonly value="<?php echo esc_attr($api_key); ?>" class="regular-text code" onclick="this.select();" />
                    <button type="button" class="button button-secondary copy-api-key"><?php _e('Copy', 'seokiller-action'); ?></button>
                </div>
            </div>
            
            <div class="regenerate-key-section">
                <h3><?php _e('Regenerate API Key', 'seokiller-action'); ?></h3>
                <p class="warning"><?php _e('Warning: Regenerating your API key will invalidate the existing key. Any applications currently using the API key will need to be updated.', 'seokiller-action'); ?></p>
                
                <form method="post" action="">
                    <?php wp_nonce_field('seokiller_action_regenerate_key', 'seokiller_action_nonce'); ?>
                    <table class="form-table">
                        <tr>
                            <th scope="row"><?php _e('Admin Password', 'seokiller-action'); ?></th>
                            <td>
                                <input type="password" name="seokiller_admin_password" class="regular-text" required />
                                <p class="description"><?php _e('Enter your admin password to confirm API key regeneration.', 'seokiller-action'); ?></p>
                            </td>
                        </tr>
                    </table>
                    
                    <p class="submit">
                        <input type="submit" name="regenerate_api_key" class="button button-primary" value="<?php _e('Regenerate API Key', 'seokiller-action'); ?>" />
                    </p>
                </form>
            </div>
        </div>
        
        <div class="card">
            <h2><?php _e('Admin Password Management', 'seokiller-action'); ?></h2>
            <p><?php _e('This password is required for API key regeneration.', 'seokiller-action'); ?></p>
            
            <form method="post" action="">
                <?php wp_nonce_field('seokiller_action_update_password', 'seokiller_action_nonce'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row"><?php _e('Current Password', 'seokiller-action'); ?></th>
                        <td>
                            <input type="password" name="current_admin_password" class="regular-text" required />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('New Password', 'seokiller-action'); ?></th>
                        <td>
                            <input type="password" name="new_admin_password" class="regular-text" required />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><?php _e('Confirm New Password', 'seokiller-action'); ?></th>
                        <td>
                            <input type="password" name="confirm_admin_password" class="regular-text" required />
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <input type="submit" name="update_admin_password" class="button button-primary" value="<?php _e('Update Admin Password', 'seokiller-action'); ?>" />
                </p>
            </form>
        </div>
        
        <div class="card">
            <h2><?php _e('Documentation', 'seokiller-action'); ?></h2>
            
            <h3><?php _e('Making API Requests', 'seokiller-action'); ?></h3>
            <p><?php _e('To make API requests, include your API key in the X-SEOKILLER-API-KEY header.', 'seokiller-action'); ?></p>
            
            <h4><?php _e('Available Endpoints', 'seokiller-action'); ?></h4>
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('Endpoint', 'seokiller-action'); ?></th>
                        <th><?php _e('Method', 'seokiller-action'); ?></th>
                        <th><?php _e('Description', 'seokiller-action'); ?></th>
                        <th><?php _e('Parameters', 'seokiller-action'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/get-site-info</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Get information about a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/get-categories</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Get categories from a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/get-posts</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Get posts from a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code>, <code>per_page, page, category, search</code> (optional)</td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/get-post/{postId}</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Get specific post from a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/create-content</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Create a post on a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code>, <code>title, content</code>, etc.</td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/update-content/{postId}</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Update a post on a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code>, <code>title, content</code>, etc.</td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/delete-post/{postId}</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Delete a post on a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/get-authors</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Get authors from a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                </tbody>
            </table>
            
            <?php if (method_exists('SEOKILLER_Action', 'is_woocommerce_active') && SEOKILLER_Action::get_instance()->is_woocommerce_active()): ?>
            <h4><?php _e('WooCommerce Endpoints', 'seokiller-action'); ?></h4>
            <table class="widefat">
                <thead>
                    <tr>
                        <th><?php _e('Endpoint', 'seokiller-action'); ?></th>
                        <th><?php _e('Method', 'seokiller-action'); ?></th>
                        <th><?php _e('Description', 'seokiller-action'); ?></th>
                        <th><?php _e('Parameters', 'seokiller-action'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/get-products</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Get products from a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/create-product</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Create a product on a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/update-product/{productId}</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Update a product on a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                    <tr>
                        <td><code>/wp-json/seokiller/v1/delete-product/{productId}</code></td>
                        <td><code>POST</code></td>
                        <td><?php _e('Delete a product on a client WordPress site', 'seokiller-action'); ?></td>
                        <td><code>site_url, secret_pass</code> or <code>site_auth</code></td>
                    </tr>
                </tbody>
            </table>
            <?php endif; ?>

            <h3><?php _e('Parameter Format', 'seokiller-action'); ?></h3>
            <p><?php _e('All endpoints accept JSON-formatted parameters in the request body. There are two formats for authentication:', 'seokiller-action'); ?></p>
            
            <h4><?php _e('Format 1: Direct parameters', 'seokiller-action'); ?></h4>
            <pre><code>{
  "site_url": "https://example.com",
  "secret_pass": "your_secret_password",
  ... additional parameters ...
}</code></pre>

            <h4><?php _e('Format 2: Nested site_auth', 'seokiller-action'); ?></h4>
            <pre><code>{
  "site_auth": {
    "site_url": "https://example.com",
    "secret_pass": "your_secret_password"
  },
  ... additional parameters ...
}</code></pre>

            <h3><?php _e('Authentication Example', 'seokiller-action'); ?></h3>
            <p><?php _e('Example curl request:', 'seokiller-action'); ?></p>
            <pre><code>curl -X POST \
  '<?php echo esc_url(get_rest_url(null, 'seokiller/v1/get-site-info')); ?>' \
  -H 'Content-Type: application/json' \
  -H 'X-SEOKILLER-API-KEY: <?php echo esc_attr($api_key); ?>' \
  -d '{
    "site_url": "https://example.com",
    "secret_pass": "your_secret_password"
  }'</code></pre>
        </div>
    </div>
</div>

<script type="text/javascript">
    jQuery(document).ready(function($) {
        // Copy API key to clipboard
        $('.copy-api-key').on('click', function() {
            var apiKeyField = $(this).prev('input');
            apiKeyField.select();
            document.execCommand('copy');
            
            var originalText = $(this).text();
            $(this).text('Copied!');
            
            setTimeout(function(button, originalText) {
                $(button).text(originalText);
            }, 1000, this, originalText);
        });
    });
</script>

<style>
    .seokiller-action-admin .card {
        padding: 20px;
        background: #fff;
        border: 1px solid #ccd0d4;
        box-shadow: 0 1px 1px rgba(0,0,0,.04);
        margin-bottom: 20px;
    }
    
    .api-key-container {
        display: flex;
        align-items: center;
        margin-bottom: 20px;
    }
    
    .api-key-container input {
        margin-right: 8px;
    }
    
    .warning {
        color: #d63638;
    }
</style> 