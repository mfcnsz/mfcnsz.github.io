<?php
/**
 * SEOKILLER ACTION - OpenAI Debug Configuration
 * Add these lines to your wp-config.php file for enhanced OpenAI debugging
 */

// Basic WordPress Debug Settings
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);

// SEOKILLER ACTION Specific Debug Settings
define('SEOKILLER_DEBUG', true);
define('SEOKILLER_LOG_OPENAI', true);
define('SEOKILLER_VERBOSE_LOGGING', true);

// Enhanced Error Logging
ini_set('log_errors', 1);
ini_set('error_log', WP_CONTENT_DIR . '/debug.log');

// Increase memory limit for complex operations
ini_set('memory_limit', '256M');

// Increase execution time for API requests
ini_set('max_execution_time', 300);

// cURL settings for better OpenAI compatibility
define('WP_HTTP_BLOCK_EXTERNAL', false);

// Custom log file for SEOKILLER OpenAI requests
if (!defined('SEOKILLER_OPENAI_LOG')) {
    define('SEOKILLER_OPENAI_LOG', WP_CONTENT_DIR . '/seokiller-openai.log');
}

// Enable REST API debugging
define('REST_REQUEST_AFTER_CALLBACKS', true);

// Optional: Disable WordPress caching during development
define('WP_CACHE', false);

// Optional: Force HTTPS for API requests
define('FORCE_SSL_ADMIN', true);

/**
 * Add these lines at the end of your wp-config.php, just before "That's all, stop editing!"
 * 
 * Example placement:
 * 
 * // ... your existing wp-config.php content ...
 * 
 * // SEOKILLER ACTION OpenAI Debug Configuration
 * include_once(ABSPATH . 'wp-config-openai.php');
 * 
 * // That's all, stop editing! Happy publishing.
 */

// Custom error handler for SEOKILLER requests
if (!function_exists('seokiller_error_handler')) {
    function seokiller_error_handler($errno, $errstr, $errfile, $errline) {
        if (strpos($errfile, 'seokiller') !== false) {
            $log_message = sprintf(
                "[%s] SEOKILLER Error %d: %s in %s on line %d\n",
                date('Y-m-d H:i:s'),
                $errno,
                $errstr,
                $errfile,
                $errline
            );
            error_log($log_message, 3, SEOKILLER_OPENAI_LOG);
        }
        return false; // Continue with normal error handling
    }
    
    set_error_handler('seokiller_error_handler');
}

// Log OpenAI requests function
if (!function_exists('seokiller_log_openai_request')) {
    function seokiller_log_openai_request($message, $data = array()) {
        if (defined('SEOKILLER_LOG_OPENAI') && SEOKILLER_LOG_OPENAI) {
            $log_entry = sprintf(
                "[%s] %s\nData: %s\n%s\n",
                date('Y-m-d H:i:s'),
                $message,
                json_encode($data, JSON_PRETTY_PRINT),
                str_repeat('-', 80)
            );
            error_log($log_entry, 3, SEOKILLER_OPENAI_LOG);
        }
    }
}

// Add hook to log all incoming requests
if (defined('SEOKILLER_VERBOSE_LOGGING') && SEOKILLER_VERBOSE_LOGGING) {
    add_action('init', function() {
        if (strpos($_SERVER['REQUEST_URI'], '/wp-json/seokiller/v1/') !== false) {
            seokiller_log_openai_request('Incoming Request', array(
                'method' => $_SERVER['REQUEST_METHOD'],
                'uri' => $_SERVER['REQUEST_URI'],
                'headers' => getallheaders(),
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
                'origin' => $_SERVER['HTTP_ORIGIN'] ?? 'unknown',
                'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown'
            ));
        }
    });
}
?> 