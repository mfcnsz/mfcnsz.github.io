# SEOKILLER ACTION - OpenAI Actions Kurulum ve Test Kılavuzu

## 🚀 Genel Bakış

SEOKILLER ACTION v1.2.0 artık OpenAI Actions ile tam uyumludur. Bu kılavuz, eklentiyi OpenAI GPT Actions ile nasıl entegre edeceğinizi ve test edeceğinizi gösterir.

## ⚙️ Kurulum Adımları

### 1. Plugin Güncellemesi

Eklentinin v1.2.0 veya daha yeni bir sürümünü kullandığınızdan emin olun:

```bash
# Plugin klasöründe
grep "Version:" seokiller-action.php
# Çıktı: Version: 1.2.0
```

### 2. WordPress Konfigürasyonu

`wp-config.php` dosyanıza debug ayarlarını ekleyin:

```php
// wp-config.php sonuna ekleyin ("That's all, stop editing!" satırından önce)

// SEOKILLER ACTION OpenAI Debug Configuration
include_once(ABSPATH . 'wp-config-openai.php');
```

### 3. Sunucu Konfigürasyonu

#### Apache Sunucular (.htaccess)

Eklenti klasöründeki `.htaccess` dosyası otomatik olarak CORS ayarlarını yapar. Manuel kontrol için:

```apache
# .htaccess dosyasında bu satırların olduğundan emin olun
Header always set Access-Control-Allow-Origin "https://chat.openai.com"
Header always set Access-Control-Allow-Methods "GET, POST, OPTIONS"
Header always set Access-Control-Allow-Headers "X-SEOKILLER-API-KEY, Content-Type, Authorization, X-Requested-With"
```

#### Nginx Sunucular

`nginx-seokiller.conf` dosyasını Nginx konfigürasyonunuza dahil edin:

```nginx
# /etc/nginx/sites-available/your-site içinde
include /path/to/nginx-seokiller.conf;
```

### 4. SSL Sertifikası

OpenAI Actions HTTPS gerektirir:

```bash
# SSL kontrolü
curl -I https://your-domain.com/wp-json/seokiller/v1/debug
# HTTP/2 200 döndürmeli
```

## 🔧 Temel Testler

### 1. Plugin Durumu Kontrolü

```bash
curl -X GET "https://your-domain.com/wp-json/seokiller/v1/debug"
```

**Beklenen Response:**
```json
{
    "status": "success",
    "message": "SEOKILLER ACTION API is working",
    "version": "1.2.0",
    "time": "2024-01-15 10:30:00"
}
```

### 2. OpenAI Test Endpoint'i

```bash
curl -X GET "https://your-domain.com/wp-json/seokiller/v1/openai-test" \
  -H "Origin: https://chat.openai.com" \
  -H "User-Agent: ChatGPT/1.0"
```

**Beklenen Response:**
```json
{
    "status": "success",
    "message": "OpenAI Actions connection test successful",
    "request_info": {
        "is_openai_detected": true,
        "origin": "https://chat.openai.com"
    },
    "compatibility": {
        "cors_enabled": true,
        "openai_compatible": true
    }
}
```

### 3. CORS Preflight Test

```bash
curl -X OPTIONS "https://your-domain.com/wp-json/seokiller/v1/get-site-info" \
  -H "Origin: https://chat.openai.com" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: X-SEOKILLER-API-KEY, Content-Type" \
  -v
```

**Beklenen Headers:**
```
Access-Control-Allow-Origin: https://chat.openai.com
Access-Control-Allow-Methods: GET, POST, OPTIONS
Access-Control-Allow-Headers: X-SEOKILLER-API-KEY, Content-Type, Authorization, X-Requested-With
```

### 4. Authentication Test

```bash
curl -X POST "https://your-domain.com/wp-json/seokiller/v1/get-site-info" \
  -H "X-SEOKILLER-API-KEY: YOUR_API_KEY_HERE" \
  -H "Content-Type: application/json" \
  -d '{
    "site_auth": {
      "site_url": "https://client-site.com",
      "secret_pass": "client_secret"
    }
  }'
```

## 🤖 OpenAI Actions Entegrasyonu

### 1. OpenAI Schema Import

`openai-schema.json` dosyasını OpenAI Actions'a import edin:

1. ChatGPT → Settings → Beta features → Actions
2. "Create a GPT" → Configure → Actions
3. "Import from URL" veya "Import schema"
4. Schema dosyasını yükleyin

### 2. Authentication Ayarları

OpenAI Actions'da authentication ayarlarını yapın:

```
Authentication Type: API Key
API Key: YOUR_SEOKILLER_API_KEY
Auth Type: Custom
Header Name: X-SEOKILLER-API-KEY
```

### 3. Server URL

OpenAI Actions'da server URL'sini ayarlayın:

```
Server URL: https://your-domain.com/wp-json/seokiller/v1
```

## 🔍 Debug ve Log Kontrolü

### 1. WordPress Debug Logs

```bash
# WordPress genel debug log
tail -f /path/to/wp-content/debug.log | grep SEOKILLER

# SEOKILLER özel OpenAI log
tail -f /path/to/wp-content/seokiller-openai.log
```

### 2. Sunucu Access Logs

#### Apache
```bash
tail -f /var/log/apache2/access.log | grep seokiller
```

#### Nginx
```bash
tail -f /var/log/nginx/seokiller_access.log
```

### 3. Real-time Monitoring

```bash
# OpenAI isteklerini real-time takip
watch -n 1 'tail -5 /path/to/wp-content/seokiller-openai.log'
```

## 🚨 Sorun Giderme

### Problem: CORS Hatası

**Belirti:**
```
Access to fetch at 'https://your-domain.com/wp-json/seokiller/v1/...' 
from origin 'https://chat.openai.com' has been blocked by CORS policy
```

**Çözüm:**
1. `.htaccess` veya Nginx config'i kontrol edin
2. WordPress'in REST API'sının aktif olduğundan emin olun
3. SSL sertifikasını kontrol edin

```bash
# CORS test
curl -H "Origin: https://chat.openai.com" \
  -H "Access-Control-Request-Method: POST" \
  -H "Access-Control-Request-Headers: X-SEOKILLER-API-KEY" \
  -X OPTIONS https://your-domain.com/wp-json/seokiller/v1/debug -v
```

### Problem: Authentication Failed

**Belirti:**
```json
{
  "code": "api_key_missing",
  "message": "API key is missing. Please provide X-SEOKILLER-API-KEY header."
}
```

**Çözüm:**
1. API key'in doğru olduğundan emin olun
2. Header formatını kontrol edin
3. OpenAI Actions authentication ayarlarını gözden geçirin

```bash
# API key test
curl -X GET "https://your-domain.com/wp-json/seokiller/v1/debug" \
  -H "X-SEOKILLER-API-KEY: YOUR_API_KEY"
```

### Problem: Rate Limiting

**Belirti:**
```json
{
  "code": "seokiller_action_error",
  "message": "Rate limit exceeded. Try again in 45 seconds."
}
```

**Çözüm:**
1. Rate limit ayarlarını kontrol edin
2. OpenAI için yüksek limitler ayarlandığından emin olun
3. Gerekirse rate limit'i artırın

### Problem: Request Parsing Failed

**Belirti:**
```json
{
  "code": "missing_required_params",
  "message": "Missing required parameter(s): site_url, secret_pass"
}
```

**Çözüm:**
1. Request body formatını kontrol edin
2. JSON encoding'i doğrulayın
3. site_auth nested formatını kullanın

**Doğru Format:**
```json
{
  "site_auth": {
    "site_url": "https://client-site.com",
    "secret_pass": "your_secret"
  }
}
```

## 📊 Performance Monitoring

### 1. Response Time Monitoring

```bash
# Ortalama response time ölçümü
for i in {1..10}; do
  curl -o /dev/null -s -w "%{time_total}\n" \
    "https://your-domain.com/wp-json/seokiller/v1/debug"
done | awk '{sum+=$1} END {print "Average: " sum/NR " seconds"}'
```

### 2. Concurrent Request Test

```bash
# 5 concurrent request test
for i in {1..5}; do
  curl -X GET "https://your-domain.com/wp-json/seokiller/v1/openai-test" \
    -H "Origin: https://chat.openai.com" &
done
wait
```

### 3. Memory Usage

```bash
# PHP memory usage monitoring
tail -f /path/to/wp-content/debug.log | grep "memory"
```

## ✅ Başarı Kontrol Listesi

- [ ] Plugin v1.2.0+ yüklü ve aktif
- [ ] SSL sertifikası geçerli
- [ ] CORS headers doğru ayarlanmış
- [ ] `/debug` endpoint 200 OK döndürüyor
- [ ] `/openai-test` endpoint OpenAI isteğini tespit ediyor
- [ ] OPTIONS preflight request başarılı
- [ ] Authentication çalışıyor
- [ ] Rate limiting uygun şekilde ayarlanmış
- [ ] Log dosyaları yazılıyor
- [ ] OpenAI Actions'da schema import edildi
- [ ] OpenAI Actions authentication ayarlandı

## 🎯 OpenAI GPT Test Senaryosu

OpenAI GPT'nize şu prompt'u vererek test edin:

```
"SEOKILLER ACTION eklentisini test etmek istiyorum. 
Önce bağlantı durumunu kontrol et, sonra örnek bir site bilgisi al.
Site URL: https://test-site.com
Secret: test123"
```

**Beklenen Davranış:**
1. GPT önce `/openai-test` endpoint'ini çağırmalı
2. Sonra `/get-site-info` endpoint'ini çağırmalı
3. Başarılı response almalı veya detaylı hata mesajı vermeli

## 📞 Destek

Sorun yaşıyorsanız:

1. **Log Dosyalarını Kontrol Edin:** `wp-content/seokiller-openai.log`
2. **Debug Mode'u Açın:** `wp-config-openai.php` ayarları
3. **Test Endpoint'lerini Kullanın:** `/debug`, `/openai-test`, `/diagnostic`
4. **CORS Ayarlarını Doğrulayın:** Browser developer tools
5. **SSL Sertifikasını Kontrol Edin:** `curl -I https://domain.com`

## 🔄 Güncelleme Notları

### v1.2.0 Yenilikleri:
- ✅ OpenAI Actions tam uyumluluğu
- ✅ Geliştirilmiş CORS desteği
- ✅ Çoklu authentication header formatları
- ✅ Enhanced error responses
- ✅ OpenAI request detection
- ✅ Özel test endpoint'leri
- ✅ Detaylı debug logging
- ✅ Rate limiting optimizasyonları

Bu kılavuzu takip ederek SEOKILLER ACTION eklentinizi OpenAI Actions ile başarıyla entegre edebilirsiniz. 