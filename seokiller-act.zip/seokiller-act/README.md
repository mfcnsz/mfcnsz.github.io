# SEOKILLER ACTION Plugin

WordPress plugin that serves as a bridge between SEOKILLER GPT and client WordPress sites running the SEOKILLER WP plugin.

## Description

The SEOKILLER ACTION plugin enables SEOKILLER GPT to communicate with WordPress sites running the SEOKILLER WP plugin. It acts as a secure proxy server, authenticating requests from the GPT and forwarding them to client WordPress sites.

## Features

- **Dynamic API key authentication** - Generate and manage API keys from the admin panel
- REST API endpoints for content management
- **Admin interface for API key management** - Easy-to-use interface for viewing and regenerating API keys
- Rate limiting to prevent abuse
- Detailed logging of all API activities
- Support for WooCommerce products (if WooCommerce is active)
- **AJAX-powered API key generation** - Generate new keys without page reload

## Installation

1. Download the plugin zip file
2. Upload and install via the WordPress admin panel
3. Activate the plugin
4. Navigate to the **SEOKILLER ACTION** menu in WordPress admin to view and manage your API key

## API Key Management

### Viewing Your API Key

1. Go to WordPress Admin → SEOKILLER ACTION
2. Your current API key will be displayed in the "API Key Yönetimi" section
3. You can copy the key to use in SEOKILLER GPT

### Generating a New API Key

1. In the admin panel, click the "Yeni Key Oluştur" button
2. Confirm that you want to generate a new key (this will invalidate the old one)
3. The new key will be automatically generated and displayed
4. Update SEOKILLER GPT with the new key

### Testing Your API

Use the "API Test Et" button in the admin panel to verify that your API is working correctly.

## API Documentation

### Authentication

All API requests require an API key, which should be included in the `X-SEOKILLER-API-KEY` header.

Example:

```
X-SEOKILLER-API-KEY: your_api_key_here
```

**Note**: The API key is now dynamically generated and managed through the WordPress admin panel. No more hardcoded keys!

### Available Endpoints

#### Debug Endpoint

```
GET /wp-json/seokiller/v1/debug
```

Returns API status information and version details. No authentication required.

#### Site Info

```
POST /wp-json/seokiller/v1/get-site-info
POST /wp-json/seokiller/v1/get-site-info-alt
```

Parameters:
- `site_url` (required): The URL of the client WordPress site
- `secret_pass` (required): The secret password configured on the client site

OR

- `site_auth` (required): Object containing `site_url` and `secret_pass`

#### Categories

```
POST /wp-json/seokiller/v1/get-categories
POST /wp-json/seokiller/v1/get-categories-alt
```

Parameters:
- `site_url` (required): The URL of the client WordPress site
- `secret_pass` (required): The secret password configured on the client site

OR

- `site_auth` (required): Object containing `site_url` and `secret_pass`

#### Authors

```
POST /wp-json/seokiller/v1/get-authors
POST /wp-json/seokiller/v1/get-authors-alt
```

Parameters:
- `site_url` (required): The URL of the client WordPress site
- `secret_pass` (required): The secret password configured on the client site

OR

- `site_auth` (required): Object containing `site_url` and `secret_pass`

#### Posts

```
POST /wp-json/seokiller/v1/get-posts
POST /wp-json/seokiller/v1/get-posts-alt
```

Parameters:
- `site_url` (required): The URL of the client WordPress site
- `secret_pass` (required): The secret password configured on the client site
- Additional parameters will be forwarded to the client site

OR

- `site_auth` (required): Object containing `site_url` and `secret_pass`

#### Single Post

```
POST /wp-json/seokiller/v1/get-post/{postId}
POST /wp-json/seokiller/v1/get-post-alt/{postId}
```

Parameters:
- `site_url` (required): The URL of the client WordPress site
- `secret_pass` (required): The secret password configured on the client site
- `postId` (required): Post ID in URL path

#### Create Content

```
POST /wp-json/seokiller/v1/create-content
POST /wp-json/seokiller/v1/create-content-alt
```

Parameters:
- `site_url` (required): The URL of the client WordPress site
- `secret_pass` (required): The secret password configured on the client site
- `title` (required): Post title
- `content` (required): Post content
- Additional parameters as needed

OR use the nested format:
```json
{
  "site_auth": {
    "site_url": "https://example.com",
    "secret_pass": "your_secret_password"
  },
  "title": "Post Title",
  "content": "Post content",
  ...other parameters
}
```

#### Update Content

```
POST /wp-json/seokiller/v1/update-content/{postId}
POST /wp-json/seokiller/v1/update-content-alt/{postId}
```

Parameters:
- `site_url` (required): The URL of the client WordPress site
- `secret_pass` (required): The secret password configured on the client site
- `postId` (required): Post ID in URL path
- Content fields to update

#### Delete Post

```
POST /wp-json/seokiller/v1/delete-post/{postId}
POST /wp-json/seokiller/v1/delete-post-alt/{postId}
```

Parameters:
- `site_url` (required): The URL of the client WordPress site
- `secret_pass` (required): The secret password configured on the client site
- `postId` (required): Post ID in URL path

#### WooCommerce Products

```
POST /wp-json/seokiller/v1/get-products
POST /wp-json/seokiller/v1/get-products-alt
POST /wp-json/seokiller/v1/create-product
POST /wp-json/seokiller/v1/create-product-alt
POST /wp-json/seokiller/v1/update-product/{productId}
POST /wp-json/seokiller/v1/update-product-alt/{productId}
POST /wp-json/seokiller/v1/delete-product/{productId}
POST /wp-json/seokiller/v1/delete-product-alt/{productId}
```

All WooCommerce endpoints require the same authentication parameters as above.

### Example Usage

```bash
curl -X POST https://your-site.com/wp-json/seokiller/v1/get-site-info \
  -H "Content-Type: application/json" \
  -H "X-SEOKILLER-API-KEY: your_dynamic_api_key_here" \
  -d '{
    "site_auth": {
      "site_url": "https://client-site.com",
      "secret_pass": "client_secret_password"
    }
  }'
```

## Troubleshooting

### Common Issues

#### "api_key_missing" or "api_key_invalid" Error

If you receive authentication errors:

1. Go to WordPress Admin → SEOKILLER ACTION
2. Copy your current API key
3. Ensure you're using the correct API key in your requests
4. If issues persist, generate a new API key using the "Yeni Key Oluştur" button

#### "api_key_not_configured" Error

This error indicates that no API key has been generated yet:

1. Go to WordPress Admin → SEOKILLER ACTION
2. The plugin should automatically generate an API key
3. If not, try deactivating and reactivating the plugin

#### "missing_required_params" Error

If you receive an error about missing site_url or secret_pass parameters, check that:

1. Your request includes either:
   - Both `site_url` and `secret_pass` parameters directly in the request body
   - OR a `site_auth` object containing both `site_url` and `secret_pass`

2. Content-Type header is properly set:
   - Ensure your request has `Content-Type: application/json` header

3. Request body format:
   - Double-check your JSON format for proper structure 
   - Validate your JSON syntax with a JSON validator tool

#### Debug Mode

To enable debug mode for troubleshooting, add these lines to your wp-config.php:

```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

Debug logs will be created in the wp-content directory.

## Parameter Formats

The plugin accepts parameters in two formats:

### Format 1: Direct parameters
```json
{
  "site_url": "https://example.com",
  "secret_pass": "your_secret_password",
  ... additional parameters ...
}
```

### Format 2: Nested site_auth
```json
{
  "site_auth": {
    "site_url": "https://example.com",
    "secret_pass": "your_secret_password"
  },
  ... additional parameters ...
}
```

## Admin Interface Features

- **Real-time API key generation**: Generate new keys without page reload
- **API testing**: Built-in button to test your API connection
- **Endpoint documentation**: View all available endpoints directly in the admin
- **Security**: Nonce-protected forms and capability checks

## Requirements

- WordPress 5.0 or higher
- PHP 7.0 or higher

## License

This plugin is licensed under the GPL-2.0+ license.

## Support

For support inquiries, please contact support@seokiller.net. 