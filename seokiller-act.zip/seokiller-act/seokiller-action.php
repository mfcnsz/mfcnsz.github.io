<?php
/**
 * Plugin Name: SEOKILLER ACTION
 * Plugin URI: https://seokiller.net/
 * Description: WordPress Multi-Site Content Management API Gateway with OpenAI Actions Support - Action gateway for SEOKILLER GPT to communicate with WordPress sites running SEOKILLER WP plugin
 * Version: 1.2.0
 * Author: SEOKILLER
 * Author URI: https://seokiller.net/
 * License: GPL-2.0+
 * Text Domain: seokiller-action
 * Domain Path: /languages
 * OpenAI Compatible: Yes
 * Requires at least: 5.0
 * Tested up to: 6.3
 * Requires PHP: 7.4
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('SEOKILLER_ACTION_VERSION', '1.2.0');
define('SEOKILLER_ACTION_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SEOKILLER_ACTION_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once SEOKILLER_ACTION_PLUGIN_DIR . 'includes/class-seokiller-action-utils.php';

// === Enhanced OpenAI Actions CORS Support ===
// Early CORS headers for all requests
add_action('init', 'seokiller_add_early_cors_headers', 1);

function seokiller_add_early_cors_headers() {
    // Only add CORS headers for our API endpoints
    if (strpos($_SERVER['REQUEST_URI'], '/wp-json/seokiller/v1/') !== false) {
        $allowed_origins = seokiller_get_allowed_origins();
        
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
        
        if (in_array($origin, $allowed_origins)) {
            header("Access-Control-Allow-Origin: " . $origin);
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
            header("Access-Control-Allow-Headers: Content-Type, X-SEOKILLER-API-KEY, Authorization");
            header("Access-Control-Allow-Credentials: true");
            header("Access-Control-Max-Age: 86400"); // 24 hours cache for preflight
        }
        
        // Handle preflight OPTIONS request
        if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
            header("HTTP/1.1 200 OK");
            exit();
        }
    }
}

// Get allowed origins (configurable via admin)
function seokiller_get_allowed_origins() {
    $default_origins = array(
        'https://chat.openai.com',
        'https://chatgpt.com'
    );
    
    // Check if custom origins are configured
    $custom_origins = get_option('seokiller_cors_origins', '');
    if (!empty($custom_origins)) {
        $origins = explode("\n", $custom_origins);
        $origins = array_map('trim', $origins);
        $origins = array_filter($origins); // Remove empty lines
        return array_merge($default_origins, $origins);
    }
    
    return $default_origins;
}

// REST API specific CORS support
add_action('rest_api_init', 'seokiller_add_cors_support', 0);

function seokiller_add_cors_support() {
    // Add CORS headers to all REST API responses
    add_filter('rest_pre_serve_request', 'seokiller_add_cors_headers', 10, 4);
}

function seokiller_add_cors_headers($served, $result, $request, $server) {
    // Only for our endpoints
    if (strpos($request->get_route(), '/seokiller/v1/') !== false) {
        $allowed_origins = seokiller_get_allowed_origins();
        
        $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
        
        if (in_array($origin, $allowed_origins)) {
            header("Access-Control-Allow-Origin: " . $origin);
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
            header("Access-Control-Allow-Headers: Content-Type, X-SEOKILLER-API-KEY, Authorization, X-Requested-With");
            header("Access-Control-Allow-Credentials: true");
        }
    }
    
    return $served;
}

// === OpenAI Request Detection ===
add_filter('rest_pre_dispatch', 'seokiller_check_openai_request', 10, 3);

function seokiller_check_openai_request($result, $server, $request) {
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
    $referer = $_SERVER['HTTP_REFERER'] ?? '';
    
    // Enhanced OpenAI detection with multiple patterns
    $is_openai = false;
    
    // Check User-Agent patterns
    if (stripos($user_agent, 'ChatGPT') !== false || 
        stripos($user_agent, 'OpenAI') !== false ||
        stripos($user_agent, 'GPTBot') !== false) {
        $is_openai = true;
    }
    
    // Check Origin header for both domains
    if ($origin === 'https://chat.openai.com' || 
        $origin === 'https://chatgpt.com' ||
        stripos($origin, 'openai.com') !== false) {
        $is_openai = true;
    }
    
    // Check Referer header for both domains
    if (stripos($referer, 'chat.openai.com') !== false ||
        stripos($referer, 'chatgpt.com') !== false ||
        stripos($referer, 'openai.com') !== false) {
        $is_openai = true;
    }
    
    // Check for OpenAI-specific headers
    $headers = getallheaders();
    foreach ($headers as $name => $value) {
        if (stripos($name, 'openai') !== false || 
            stripos($value, 'openai') !== false ||
            stripos($value, 'chatgpt') !== false) {
            $is_openai = true;
            break;
        }
    }
    
    if ($is_openai) {
        // Enhanced logging for OpenAI requests
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('SEOKILLER: OpenAI Request Detected - Route: ' . $request->get_route());
            error_log('SEOKILLER: OpenAI User-Agent: ' . $user_agent);
            error_log('SEOKILLER: OpenAI Origin: ' . $origin);
            error_log('SEOKILLER: Request Method: ' . $request->get_method());
            
            // Log request body for debugging
            $body = $request->get_body();
            if (!empty($body)) {
                error_log('SEOKILLER: OpenAI Request Body: ' . $body);
            }
        }
        
        // Set higher rate limits for OpenAI
        add_filter('seokiller_rate_limit', function() {
            return 100; // Higher limit for OpenAI requests
        });
        
        // Mark request as OpenAI for special handling
        $GLOBALS['seokiller_openai_request'] = true;
        
        // Add OpenAI-specific error handling
        add_filter('rest_request_before_callbacks', function($response, $handler, $request) {
            if (isset($GLOBALS['seokiller_openai_request']) && $GLOBALS['seokiller_openai_request']) {
                // Ensure proper error formatting for OpenAI
                add_filter('rest_prepare_error', function($data, $error) {
                    if (is_wp_error($error)) {
                        return array(
                            'error' => array(
                                'code' => $error->get_error_code(),
                                'message' => $error->get_error_message(),
                                'data' => $error->get_error_data(),
                                'openai_compatible' => true
                            )
                        );
                    }
                    return $data;
                }, 10, 2);
            }
            return $response;
        }, 10, 3);
    }
    
    return $result;
}

// === Enhanced Debug Logging for OpenAI ===
if (defined('WP_DEBUG') && WP_DEBUG) {
    add_action('rest_api_init', function() {
        // Create OpenAI-specific log if requested
        if (defined('SEOKILLER_LOG_OPENAI') && SEOKILLER_LOG_OPENAI) {
            $log_file = WP_CONTENT_DIR . '/seokiller-openai.log';
            $log_data = date('Y-m-d H:i:s') . ' - ';
            $log_data .= $_SERVER['REQUEST_METHOD'] . ' ';
            $log_data .= $_SERVER['REQUEST_URI'] . "\n";
            $log_data .= 'Headers: ' . print_r(getallheaders(), true) . "\n";
            $log_data .= 'Body: ' . file_get_contents('php://input') . "\n\n";
            file_put_contents($log_file, $log_data, FILE_APPEND | LOCK_EX);
        }
    });
}

/**
 * The core plugin class
 */
class SEOKILLER_Action {
    
    /**
     * The single instance of the class
     */
    protected static $_instance = null;
    
    /**
     * API key option name in the database
     */
    private $api_key_option = 'seokiller_action_api_key';
    
    /**
     * Admin password option name in the database
     */
    private $admin_password_option = 'seokiller_action_admin_password';
    
    /**
     * Ensures only one instance is loaded or can be loaded
     */
    public static function get_instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }
    
    /**
     * Constructor
     */
    public function __construct() {
        // Initialize API if API key exists, generate one if it doesn't
        $this->ensure_api_key_exists();
        
        // Initialize admin password if it doesn't exist
        if (!get_option($this->admin_password_option)) {
            $this->set_default_admin_password();
        }
        
        // Register admin menu - hook into admin_menu action
        add_action('admin_menu', array($this, 'register_admin_menu'));
        
        // Register REST API endpoints
        add_action('rest_api_init', array($this, 'register_rest_routes'));
        
        // Admin form processing
        add_action('admin_post_seokiller_save_settings', array($this, 'save_settings'));
        
        // AJAX handlers
        add_action('wp_ajax_seokiller_generate_new_key', array($this, 'ajax_generate_new_key'));
        
        // Register plugin activation hook
        register_activation_hook(__FILE__, array($this, 'activation'));
        
        // Register plugin deactivation hook
        register_deactivation_hook(__FILE__, array($this, 'deactivation'));
    }
    
    /**
     * Ensure API key exists
     */
    private function ensure_api_key_exists() {
        $api_key = get_option($this->api_key_option, '');
        if (empty($api_key)) {
            $api_key = $this->generate_api_key();
        }
    }
    
    /**
     * Generate API key
     */
    public function generate_api_key() {
        $api_key = wp_generate_password(32, false);
        update_option($this->api_key_option, $api_key);
        
        // Log API key generation
        if (class_exists('SEOKILLER_Action_Utils')) {
            SEOKILLER_Action_Utils::log('New API key generated', 'info');
        }
        
        return $api_key;
    }
    
    /**
     * Get current API key
     */
    public function get_api_key() {
        return get_option($this->api_key_option, '');
    }
    
    /**
     * Debug log helper function
     */
    private function debug_log($message, $data = null) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('SEOKILLER: ' . $message . ($data !== null ? ' - ' . json_encode($data) : ''));
        }
    }
    
    /**
     * Debug incoming request details
     */
    private function debug_request($request, $endpoint = '') {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('==================== SEOKILLER REQUEST DEBUG ====================');
            error_log('ENDPOINT: ' . $endpoint);
            
            // Log headers
            $headers = $request->get_headers();
            error_log('HEADERS: ' . json_encode($headers));
            
            // Log method
            error_log('METHOD: ' . $request->get_method());
            
            // Log URL parameters
            error_log('URL PARAMS: ' . json_encode($request->get_params()));
            
            // Log JSON body
            $json_params = $request->get_json_params();
            error_log('JSON BODY: ' . json_encode($json_params));
            
            // Log raw body content
            $body = $request->get_body();
            error_log('RAW BODY: ' . $body);
            
            error_log('===============================================================');
        }
    }
    
    /**
     * Plugin activation
     */
    public function activation() {
        // Ensure API key is generated on activation
        $this->ensure_api_key_exists();
        
        // Set default admin password if it doesn't exist
        if (!get_option($this->admin_password_option)) {
            $this->set_default_admin_password();
        }
        
        // Create custom capability for plugin management
        $role = get_role('administrator');
        if ($role) {
            $role->add_cap('manage_options'); // Standard capability for administrator
        }
        
        // Initialize logging
        if (class_exists('SEOKILLER_Action_Utils')) {
            SEOKILLER_Action_Utils::init_logger();
            SEOKILLER_Action_Utils::log('SEOKILLER ACTION plugin activated', 'info');
        }
        
        // Flush rewrite rules to register REST API endpoints
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivation() {
        // Log deactivation
        if (class_exists('SEOKILLER_Action_Utils')) {
            SEOKILLER_Action_Utils::log('SEOKILLER ACTION plugin deactivated', 'info');
        }
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Set default admin password
     */
    private function set_default_admin_password() {
        $default_password = bin2hex(random_bytes(8)); // 16 characters
        update_option($this->admin_password_option, wp_hash_password($default_password));
        
        // Log password generation
        if (class_exists('SEOKILLER_Action_Utils')) {
            SEOKILLER_Action_Utils::log('Default admin password set', 'info');
        }
        
        return $default_password;
    }
    
    /**
     * Register admin menu
     */
    public function register_admin_menu() {
        add_menu_page(
            'SEOKILLER ACTION', // Page title
            'SEOKILLER ACTION', // Menu title
            'manage_options',   // Capability - changed to standard WordPress capability
            'seokiller-action', // Menu slug
            array($this, 'display_admin_page'), // Function to render the admin page
            'dashicons-randomize', // Icon
            30 // Position
        );
    }
    
    /**
     * Display admin page
     */
    public function display_admin_page() {
        $current_api_key = $this->get_api_key();
        
        // Form processing messages
        if (isset($_GET['settings-updated']) && $_GET['settings-updated'] == 'true') {
            echo '<div class="notice notice-success is-dismissible"><p>Ayarlar kaydedildi!</p></div>';
        }
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <div class="card">
                <h2>API Key Yönetimi</h2>
                <p>SEOKILLER GPT'nin bu API ile bağlantı kurması için aşağıdaki API key'i kullanın:</p>
                
                <form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
                    <?php wp_nonce_field('seokiller_settings_nonce', 'seokiller_nonce'); ?>
                    <input type="hidden" name="action" value="seokiller_save_settings" />
                    
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="seokiller_api_key">API Key</label>
                            </th>
                            <td>
                                <input type="text" 
                                       id="seokiller_api_key" 
                                       name="seokiller_api_key" 
                                       value="<?php echo esc_attr($current_api_key); ?>" 
                                       class="regular-text" />
                                <p class="description">
                                    Bu API key'i SEOKILLER GPT'de kullanın. 
                                    <button type="button" id="generate-new-key" class="button">Yeni Key Oluştur</button>
                                </p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="seokiller_cors_origins">CORS İzin Verilen Kaynaklar</label>
                            </th>
                            <td>
                                <textarea id="seokiller_cors_origins" 
                                          name="seokiller_cors_origins" 
                                          rows="5" 
                                          class="large-text"><?php 
                                    $default_origins = "https://chat.openai.com\nhttps://chatgpt.com";
                                    $origins = get_option('seokiller_cors_origins', $default_origins);
                                    echo esc_textarea($origins); 
                                ?></textarea>
                                <p class="description">
                                    API'ye erişim izni verilecek domain'leri girin (her satıra bir tane).<br>
                                    Varsayılan olarak OpenAI domain'leri dahildir.<br>
                                    Örnek: https://example.com
                                </p>
                            </td>
                        </tr>
                    </table>
                    
                    <?php submit_button('Ayarları Kaydet'); ?>
                </form>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h2>API Test</h2>
                <p>API bağlantınızı test edin:</p>
                <a href="<?php echo esc_url(site_url('/wp-json/seokiller/v1/debug')); ?>" 
                   target="_blank" 
                   class="button button-primary">API Test Et</a>
            </div>
            
            <div class="card" style="margin-top: 20px;">
                <h2>Endpoint Listesi</h2>
                <p>Mevcut API endpoint'leri:</p>
                <ul>
                    <li><strong>Debug:</strong> <code>GET /wp-json/seokiller/v1/debug</code></li>
                    <li><strong>Site Bilgisi:</strong> <code>POST /wp-json/seokiller/v1/get-site-info</code></li>
                    <li><strong>Site Bilgisi (Alt):</strong> <code>POST /wp-json/seokiller/v1/get-site-info-alt</code></li>
                    <li><strong>Kategoriler:</strong> <code>POST /wp-json/seokiller/v1/get-categories</code></li>
                    <li><strong>Kategoriler (Alt):</strong> <code>POST /wp-json/seokiller/v1/get-categories-alt</code></li>
                    <li><strong>Yazarlar:</strong> <code>POST /wp-json/seokiller/v1/get-authors</code></li>
                    <li><strong>Yazarlar (Alt):</strong> <code>POST /wp-json/seokiller/v1/get-authors-alt</code></li>
                    <li><strong>Yazılar:</strong> <code>POST /wp-json/seokiller/v1/get-posts</code></li>
                    <li><strong>Yazılar (Alt):</strong> <code>POST /wp-json/seokiller/v1/get-posts-alt</code></li>
                    <li><strong>Tek Yazı:</strong> <code>POST /wp-json/seokiller/v1/get-post/{id}</code></li>
                    <li><strong>Tek Yazı (Alt):</strong> <code>POST /wp-json/seokiller/v1/get-post-alt/{id}</code></li>
                    <li><strong>İçerik Oluştur:</strong> <code>POST /wp-json/seokiller/v1/create-content</code></li>
                    <li><strong>İçerik Oluştur (Alt):</strong> <code>POST /wp-json/seokiller/v1/create-content-alt</code></li>
                    <li><strong>İçerik Güncelle:</strong> <code>POST /wp-json/seokiller/v1/update-content/{id}</code></li>
                    <li><strong>İçerik Güncelle (Alt):</strong> <code>POST /wp-json/seokiller/v1/update-content-alt/{id}</code></li>
                    <li><strong>Yazı Sil:</strong> <code>POST /wp-json/seokiller/v1/delete-post/{id}</code></li>
                    <li><strong>Yazı Sil (Alt):</strong> <code>POST /wp-json/seokiller/v1/delete-post-alt/{id}</code></li>
                    
                    <!-- WooCommerce Endpoints -->
                    <li style="margin-top: 15px;"><strong style="color: #0073aa;">WooCommerce Endpoint'leri:</strong>
                        <?php if (!$this->is_woocommerce_active()): ?>
                        <span style="color: #d63638; font-size: 12px;">(WooCommerce gereklidir)</span>
                        <?php endif; ?>
                    </li>
                    <li><strong>Ürünler:</strong> <code>POST /wp-json/seokiller/v1/get-products</code></li>
                    <li><strong>Ürünler (Alt):</strong> <code>POST /wp-json/seokiller/v1/get-products-alt</code></li>
                    <li><strong>Tek Ürün:</strong> <code>POST /wp-json/seokiller/v1/get-product/{id}</code></li>
                    <li><strong>Ürün Oluştur:</strong> <code>POST /wp-json/seokiller/v1/create-product</code></li>
                    <li><strong>Ürün Oluştur (Alt):</strong> <code>POST /wp-json/seokiller/v1/create-product-alt</code></li>
                    <li><strong>Ürün Güncelle:</strong> <code>POST /wp-json/seokiller/v1/update-product/{id}</code></li>
                    <li><strong>Ürün Güncelle (Alt):</strong> <code>POST /wp-json/seokiller/v1/update-product-alt/{id}</code></li>
                    <li><strong>Ürün Sil:</strong> <code>POST /wp-json/seokiller/v1/delete-product/{id}</code></li>
                    <li><strong>Ürün Sil (Alt):</strong> <code>POST /wp-json/seokiller/v1/delete-product-alt/{id}</code></li>
                    
                    <!-- Test/Debug Endpoints -->
                    <li style="margin-top: 15px;"><strong style="color: #0073aa;">Test & Debug Endpoint'leri:</strong></li>
                    <li><strong>Tanılama:</strong> <code>POST /wp-json/seokiller/v1/diagnostic</code></li>
                    <li><strong>JSON Test:</strong> <code>POST /wp-json/seokiller/v1/json-test</code></li>
                    <li><strong>OpenAI Test:</strong> <code>GET/POST/OPTIONS /wp-json/seokiller/v1/openai-test</code></li>
                </ul>
            </div>
        </div>
        
        <script>
        jQuery(document).ready(function($) {
            $('#generate-new-key').on('click', function() {
                if (confirm('Yeni API key oluşturulacak. Mevcut key geçersiz hale gelecek. Devam edilsin mi?')) {
                    // AJAX ile yeni key oluştur
                    $.post(ajaxurl, {
                        action: 'seokiller_generate_new_key',
                        nonce: '<?php echo wp_create_nonce('seokiller_generate_key'); ?>'
                    }, function(response) {
                        if (response.success) {
                            $('#seokiller_api_key').val(response.data.api_key);
                            alert('Yeni API key oluşturuldu!');
                        } else {
                            alert('Hata: ' + response.data.message);
                        }
                    });
                }
            });
        });
        </script>
        <style>
            .seokiller-action-admin .card {
                padding: 20px;
                background: #fff;
                border: 1px solid #ccd0d4;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
                margin-bottom: 20px;
            }
            
            .card {
                padding: 15px;
                background: #fff;
                border: 1px solid #ccd0d4;
                box-shadow: 0 1px 1px rgba(0,0,0,.04);
                margin-bottom: 20px;
            }
        </style>
        <?php
    }
    
    /**
     * Save settings
     */
    public function save_settings() {
        // Nonce check
        if (!wp_verify_nonce($_POST['seokiller_nonce'], 'seokiller_settings_nonce')) {
            wp_die('Güvenlik kontrolü başarısız');
        }
        
        // Permission check
        if (!current_user_can('manage_options')) {
            wp_die('Bu işlem için yetkiniz yok');
        }
        
        // Save API key
        if (isset($_POST['seokiller_api_key'])) {
            $api_key = sanitize_text_field($_POST['seokiller_api_key']);
            update_option($this->api_key_option, $api_key);
        }
        
        // Save CORS origins
        if (isset($_POST['seokiller_cors_origins'])) {
            $cors_origins = sanitize_textarea_field($_POST['seokiller_cors_origins']);
            update_option('seokiller_cors_origins', $cors_origins);
        }
        
        // Redirect back
        wp_redirect(add_query_arg('settings-updated', 'true', admin_url('admin.php?page=seokiller-action')));
        exit;
    }
    
    /**
     * AJAX handler to generate new API key
     */
    public function ajax_generate_new_key() {
        // Nonce check
        if (!wp_verify_nonce($_POST['nonce'], 'seokiller_generate_key')) {
            wp_send_json_error(array('message' => 'Güvenlik kontrolü başarısız'));
        }
        
        // Permission check
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Bu işlem için yetkiniz yok'));
        }
        
        // Generate new API key
        $new_api_key = $this->generate_api_key();
        
        wp_send_json_success(array('api_key' => $new_api_key));
    }
    
    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        // Register namespace
        $namespace = 'seokiller/v1';

        // Debug endpoint
        register_rest_route($namespace, '/debug', array(
            'methods' => 'GET',
            'callback' => function() {
                return rest_ensure_response(array(
                    'status' => 'success',
                    'message' => 'SEOKILLER ACTION API is working',
                    'time' => current_time('mysql'),
                    'version' => SEOKILLER_ACTION_VERSION,
                    'api_key' => substr($this->get_api_key(), 0, 5) . '...',
                    'php_version' => phpversion()
                ));
            },
            'permission_callback' => '__return_true'
        ));
        
        // Diagnostic endpoint - for troubleshooting
        register_rest_route($namespace, '/diagnostic', array(
            'methods' => 'POST',
            'callback' => array($this, 'diagnostic_endpoint'),
            'permission_callback' => '__return_true',
        ));
        
        // JSON test endpoint - for testing JSON parsing
        register_rest_route($namespace, '/json-test', array(
            'methods' => 'POST',
            'callback' => function($request) {
                $raw_data = file_get_contents('php://input');
                $decoded = json_decode($raw_data, true);
                $site_auth = isset($decoded['site_auth']) ? $decoded['site_auth'] : null;
                $site_url = isset($site_auth['site_url']) ? $site_auth['site_url'] : 'Not found';
                $secret_pass = isset($site_auth['secret_pass']) ? 'Present (length: ' . strlen($site_auth['secret_pass']) . ')' : 'Not found';
                
                return array(
                    'success' => true,
                    'raw_data_length' => strlen($raw_data),
                    'json_decode_result' => $decoded ? 'Success' : 'Failed',
                    'site_auth_found' => $site_auth ? 'Yes' : 'No',
                    'site_url' => $site_url,
                    'secret_pass' => $secret_pass,
                    'all_keys' => $decoded ? array_keys($decoded) : []
                );
            },
            'permission_callback' => '__return_true',
        ));
        
        // OpenAI test endpoint - special endpoint for OpenAI Actions testing
        register_rest_route($namespace, '/openai-test', array(
            'methods' => array('GET', 'POST', 'OPTIONS'),
            'callback' => function($request) {
                $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
                $origin = $_SERVER['HTTP_ORIGIN'] ?? 'none';
                $method = $_SERVER['REQUEST_METHOD'];
                $headers = function_exists('getallheaders') ? getallheaders() : $_SERVER;
                
                // Extract headers that OpenAI might send
                $openai_headers = array();
                foreach ($headers as $key => $value) {
                    if (stripos($key, 'openai') !== false || 
                        stripos($key, 'gpt') !== false ||
                        stripos($key, 'chatgpt') !== false ||
                        $key === 'X-SEOKILLER-API-KEY' ||
                        $key === 'Authorization') {
                        $openai_headers[$key] = $value;
                    }
                }
                
                return new WP_REST_Response(array(
                    'status' => 'success',
                    'message' => 'OpenAI Actions connection test successful',
                    'timestamp' => current_time('mysql'),
                    'server_info' => array(
                        'plugin_version' => SEOKILLER_ACTION_VERSION,
                        'wordpress_version' => get_bloginfo('version'),
                        'php_version' => phpversion()
                    ),
                    'request_info' => array(
                        'method' => $method,
                        'origin' => $origin,
                        'user_agent' => $user_agent,
                        'route' => $request->get_route(),
                        'is_openai_detected' => isset($GLOBALS['seokiller_openai_request'])
                    ),
                    'headers_analysis' => array(
                        'total_headers' => count($headers),
                        'openai_related_headers' => $openai_headers,
                        'cors_headers_present' => isset($headers['Access-Control-Allow-Origin'])
                    ),
                    'compatibility' => array(
                        'cors_enabled' => true,
                        'openai_compatible' => true,
                        'authentication_methods' => array(
                            'X-SEOKILLER-API-KEY',
                            'Authorization Bearer'
                        )
                    )
                ), 200);
            },
            'permission_callback' => '__return_true',
        ));

        // Define common schema properties
        $site_url_schema = array(
            'description' => 'Client WordPress site URL',
            'type'        => 'string',
            'format'      => 'uri',
            'required'    => true
        );

        $secret_pass_schema = array(
            'description' => 'Secret password for client site authentication',
            'type'        => 'string',
            'required'    => true
        );

        // Site info endpoint
        register_rest_route($namespace, '/get-site-info', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'get_site_info'),
            'permission_callback' => array($this, 'check_api_key'),
            'args'                => array(
                'site_url'    => $site_url_schema,
                'secret_pass' => $secret_pass_schema,
                'site_auth'   => array(
                    'description' => 'Site authentication information',
                    'type'        => 'object',
                    'properties'  => array(
                        'site_url'    => array(
                            'description' => 'Client WordPress site URL',
                            'type'        => 'string',
                            'format'      => 'uri'
                        ),
                        'secret_pass' => array(
                            'description' => 'Secret password for client site authentication',
                            'type'        => 'string'
                        )
                    )
                )
            )
        ));
        
        // Categories endpoint
        register_rest_route($namespace, '/get-categories', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'get_categories'),
            'permission_callback' => array($this, 'check_api_key'),
            'args'                => array(
                'site_url'    => $site_url_schema,
                'secret_pass' => $secret_pass_schema,
                'site_auth'   => array(
                    'description' => 'Site authentication information',
                    'type'        => 'object',
                    'properties'  => array(
                        'site_url'    => array(
                            'description' => 'Client WordPress site URL',
                            'type'        => 'string',
                            'format'      => 'uri'
                        ),
                        'secret_pass' => array(
                            'description' => 'Secret password for client site authentication',
                            'type'        => 'string'
                        )
                    )
                )
            )
        ));
        
        // Posts endpoint - Get all posts
        register_rest_route($namespace, '/get-posts', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'get_posts'),
            'permission_callback' => array($this, 'check_api_key'),
            'args'                => array(
                'site_url'    => $site_url_schema,
                'secret_pass' => $secret_pass_schema,
                'per_page'    => array(
                    'description' => 'Number of posts per page',
                    'type'        => 'integer',
                    'default'     => 10
                ),
                'page'        => array(
                    'description' => 'Page number',
                    'type'        => 'integer',
                    'default'     => 1
                ),
                'category'    => array(
                    'description' => 'Category ID to filter by',
                    'type'        => 'integer'
                ),
                'search'      => array(
                    'description' => 'Search term',
                    'type'        => 'string'
                ),
                'site_auth'   => array(
                    'description' => 'Site authentication information',
                    'type'        => 'object',
                    'properties'  => array(
                        'site_url'    => array(
                            'description' => 'Client WordPress site URL',
                            'type'        => 'string',
                            'format'      => 'uri'
                        ),
                        'secret_pass' => array(
                            'description' => 'Secret password for client site authentication',
                            'type'        => 'string'
                        )
                    )
                )
            )
        ));
        
        // Single post endpoint - Get single post
        register_rest_route($namespace, '/get-post/(?P<postId>\d+)', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'get_post'),
            'permission_callback' => array($this, 'check_api_key'),
            'args'                => array(
                'site_url'    => $site_url_schema,
                'secret_pass' => $secret_pass_schema,
                'postId'      => array(
                    'description' => 'Post ID',
                    'type'        => 'integer',
                    'required'    => true
                )
            )
        ));
        
        // Create content endpoint
        register_rest_route($namespace, '/create-content', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'create_content'),
            'permission_callback' => array($this, 'check_api_key'),
            'args'                => array(
                'site_url'    => $site_url_schema,
                'secret_pass' => $secret_pass_schema,
                'title'       => array(
                    'description' => 'Post title',
                    'type'        => 'string',
                    'required'    => true
                ),
                'content'     => array(
                    'description' => 'Post content',
                    'type'        => 'string',
                    'required'    => true
                ),
                'status'      => array(
                    'description' => 'Post status',
                    'type'        => 'string',
                    'enum'        => ['draft', 'publish', 'pending', 'future', 'private'],
                    'default'     => 'draft'
                ),
                'site_auth'   => array(
                    'description' => 'Site authentication information',
                    'type'        => 'object',
                    'properties'  => array(
                        'site_url'    => array(
                            'description' => 'Client WordPress site URL',
                            'type'        => 'string',
                            'format'      => 'uri'
                        ),
                        'secret_pass' => array(
                            'description' => 'Secret password for client site authentication',
                            'type'        => 'string'
                        )
                    )
                )
            )
        ));
        
        // Update content endpoint
        register_rest_route($namespace, '/update-content/(?P<postId>\d+)', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'update_content'),
            'permission_callback' => array($this, 'check_api_key'),
            'args'                => array(
                'site_url'    => $site_url_schema,
                'secret_pass' => $secret_pass_schema,
                'postId'      => array(
                    'description' => 'Post ID',
                    'type'        => 'integer',
                    'required'    => true
                )
            )
        ));
        
        // Delete post endpoint
        register_rest_route($namespace, '/delete-post/(?P<postId>\d+)', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'delete_post'),
            'permission_callback' => array($this, 'check_api_key'),
            'args'                => array(
                'site_url'    => $site_url_schema,
                'secret_pass' => $secret_pass_schema,
                'postId'      => array(
                    'description' => 'Post ID',
                    'type'        => 'integer',
                    'required'    => true
                ),
                'force'       => array(
                    'description' => 'Whether to bypass trash and force deletion',
                    'type'        => 'boolean',
                    'default'     => false
                )
            )
        ));
        
        // Authors endpoint
        register_rest_route($namespace, '/get-authors', array(
            'methods'             => 'POST',
            'callback'            => array($this, 'get_authors'),
            'permission_callback' => array($this, 'check_api_key'),
            'args'                => array(
                'site_url'    => $site_url_schema,
                'secret_pass' => $secret_pass_schema
            )
        ));
        
        // WooCommerce products endpoints (if WooCommerce is active)
        if ($this->is_woocommerce_active()) {
            // Get products
            register_rest_route($namespace, '/get-products', array(
                'methods'             => 'POST',
                'callback'            => array($this, 'get_products'),
                'permission_callback' => array($this, 'check_api_key'),
                'args'                => array(
                    'site_url'    => $site_url_schema,
                    'secret_pass' => $secret_pass_schema,
                    'per_page'    => array(
                        'description' => 'Number of products per page',
                        'type'        => 'integer',
                        'default'     => 10
                    ),
                    'page'        => array(
                        'description' => 'Page number',
                        'type'        => 'integer',
                        'default'     => 1
                    ),
                    'category'    => array(
                        'description' => 'Category ID to filter by',
                        'type'        => 'integer'
                    ),
                    'search'      => array(
                        'description' => 'Search term',
                        'type'        => 'string'
                    )
                )
            ));
            
            // Create product endpoint
            register_rest_route($namespace, '/create-product', array(
                'methods'             => 'POST',
                'callback'            => array($this, 'create_product'),
                'permission_callback' => array($this, 'check_api_key'),
                'args'                => array(
                    'site_url'    => $site_url_schema,
                    'secret_pass' => $secret_pass_schema,
                    'name'        => array(
                        'description' => 'Product name',
                        'type'        => 'string',
                        'required'    => true
                    ),
                    'type'        => array(
                        'description' => 'Product type',
                        'type'        => 'string',
                        'enum'        => ['simple', 'grouped', 'external', 'variable'],
                        'default'     => 'simple'
                    ),
                    'regular_price' => array(
                        'description' => 'Regular price',
                        'type'        => 'string'
                    ),
                    'description' => array(
                        'description' => 'Product description',
                        'type'        => 'string'
                    )
                )
            ));
            
            // Update product endpoint
            register_rest_route($namespace, '/update-product/(?P<productId>\d+)', array(
                'methods'             => 'POST',
                'callback'            => array($this, 'update_product'),
                'permission_callback' => array($this, 'check_api_key'),
                'args'                => array(
                    'site_url'    => $site_url_schema,
                    'secret_pass' => $secret_pass_schema,
                    'productId'   => array(
                        'description' => 'Product ID',
                        'type'        => 'integer',
                        'required'    => true,
                        'validate_callback' => function($param) {
                            return is_numeric($param);
                        }
                    )
                )
            ));
            
            // Delete product endpoint
            register_rest_route($namespace, '/delete-product/(?P<productId>\d+)', array(
                'methods'             => 'POST',
                'callback'            => array($this, 'delete_product'),
                'permission_callback' => array($this, 'check_api_key'),
                'args'                => array(
                    'site_url'    => $site_url_schema,
                    'secret_pass' => $secret_pass_schema,
                    'productId'   => array(
                        'description' => 'Product ID',
                        'type'        => 'integer',
                        'required'    => true,
                        'validate_callback' => function($param) {
                            return is_numeric($param);
                        }
                    )
                )
            ));

            // Get single product endpoint
            register_rest_route($namespace, '/get-product/(?P<productId>\d+)', array(
                'methods'             => 'POST',
                'callback'            => array($this, 'get_product'),
                'permission_callback' => array($this, 'check_api_key'),
                'args'                => array(
                    'site_url'    => $site_url_schema,
                    'secret_pass' => $secret_pass_schema,
                    'productId'   => array(
                        'description' => 'Product ID',
                        'type'        => 'integer',
                        'required'    => true,
                        'validate_callback' => function($param) {
                            return is_numeric($param);
                        }
                    )
                )
            ));
        }
        
        // Alternative endpoints for better OpenAI compatibility
        
        // Alternative content creation endpoint
        register_rest_route($namespace, '/create-content-alt', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_content_alt'),
            'permission_callback' => array($this, 'check_api_key'),
        ));

        // Alternative content update endpoint
        register_rest_route($namespace, '/update-content-alt/(?P<postId>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'update_content_alt'),
            'permission_callback' => array($this, 'check_api_key'),
            'args' => array(
                'postId' => array(
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ),
            ),
        ));

        // Alternative get categories endpoint
        register_rest_route($namespace, '/get-categories-alt', array(
            'methods' => 'POST',
            'callback' => array($this, 'get_categories_alt'),
            'permission_callback' => array($this, 'check_api_key'),
        ));

        // Alternative get authors endpoint
        register_rest_route($namespace, '/get-authors-alt', array(
            'methods' => 'POST',
            'callback' => array($this, 'get_authors_alt'),
            'permission_callback' => array($this, 'check_api_key'),
        ));

        // Alternative get posts endpoint
        register_rest_route($namespace, '/get-posts-alt', array(
            'methods' => 'POST',
            'callback' => array($this, 'get_posts_alt'),
            'permission_callback' => array($this, 'check_api_key'),
        ));

        // Alternative get single post endpoint
        register_rest_route($namespace, '/get-post-alt/(?P<postId>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'get_post_alt'),
            'permission_callback' => array($this, 'check_api_key'),
            'args' => array(
                'postId' => array(
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ),
            ),
        ));

        // Alternative delete post endpoint
        register_rest_route($namespace, '/delete-post-alt/(?P<postId>\d+)', array(
            'methods' => 'POST',
            'callback' => array($this, 'delete_post_alt'),
            'permission_callback' => array($this, 'check_api_key'),
            'args' => array(
                'postId' => array(
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ),
            ),
        ));

        // Alternative site info endpoint
        register_rest_route($namespace, '/get-site-info-alt', array(
            'methods' => 'POST',
            'callback' => array($this, 'get_site_info_alt'),
            'permission_callback' => array($this, 'check_api_key'),
        ));

        // Alternative WooCommerce endpoints
        if ($this->is_woocommerce_active()) {
            register_rest_route($namespace, '/get-products-alt', array(
                'methods' => 'POST',
                'callback' => array($this, 'get_products_alt'),
                'permission_callback' => array($this, 'check_api_key'),
            ));

            register_rest_route($namespace, '/create-product-alt', array(
                'methods' => 'POST',
                'callback' => array($this, 'create_product_alt'),
                'permission_callback' => array($this, 'check_api_key'),
            ));

            register_rest_route($namespace, '/update-product-alt/(?P<productId>\d+)', array(
                'methods' => 'POST',
                'callback' => array($this, 'update_product_alt'),
                'permission_callback' => array($this, 'check_api_key'),
                'args' => array(
                    'productId' => array(
                        'validate_callback' => function($param) {
                            return is_numeric($param);
                        }
                    ),
                ),
            ));

            register_rest_route($namespace, '/delete-product-alt/(?P<productId>\d+)', array(
                'methods' => 'POST',
                'callback' => array($this, 'delete_product_alt'),
                'permission_callback' => array($this, 'check_api_key'),
                'args' => array(
                    'productId' => array(
                        'validate_callback' => function($param) {
                            return is_numeric($param);
                        }
                    ),
                ),
            ));
        }
    }
    
    /**
     * Validate API key (now dynamic)
     */
    public function check_api_key($request) {
        // OPTIONS requests bypass authentication (for CORS preflight)
        if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
            return true;
        }
        
        // Debug and test endpoints bypass authentication
        $route = $request->get_route();
        if (strpos($route, '/debug') !== false || 
            strpos($route, '/diagnostic') !== false || 
            strpos($route, '/json-test') !== false ||
            strpos($route, '/openai-test') !== false) {
            return true;
        }
        
        // Try to get API key from multiple header formats
        $api_key = null;
        
        // Standard header (primary)
        if ($request->get_header('X-SEOKILLER-API-KEY')) {
            $api_key = $request->get_header('X-SEOKILLER-API-KEY');
        }
        // Lowercase version (fallback)
        elseif ($request->get_header('x-seokiller-api-key')) {
            $api_key = $request->get_header('x-seokiller-api-key');
        }
        // Authorization Bearer header (OpenAI style)
        elseif ($request->get_header('Authorization')) {
            $auth = $request->get_header('Authorization');
            if (strpos($auth, 'Bearer ') === 0) {
                $api_key = substr($auth, 7);
            }
        }
        // Try getting from $_SERVER directly (some proxy setups)
        elseif (isset($_SERVER['HTTP_X_SEOKILLER_API_KEY'])) {
            $api_key = $_SERVER['HTTP_X_SEOKILLER_API_KEY'];
        }
        
        $this->debug_log('API key check', [
            'header_found' => !empty($api_key) ? substr($api_key, 0, 5) . '...' : 'empty',
            'method' => $_SERVER['REQUEST_METHOD'],
            'route' => $route,
            'is_openai' => isset($GLOBALS['seokiller_openai_request'])
        ]);
        
        if (empty($api_key)) {
            error_log('SEOKILLER AUTH: API key is missing');
            
            // Enhanced error response for OpenAI Actions
            $error_response = new WP_Error(
                'api_key_missing',
                'API key is missing. Please provide X-SEOKILLER-API-KEY header.',
                array('status' => 401)
            );
            
            // Add detail field for OpenAI Actions compatibility
            if (isset($GLOBALS['seokiller_openai_request'])) {
                $error_response->add_data(array(
                    'detail' => 'Missing authentication header. Please add X-SEOKILLER-API-KEY to your request headers.',
                    'required_header' => 'X-SEOKILLER-API-KEY',
                    'openai_compatible' => true
                ));
            }
            
            return $error_response;
        }

        // Get the stored API key
        $correct_api_key = $this->get_api_key();
        
        if (empty($correct_api_key)) {
            error_log('SEOKILLER AUTH: No API key configured');
            return new WP_Error(
                'api_key_not_configured',
                'API key not configured on server',
                array('status' => 500)
            );
        }
        
        $this->debug_log('API key comparison', [
            'expected' => substr($correct_api_key, 0, 5) . '...',
            'received' => substr($api_key, 0, 5) . '...',
            'lengths_match' => strlen($api_key) === strlen($correct_api_key)
        ]);
        
        // Clean and compare API keys
        if (trim($api_key) !== trim($correct_api_key)) {
            error_log('SEOKILLER AUTH: Invalid API key provided');
            
            $error_response = new WP_Error(
                'api_key_invalid',
                'Invalid API key provided',
                array('status' => 401)
            );
            
            // Add detail field for OpenAI Actions compatibility
            if (isset($GLOBALS['seokiller_openai_request'])) {
                $error_response->add_data(array(
                    'detail' => 'The provided API key is not valid. Please check your API key and try again.',
                    'openai_compatible' => true
                ));
            }
            
            return $error_response;
        }

        // Log successful authentication
        error_log('SEOKILLER AUTH: API key validation successful' . 
                 (isset($GLOBALS['seokiller_openai_request']) ? ' (OpenAI Request)' : ''));
        
        return true;
    }
    
    /**
     * Check if WooCommerce is active
     */
    public function is_woocommerce_active() {
        return in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')));
    }
    
    /**
     * Forward request to client site
     */
    private function forward_request_to_client($site_url, $endpoint, $method, $data = null, $secret_pass = '') {
        if (empty($site_url)) {
            return new WP_Error(
                'seokiller_action_error',
                'Site URL is required',
                array('status' => 400)
            );
        }
        
        $url = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/' . $endpoint;
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass
        );
        
        $args = array(
            'method' => $method,
            'headers' => $headers,
            'timeout' => 45,
            'redirection' => 5,
            'sslverify' => false
        );
        
        // Handle GET requests differently than POST/PUT/DELETE
        if ($method === 'GET' && !is_null($data) && is_array($data)) {
            // For GET requests, add parameters to URL as query string
            $url = add_query_arg($data, $url);
        } elseif (!is_null($data)) {
            // For other methods, add parameters to request body
            $args['body'] = json_encode($data);
        }
        
        // Log outgoing request
        if (class_exists('SEOKILLER_Action_Utils')) {
            SEOKILLER_Action_Utils::log_api_request($site_url, $endpoint, $method, 0, $data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            if (class_exists('SEOKILLER_Action_Utils')) {
                SEOKILLER_Action_Utils::log("Error forwarding request to {$site_url}: {$error_message}", 'error');
            }
            return new WP_Error(
                'seokiller_action_error',
                "Error connecting to client site: {$error_message}",
                array('status' => 500)
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $status = wp_remote_retrieve_response_code($response);
        
        // Log response
        if (class_exists('SEOKILLER_Action_Utils')) {
            SEOKILLER_Action_Utils::log_api_request($site_url, $endpoint, $method, $status);
        }
        
        return array(
            'status' => $status,
            'body' => json_decode($body, true)
        );
    }

    /**
     * Validate and extract common parameters
     */
    private function validate_and_extract_params($request) {
        // Try to get parameters from JSON body first
        $json_params = $request->get_json_params();
        if (!empty($json_params) && isset($json_params['site_url']) && isset($json_params['secret_pass'])) {
            return array(
                'site_url' => esc_url_raw($json_params['site_url']),
                'secret_pass' => sanitize_text_field($json_params['secret_pass']),
                'params' => $json_params
            );
        }
        
        // Fallback to query parameters if JSON body doesn't have required fields
        $query_params = $request->get_params();
        if (isset($query_params['site_url']) && isset($query_params['secret_pass'])) {
            return array(
                'site_url' => esc_url_raw($query_params['site_url']),
                'secret_pass' => sanitize_text_field($query_params['secret_pass']),
                'params' => $query_params
            );
        }
        
        return new WP_Error(
            'seokiller_action_error',
            'Missing required parameters: site_url and secret_pass',
            array('status' => 400)
        );
    }

    /**
     * REST API Callbacks
     */
    
    // Site Info Endpoint
    public function get_site_info($request) {
        $this->debug_log('get_site_info called');
        $this->debug_request($request, 'get_site_info');
        
        // Try all possible ways to extract site credentials
        $credentials = $this->extract_all_possible_credentials($request);
        $site_url = $credentials['site_url'];
        $secret_pass = $credentials['secret_pass'];
        
        // For debugging purposes - log what we extracted
        $this->debug_log('Final credentials after all attempts', [
            'site_url' => $site_url, 
            'secret_pass_length' => !empty($secret_pass) ? strlen($secret_pass) : 0
        ]);
        
        // Gerekli parametreleri kontrol et
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            $this->debug_log('Missing credentials', $missing);
            
            return new WP_Error(
                'missing_required_params',
                'Missing required parameter(s): ' . implode(', ', $missing),
                array(
                    'status' => 400,
                    'params' => $missing
                )
            );
        }
        
        // WordPress sitesine istek gönder
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/site-info';
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        $this->debug_log('Sending request to', $client_endpoint);
        
        $response = wp_remote_get($client_endpoint, array(
            'headers' => $headers,
            'timeout' => 45,
        ));
        
        // İstek hatası kontrol et
        if (is_wp_error($response)) {
            $this->debug_log('WP request failed', $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        $this->debug_log('Response received', [
            'code' => $response_code,
            'body' => $response_body
        ]);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    // Get Posts Endpoint
    public function get_posts($request) {
        $this->debug_log('get_posts called');
        $this->debug_request($request, 'get_posts');
        
        // Try all possible ways to extract site credentials
        $credentials = $this->extract_all_possible_credentials($request);
        $site_url = $credentials['site_url'];
        $secret_pass = $credentials['secret_pass'];
        
        // Get JSON and URL parameters for this endpoint
        $json_params = $request->get_json_params();
        $url_params = $request->get_params();
        
        // For debugging purposes - log what we extracted
        $this->debug_log('Final credentials after all attempts', [
            'site_url' => $site_url, 
            'secret_pass_length' => !empty($secret_pass) ? strlen($secret_pass) : 0,
            'json_params' => $json_params,
            'url_params' => array_keys($url_params)
        ]);
        
        // Gerekli parametreleri kontrol et
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            $this->debug_log('Missing credentials', $missing);
            
            return SEOKILLER_Action_Utils::error_response(
                'Missing required parameter(s): ' . implode(', ', $missing),
                400,
                'missing_required_params'
            );
        }
        
        // Query parametrelerini hazırla - OpenAI Actions uyumlu
        $query_params = array();
        $allowed_params = array('per_page', 'page', 'category', 'search', 'status', 'order', 'orderby');
        
        // Önce JSON parametrelerini kontrol et (OpenAI Actions genelde bu şekilde gönderir)
        if (!empty($json_params)) {
            foreach ($allowed_params as $param) {
                if (isset($json_params[$param])) {
                    $query_params[$param] = sanitize_text_field($json_params[$param]);
                }
            }
        }
        
        // Sonra URL parametrelerini kontrol et
        foreach ($allowed_params as $param) {
            if (isset($url_params[$param]) && !isset($query_params[$param])) {
                $query_params[$param] = sanitize_text_field($url_params[$param]);
            }
        }
        
        $this->debug_log('Query params prepared', $query_params);
        
        // WordPress sitesine istek gönder
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/posts';
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        // GET parametreleri URL'e ekle
        if (!empty($query_params)) {
            $client_endpoint = add_query_arg($query_params, $client_endpoint);
        }
        
        $this->debug_log('Sending request to', $client_endpoint);
        
        $response = wp_remote_get($client_endpoint, array(
            'headers' => $headers,
            'timeout' => 45,
        ));
        
        // İstek hatası kontrol et
        if (is_wp_error($response)) {
            $this->debug_log('WP request failed', $response->get_error_message());
            return SEOKILLER_Action_Utils::error_response(
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                500,
                'wp_request_failed'
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        $this->debug_log('Response received', [
            'code' => $response_code,
            'body' => $response_body
        ]);
        
        // OpenAI Actions için optimize edilmiş response
        if (isset($GLOBALS['seokiller_openai_request']) && $GLOBALS['seokiller_openai_request']) {
            return SEOKILLER_Action_Utils::openai_success_response(
                $response_body,
                'Posts retrieved successfully',
                array('total_found' => is_array($response_body) ? count($response_body) : 0)
            );
        }
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    // Get Single Post Endpoint
    public function get_post($request) {
        error_log('SEOKILLER GET_POST: get_post called');
        
        // JSON parametrelerini al
        $params = $request->get_json_params();
        if (empty($params)) {
            error_log('SEOKILLER GET_POST: Empty JSON params');
            $params = array();
        }
        
        $post_id = (int) $request['postId']; // From URL parameter
        error_log('SEOKILLER GET_POST: Post ID: ' . $post_id);
        
        // Site kimlik bilgilerini çıkar
        $credentials = $this->extract_site_credentials($params);
        $site_url = $credentials['site_url'];
        $secret_pass = $credentials['secret_pass'];
        
        // Gerekli parametreleri kontrol et
        if (empty($site_url) || empty($secret_pass)) {
            error_log('SEOKILLER GET_POST: Missing credentials');
            return new WP_Error(
                'missing_required_params',
                'Missing site URL or secret pass',
                array('status' => 400)
            );
        }
        
        if (empty($post_id)) {
            error_log('SEOKILLER GET_POST: Invalid post ID');
            return new WP_Error(
                'invalid_post_id',
                'Invalid post ID',
                array('status' => 400)
            );
        }
        
        // WordPress sitesine istek gönder
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/posts/' . $post_id;
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        error_log('SEOKILLER GET_POST: Sending request to: ' . $client_endpoint);
        
        $response = wp_remote_get($client_endpoint, array(
            'headers' => $headers,
            'timeout' => 45,
        ));
        
        // İstek hatası kontrol et
        if (is_wp_error($response)) {
            error_log('SEOKILLER GET_POST: WP request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('SEOKILLER GET_POST: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    // Create Content Endpoint
    public function create_content($request) {
        error_log('CREATE_CONTENT: Called');
        
        $raw_data = file_get_contents('php://input');
        $extracted = $this->extract_credentials($raw_data);
        
        if (isset($extracted['error'])) {
            return new WP_Error('invalid_json', $extracted['error'], array('status' => 400));
        }
        
        $site_url = $extracted['site_url'];
        $secret_pass = $extracted['secret_pass'];
        $params = $extracted['params'];
        
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            return new WP_Error(
                'missing_required_params',
                'Eksik parametre(ler): ' . implode(', ', $missing),
                array('status' => 400, 'params' => $missing)
            );
        }
        
        // Content data
        $content_data = array();
        foreach ($params as $key => $value) {
            if ($key !== 'site_auth' && $key !== 'site_url' && $key !== 'secret_pass') {
                $content_data[$key] = $value;
            }
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/create-content';
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        error_log('CREATE_CONTENT: Sending request to: ' . $client_endpoint);
        
        $response = wp_remote_post($client_endpoint, array(
            'headers' => $headers,
            'body' => json_encode($content_data),
            'timeout' => 45,
        ));
        
        if (is_wp_error($response)) {
            error_log('CREATE_CONTENT: Request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('CREATE_CONTENT: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    // Update Content Endpoint
    public function update_content($request) {
        error_log('SEOKILLER UPDATE: update_content called');
        
        // JSON parametrelerini al
        $params = $request->get_json_params();
        if (empty($params)) {
            error_log('SEOKILLER UPDATE: Empty JSON params');
            $params = array();
        }
        
        $post_id = (int) $request['postId']; // From URL parameter
        error_log('SEOKILLER UPDATE: Post ID: ' . $post_id);
        
        // Site kimlik bilgilerini çıkar
        $credentials = $this->extract_site_credentials($params);
        $site_url = $credentials['site_url'];
        $secret_pass = $credentials['secret_pass'];
        
        // Gerekli parametreleri kontrol et
        if (empty($site_url) || empty($secret_pass)) {
            error_log('SEOKILLER UPDATE: Missing credentials');
            return new WP_Error(
                'missing_required_params',
                'Missing site URL or secret pass',
                array('status' => 400)
            );
        }
        
        if (empty($post_id)) {
            error_log('SEOKILLER UPDATE: Invalid post ID');
            return new WP_Error(
                'invalid_post_id',
                'Invalid post ID',
                array('status' => 400)
            );
        }
        
        // Güncelleme verilerini hazırla
        $update_data = array();
        foreach ($params as $key => $value) {
            // site_auth hariç tüm parametreleri geçir
            if ($key !== 'site_auth' && $key !== 'site_url' && $key !== 'secret_pass') {
                $update_data[$key] = $value;
            }
        }
        
        // Boş güncellemeler kabul etme
        if (empty($update_data)) {
            error_log('SEOKILLER UPDATE: No update data provided');
            return new WP_Error(
                'no_update_data',
                'No content data provided for update',
                array('status' => 400)
            );
        }
        
        error_log('SEOKILLER UPDATE: Update data: ' . json_encode($update_data));
        
        // WordPress sitesine istek gönder
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/posts/' . $post_id;
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        error_log('SEOKILLER UPDATE: Sending request to: ' . $client_endpoint);
        
        $response = wp_remote_request($client_endpoint, array(
            'method' => 'PUT',
            'headers' => $headers,
            'body' => json_encode($update_data),
            'timeout' => 45,
        ));
        
        // İstek hatası kontrol et
        if (is_wp_error($response)) {
            error_log('SEOKILLER UPDATE: WP request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('SEOKILLER UPDATE: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    // Authors Endpoint
    public function get_authors($request) {
        $extracted = $this->validate_and_extract_params($request);
        if (is_wp_error($extracted)) {
            return $extracted;
        }
        
        return $this->forward_request_to_client(
            $extracted['site_url'],
            'authors',
            'GET',
            null,
            $extracted['secret_pass']
        );
    }
    
    // WooCommerce Endpoints
    public function get_products($request) {
        error_log('GET_PRODUCTS: Called');
        
        $raw_data = file_get_contents('php://input');
        $extracted = $this->extract_credentials($raw_data);
        
        if (isset($extracted['error'])) {
            return new WP_Error('invalid_json', $extracted['error'], array('status' => 400));
        }
        
        $site_url = $extracted['site_url'];
        $secret_pass = $extracted['secret_pass'];
        $params = $extracted['params'];
        
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            return new WP_Error(
                'missing_required_params',
                'Eksik parametre(ler): ' . implode(', ', $missing),
                array('status' => 400, 'params' => $missing)
            );
        }
        
        // Query parameters for pagination
        $query_params = array();
        if (isset($params['page'])) $query_params['page'] = $params['page'];
        if (isset($params['per_page'])) $query_params['per_page'] = $params['per_page'];
        if (isset($params['category_id'])) $query_params['category_id'] = $params['category_id'];
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products';
        if (!empty($query_params)) {
            $client_endpoint = add_query_arg($query_params, $client_endpoint);
        }
        
        $headers = array('X-SEOKILLER-SECRET' => $secret_pass);
        
        error_log('GET_PRODUCTS: Sending request to: ' . $client_endpoint);
        
        $response = wp_remote_get($client_endpoint, array(
            'headers' => $headers,
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('GET_PRODUCTS: Request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('GET_PRODUCTS: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    public function create_product($request) {
        error_log('CREATE_PRODUCT: Called');
        
        $raw_data = file_get_contents('php://input');
        $extracted = $this->extract_credentials($raw_data);
        
        if (isset($extracted['error'])) {
            return new WP_Error('invalid_json', $extracted['error'], array('status' => 400));
        }
        
        $site_url = $extracted['site_url'];
        $secret_pass = $extracted['secret_pass'];
        $params = $extracted['params'];
        
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            return new WP_Error(
                'missing_required_params',
                'Eksik parametre(ler): ' . implode(', ', $missing),
                array('status' => 400, 'params' => $missing)
            );
        }
        
        // Product data
        $product_data = array();
        foreach ($params as $key => $value) {
            if ($key !== 'site_auth' && $key !== 'site_url' && $key !== 'secret_pass') {
                $product_data[$key] = $value;
            }
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products';
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        error_log('CREATE_PRODUCT: Sending request to: ' . $client_endpoint);
        error_log('CREATE_PRODUCT: Product data: ' . json_encode($product_data));
        
        $response = wp_remote_post($client_endpoint, array(
            'headers' => $headers,
            'body' => json_encode($product_data),
            'timeout' => 45,
        ));
        
        if (is_wp_error($response)) {
            error_log('CREATE_PRODUCT: Request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('CREATE_PRODUCT: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    public function update_product($request) {
        error_log('UPDATE_PRODUCT: Called');
        
        $product_id = $request->get_param('productId');
        $raw_data = file_get_contents('php://input');
        $extracted = $this->extract_credentials($raw_data);
        
        if (isset($extracted['error'])) {
            return new WP_Error('invalid_json', $extracted['error'], array('status' => 400));
        }
        
        $site_url = $extracted['site_url'];
        $secret_pass = $extracted['secret_pass'];
        $params = $extracted['params'];
        
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            return new WP_Error(
                'missing_required_params',
                'Eksik parametre(ler): ' . implode(', ', $missing),
                array('status' => 400, 'params' => $missing)
            );
        }
        
        // Product data
        $product_data = array();
        foreach ($params as $key => $value) {
            if ($key !== 'site_auth' && $key !== 'site_url' && $key !== 'secret_pass') {
                $product_data[$key] = $value;
            }
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products/' . $product_id;
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        error_log('UPDATE_PRODUCT: Sending request to: ' . $client_endpoint);
        
        $response = wp_remote_request($client_endpoint, array(
            'method' => 'PUT',
            'headers' => $headers,
            'body' => json_encode($product_data),
            'timeout' => 45,
        ));
        
        if (is_wp_error($response)) {
            error_log('UPDATE_PRODUCT: Request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('UPDATE_PRODUCT: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    public function get_product($request) {
        error_log('GET_PRODUCT: Called');
        
        $product_id = $request->get_param('productId');
        $raw_data = file_get_contents('php://input');
        $extracted = $this->extract_credentials($raw_data);
        
        if (isset($extracted['error'])) {
            return new WP_Error('invalid_json', $extracted['error'], array('status' => 400));
        }
        
        $site_url = $extracted['site_url'];
        $secret_pass = $extracted['secret_pass'];
        
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            return new WP_Error(
                'missing_required_params',
                'Eksik parametre(ler): ' . implode(', ', $missing),
                array('status' => 400, 'params' => $missing)
            );
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products/' . $product_id;
        
        $headers = array('X-SEOKILLER-SECRET' => $secret_pass);
        
        error_log('GET_PRODUCT: Sending request to: ' . $client_endpoint);
        
        $response = wp_remote_get($client_endpoint, array(
            'headers' => $headers,
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('GET_PRODUCT: Request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('GET_PRODUCT: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }
    
    public function delete_product($request) {
        error_log('DELETE_PRODUCT: Called');
        
        $product_id = $request->get_param('productId');
        $raw_data = file_get_contents('php://input');
        $extracted = $this->extract_credentials($raw_data);
        
        if (isset($extracted['error'])) {
            return new WP_Error('invalid_json', $extracted['error'], array('status' => 400));
        }
        
        $site_url = $extracted['site_url'];
        $secret_pass = $extracted['secret_pass'];
        
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            return new WP_Error(
                'missing_required_params',
                'Eksik parametre(ler): ' . implode(', ', $missing),
                array('status' => 400, 'params' => $missing)
            );
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products/' . $product_id;
        
        $headers = array('X-SEOKILLER-SECRET' => $secret_pass);
        
        error_log('DELETE_PRODUCT: Sending request to: ' . $client_endpoint);
        
        $response = wp_remote_request($client_endpoint, array(
            'method' => 'DELETE',
            'headers' => $headers,
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('DELETE_PRODUCT: Request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('DELETE_PRODUCT: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }

    // Delete Post Endpoint
    public function delete_post($request) {
        error_log('SEOKILLER DELETE: delete_post called');
        
        // JSON parametrelerini al
        $params = $request->get_json_params();
        if (empty($params)) {
            error_log('SEOKILLER DELETE: Empty JSON params');
            $params = array();
        }
        
        $post_id = (int) $request['postId']; // From URL parameter
        error_log('SEOKILLER DELETE: Post ID: ' . $post_id);
        
        // Site kimlik bilgilerini çıkar
        $credentials = $this->extract_site_credentials($params);
        $site_url = $credentials['site_url'];
        $secret_pass = $credentials['secret_pass'];
        
        // Force parametresini kontrol et
        $force = isset($params['force']) ? (bool) $params['force'] : false;
        error_log('SEOKILLER DELETE: Force: ' . ($force ? 'true' : 'false'));
        
        // Gerekli parametreleri kontrol et
        if (empty($site_url) || empty($secret_pass)) {
            error_log('SEOKILLER DELETE: Missing credentials');
            return new WP_Error(
                'missing_required_params',
                'Missing site URL or secret pass',
                array('status' => 400)
            );
        }
        
        if (empty($post_id)) {
            error_log('SEOKILLER DELETE: Invalid post ID');
            return new WP_Error(
                'invalid_post_id',
                'Invalid post ID',
                array('status' => 400)
            );
        }
        
        // WordPress sitesine istek gönder
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/posts/' . $post_id;
        
        // Force parametresini URL'e ekle
        if ($force) {
            $client_endpoint = add_query_arg('force', 'true', $client_endpoint);
        }
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        error_log('SEOKILLER DELETE: Sending request to: ' . $client_endpoint);
        
        $response = wp_remote_request($client_endpoint, array(
            'method' => 'DELETE',
            'headers' => $headers,
            'timeout' => 45,
        ));
        
        // İstek hatası kontrol et
        if (is_wp_error($response)) {
            error_log('SEOKILLER DELETE: WP request failed: ' . $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('SEOKILLER DELETE: Response code: ' . $response_code);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }

    // Categories Endpoint
    public function get_categories($request) {
        $this->debug_log('get_categories called');
        $this->debug_request($request, 'get_categories');
        
        // Try all possible ways to extract site credentials
        $credentials = $this->extract_all_possible_credentials($request);
        $site_url = $credentials['site_url'];
        $secret_pass = $credentials['secret_pass'];
        
        // For debugging purposes - log what we extracted
        $this->debug_log('Final credentials after all attempts', [
            'site_url' => $site_url, 
            'secret_pass_length' => !empty($secret_pass) ? strlen($secret_pass) : 0
        ]);
        
        // Gerekli parametreleri kontrol et
        if (empty($site_url) || empty($secret_pass)) {
            $missing = [];
            if (empty($site_url)) $missing[] = 'site_url';
            if (empty($secret_pass)) $missing[] = 'secret_pass';
            
            $this->debug_log('Missing credentials', $missing);
            
            return new WP_Error(
                'missing_required_params',
                'Missing required parameter(s): ' . implode(', ', $missing),
                array(
                    'status' => 400,
                    'params' => $missing
                )
            );
        }
        
        // WordPress sitesine istek gönder
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/categories';
        
        $headers = array(
            'Content-Type' => 'application/json',
            'X-SEOKILLER-SECRET' => $secret_pass,
        );
        
        $this->debug_log('Sending request to', $client_endpoint);
        
        $response = wp_remote_get($client_endpoint, array(
            'headers' => $headers,
            'timeout' => 45,
        ));
        
        // İstek hatası kontrol et
        if (is_wp_error($response)) {
            $this->debug_log('WP request failed', $response->get_error_message());
            return new WP_Error(
                'wp_request_failed',
                'Failed to connect to the WordPress site: ' . $response->get_error_message(),
                array('status' => 500)
            );
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        $this->debug_log('Response received', [
            'code' => $response_code,
            'body' => $response_body
        ]);
        
        return rest_ensure_response(array(
            'status' => $response_code,
            'body' => $response_body
        ));
    }

    /**
     * Extract site credentials from request parameters
     * Handles both nested (site_auth.site_url) and flat (site_url) parameter structures
     * 
     * @param array $params Request parameters
     * @return array Site credentials (site_url and secret_pass)
     */
    private function extract_site_credentials($params) {
        // site_auth içinden veya doğrudan site_url/secret_pass
        $site_url = '';
        $secret_pass = '';
        
        $this->debug_log('Extracting site credentials', $params);
        
        if (isset($params['site_auth']) && is_array($params['site_auth'])) {
            $this->debug_log('Found site_auth format', $params['site_auth']);
            if (isset($params['site_auth']['site_url'])) {
                $site_url = $params['site_auth']['site_url'];
            }
            if (isset($params['site_auth']['secret_pass'])) {
                $secret_pass = $params['site_auth']['secret_pass'];
            }
        } else {
            $this->debug_log('Looking for direct parameters');
            if (isset($params['site_url'])) {
                $site_url = $params['site_url'];
            }
            if (isset($params['secret_pass'])) {
                $secret_pass = $params['secret_pass'];
            }
        }
        
        $this->debug_log('Extracted credentials', [
            'site_url' => $site_url, 
            'secret_pass_length' => !empty($secret_pass) ? strlen($secret_pass) : 0
        ]);
        
        return array(
            'site_url' => $site_url,
            'secret_pass' => $secret_pass
        );
    }

    /**
     * Helper function to get registered routes
     */
    private function get_registered_routes() {
        global $wp_rest_server;
        if (!$wp_rest_server) {
            return array();
        }
        return $wp_rest_server->get_routes();
    }

    /**
     * Extract credentials from all possible sources and formats
     * Enhanced for OpenAI Actions compatibility
     *
     * @param WP_REST_Request $request The request object
     * @return array Associative array with site_url and secret_pass
     */
    private function extract_all_possible_credentials($request) {
        $site_url = '';
        $secret_pass = '';
        
        // Enhanced debug logging for OpenAI requests
        $is_openai = isset($GLOBALS['seokiller_openai_request']);
        if ($is_openai) {
            $this->debug_log('OpenAI request detected - using enhanced credential extraction');
        }
        
        // Step 1: Try to extract from JSON body - multiple formats
        $json_params = $request->get_json_params();
        if (!empty($json_params)) {
            $this->debug_log('Checking JSON params for credentials', array_keys($json_params));
            
            // Check site_auth nested format (preferred)
            if (isset($json_params['site_auth']) && is_array($json_params['site_auth'])) {
                $this->debug_log('Found site_auth format in JSON');
                if (isset($json_params['site_auth']['site_url'])) {
                    $site_url = $json_params['site_auth']['site_url'];
                }
                if (isset($json_params['site_auth']['secret_pass'])) {
                    $secret_pass = $json_params['site_auth']['secret_pass'];
                }
            }
            
            // Check direct parameters in JSON (fallback)
            if (empty($site_url) && isset($json_params['site_url'])) {
                $site_url = $json_params['site_url'];
                $this->debug_log('Found site_url in direct JSON params');
            }
            if (empty($secret_pass) && isset($json_params['secret_pass'])) {
                $secret_pass = $json_params['secret_pass'];
                $this->debug_log('Found secret_pass in direct JSON params');
            }
        }
        
        // Step 2: Try raw body parsing if JSON params didn't work (OpenAI specific)
        if ((empty($site_url) || empty($secret_pass))) {
            $raw_body = $request->get_body();
            if (!empty($raw_body)) {
                $this->debug_log('Parsing raw body', ['length' => strlen($raw_body)]);
                
                // Try to decode as JSON
                $decoded = json_decode($raw_body, true);
                if ($decoded && is_array($decoded)) {
                    $this->debug_log('Successfully decoded raw body JSON', array_keys($decoded));
                    
                    // Check nested site_auth format
                    if (isset($decoded['site_auth']) && is_array($decoded['site_auth'])) {
                        if (empty($site_url) && isset($decoded['site_auth']['site_url'])) {
                            $site_url = $decoded['site_auth']['site_url'];
                            $this->debug_log('Found site_url in raw body site_auth');
                        }
                        if (empty($secret_pass) && isset($decoded['site_auth']['secret_pass'])) {
                            $secret_pass = $decoded['site_auth']['secret_pass'];
                            $this->debug_log('Found secret_pass in raw body site_auth');
                        }
                    }
                    
                    // Check direct parameters
                    if (empty($site_url) && isset($decoded['site_url'])) {
                        $site_url = $decoded['site_url'];
                        $this->debug_log('Found site_url in raw body direct');
                    }
                    if (empty($secret_pass) && isset($decoded['secret_pass'])) {
                        $secret_pass = $decoded['secret_pass'];
                        $this->debug_log('Found secret_pass in raw body direct');
                    }
                }
            }
        }
        
        // Step 3: Try URL parameters (for GET requests or mixed scenarios)
        if (empty($site_url) || empty($secret_pass)) {
            $url_params = $request->get_params();
            $this->debug_log('Checking URL parameters', array_keys($url_params));
            
            if (empty($site_url) && isset($url_params['site_url'])) {
                $site_url = $url_params['site_url'];
                $this->debug_log('Found site_url in URL parameters');
            }
            if (empty($secret_pass) && isset($url_params['secret_pass'])) {
                $secret_pass = $url_params['secret_pass'];
                $this->debug_log('Found secret_pass in URL parameters');
            }
            
            // Check for site_auth in URL parameters
            if ((empty($site_url) || empty($secret_pass)) && isset($url_params['site_auth'])) {
                $this->debug_log('Found site_auth in URL parameters');
                
                $site_auth = $url_params['site_auth'];
                if (is_string($site_auth)) {
                    $decoded = json_decode($site_auth, true);
                    if ($decoded && is_array($decoded)) {
                        $site_auth = $decoded;
                    }
                }
                
                if (is_array($site_auth)) {
                    if (empty($site_url) && isset($site_auth['site_url'])) {
                        $site_url = $site_auth['site_url'];
                    }
                    if (empty($secret_pass) && isset($site_auth['secret_pass'])) {
                        $secret_pass = $site_auth['secret_pass'];
                    }
                }
            }
        }
        
        // Step 4: Try form data parsing (additional fallback)
        if ((empty($site_url) || empty($secret_pass)) && !empty($request->get_body())) {
            $body = $request->get_body();
            
            // Try to parse as form data
            parse_str($body, $form_data);
            if (!empty($form_data)) {
                $this->debug_log('Parsed form data', array_keys($form_data));
                
                if (empty($site_url) && isset($form_data['site_url'])) {
                    $site_url = $form_data['site_url'];
                }
                if (empty($secret_pass) && isset($form_data['secret_pass'])) {
                    $secret_pass = $form_data['secret_pass'];
                }
                
                // Check for site_auth in form data
                if (isset($form_data['site_auth'])) {
                    $site_auth = $form_data['site_auth'];
                    if (is_string($site_auth)) {
                        $decoded = json_decode($site_auth, true);
                        if ($decoded && is_array($decoded)) {
                            $site_auth = $decoded;
                        }
                    }
                    
                    if (is_array($site_auth)) {
                        if (empty($site_url) && isset($site_auth['site_url'])) {
                            $site_url = $site_auth['site_url'];
                        }
                        if (empty($secret_pass) && isset($site_auth['secret_pass'])) {
                            $secret_pass = $site_auth['secret_pass'];
                        }
                    }
                }
            }
        }
        
        // Step 5: Cleanup and validation
        if (!empty($site_url)) {
            $site_url = esc_url_raw(trim($site_url));
            // Ensure URL has protocol
            if (!preg_match('/^https?:\/\//', $site_url)) {
                $site_url = 'https://' . $site_url;
            }
        }
        
        if (!empty($secret_pass)) {
            $secret_pass = sanitize_text_field(trim($secret_pass));
        }
        
        $result = array(
            'site_url' => $site_url,
            'secret_pass' => $secret_pass
        );
        
        $this->debug_log('Final extracted credentials', [
            'site_url' => !empty($site_url) ? $site_url : 'MISSING',
            'secret_pass_length' => !empty($secret_pass) ? strlen($secret_pass) : 0,
            'is_openai_request' => $is_openai
        ]);
        
        return $result;
    }

    /**
     * Extract credentials from raw data - simplified version for consistent use
     * 
     * @param string $raw_data Raw JSON data from request body
     * @return array Associative array with site_url, secret_pass, params, or error
     */
    private function extract_credentials($raw_data) {
        // JSON olarak çözümle
        $params = json_decode($raw_data, true);
        if (!$params) {
            return array('error' => 'Invalid JSON');
        }
        
        // Site bilgilerini al
        $site_url = '';
        $secret_pass = '';
        
        // site_auth formatını kontrol et
        if (isset($params['site_auth']) && is_array($params['site_auth'])) {
            $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : '';
            $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : '';
        } else {
            // Direct parameters
            $site_url = isset($params['site_url']) ? $params['site_url'] : '';
            $secret_pass = isset($params['secret_pass']) ? $params['secret_pass'] : '';
        }
        
        return array(
            'site_url' => $site_url,
            'secret_pass' => $secret_pass,
            'params' => $params
        );
    }

    /**
     * Diagnostic endpoint - tanılama ve hata ayıklama amaçlı
     */
    public function diagnostic_endpoint($request) {
        // Sadece JSON parametrelerini ve başlıkları alalım
        $params = $request->get_json_params();
        $headers = $request->get_headers();
        
        // PHP'nin ham girdiyi almasını sağlayalım
        $raw_input = file_get_contents('php://input');
        
        // Debug log'a yazalım
        error_log('DIAGNOSTIC: JSON Params: ' . json_encode($params));
        error_log('DIAGNOSTIC: Raw Input: ' . $raw_input);
        
        // Aldığımız verileri direkt geri dönelim
        return rest_ensure_response(array(
            'success' => true,
            'message' => 'Diagnostic endpoint called successfully',
            'received_data' => array(
                'json_params' => $params,
                'raw_input' => $raw_input,
                'content_type' => $_SERVER['CONTENT_TYPE'] ?? 'Not set',
                'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'Not set',
                'api_key_header' => $request->get_header('X-SEOKILLER-API-KEY')
            )
        ));
    }

    /**
     * Alternative content creation endpoint
     */
    public function create_content_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('CREATE_CONTENT_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        if (!$params) {
            error_log('CREATE_CONTENT_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('CREATE_CONTENT_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        // Prepare content data
        $content_data = array();
        foreach ($params as $key => $value) {
            if ($key !== 'site_auth' && $key !== 'site_url' && $key !== 'secret_pass') {
                $content_data[$key] = $value;
            }
        }
        
        error_log('CREATE_CONTENT_ALT: Content data: ' . json_encode($content_data));
        
        // Send request to client site
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/create-content';
        $response = wp_remote_post($client_endpoint, array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SEOKILLER-SECRET' => $secret_pass,
            ),
            'body' => json_encode($content_data),
            'timeout' => 45,
        ));
        
        if (is_wp_error($response)) {
            error_log('CREATE_CONTENT_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('CREATE_CONTENT_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative content update endpoint
     */
    public function update_content_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('UPDATE_CONTENT_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        $post_id = $request->get_param('postId');
        
        if (!$params) {
            error_log('UPDATE_CONTENT_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('UPDATE_CONTENT_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        if (empty($post_id)) {
            error_log('UPDATE_CONTENT_ALT: Invalid post ID');
            return new WP_Error('invalid_post_id', 'Invalid post ID', array('status' => 400));
        }
        
        // Prepare content data
        $content_data = array();
        foreach ($params as $key => $value) {
            if ($key !== 'site_auth' && $key !== 'site_url' && $key !== 'secret_pass') {
                $content_data[$key] = $value;
            }
        }
        
        error_log('UPDATE_CONTENT_ALT: Content data: ' . json_encode($content_data));
        
        // Send request to client site
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/update-content/' . $post_id;
        $response = wp_remote_request($client_endpoint, array(
            'method' => 'PUT',
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SEOKILLER-SECRET' => $secret_pass,
            ),
            'body' => json_encode($content_data),
            'timeout' => 45,
        ));
        
        if (is_wp_error($response)) {
            error_log('UPDATE_CONTENT_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('UPDATE_CONTENT_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative get categories endpoint
     */
    public function get_categories_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('GET_CATEGORIES_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        if (!$params) {
            error_log('GET_CATEGORIES_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('GET_CATEGORIES_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/categories';
        $response = wp_remote_get($client_endpoint, array(
            'headers' => array('X-SEOKILLER-SECRET' => $secret_pass),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('GET_CATEGORIES_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('GET_CATEGORIES_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative get authors endpoint
     */
    public function get_authors_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('GET_AUTHORS_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        if (!$params) {
            error_log('GET_AUTHORS_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('GET_AUTHORS_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/authors';
        $response = wp_remote_get($client_endpoint, array(
            'headers' => array('X-SEOKILLER-SECRET' => $secret_pass),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('GET_AUTHORS_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('GET_AUTHORS_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative get posts endpoint
     */
    public function get_posts_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('GET_POSTS_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        if (!$params) {
            error_log('GET_POSTS_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('GET_POSTS_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        // Build query parameters
        $query_params = array();
        if (isset($params['page'])) $query_params['page'] = intval($params['page']);
        if (isset($params['per_page'])) $query_params['per_page'] = intval($params['per_page']);
        if (isset($params['category_id'])) $query_params['category_id'] = intval($params['category_id']);
        
        $client_endpoint = add_query_arg($query_params, trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/posts');
        $response = wp_remote_get($client_endpoint, array(
            'headers' => array('X-SEOKILLER-SECRET' => $secret_pass),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('GET_POSTS_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('GET_POSTS_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative get single post endpoint
     */
    public function get_post_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('GET_POST_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        $post_id = $request->get_param('postId');
        
        if (!$params) {
            error_log('GET_POST_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('GET_POST_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        if (empty($post_id)) {
            error_log('GET_POST_ALT: Invalid post ID');
            return new WP_Error('invalid_post_id', 'Invalid post ID', array('status' => 400));
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/posts/' . $post_id;
        $response = wp_remote_get($client_endpoint, array(
            'headers' => array('X-SEOKILLER-SECRET' => $secret_pass),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('GET_POST_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('GET_POST_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative delete post endpoint
     */
    public function delete_post_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('DELETE_POST_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        $post_id = $request->get_param('postId');
        
        if (!$params) {
            error_log('DELETE_POST_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('DELETE_POST_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        if (empty($post_id)) {
            error_log('DELETE_POST_ALT: Invalid post ID');
            return new WP_Error('invalid_post_id', 'Invalid post ID', array('status' => 400));
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/posts/' . $post_id;
        $response = wp_remote_request($client_endpoint, array(
            'method' => 'DELETE',
            'headers' => array('X-SEOKILLER-SECRET' => $secret_pass),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('DELETE_POST_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('DELETE_POST_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative get site info endpoint
     */
    public function get_site_info_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('GET_SITE_INFO_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        if (!$params) {
            error_log('GET_SITE_INFO_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('GET_SITE_INFO_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/site-info';
        $response = wp_remote_get($client_endpoint, array(
            'headers' => array('X-SEOKILLER-SECRET' => $secret_pass),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('GET_SITE_INFO_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('GET_SITE_INFO_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative get products endpoint
     */
    public function get_products_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('GET_PRODUCTS_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        if (!$params) {
            error_log('GET_PRODUCTS_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('GET_PRODUCTS_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        // Build query parameters
        $query_params = array();
        if (isset($params['page'])) $query_params['page'] = intval($params['page']);
        if (isset($params['per_page'])) $query_params['per_page'] = intval($params['per_page']);
        if (isset($params['category_id'])) $query_params['category_id'] = intval($params['category_id']);
        
        $client_endpoint = add_query_arg($query_params, trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products');
        $response = wp_remote_get($client_endpoint, array(
            'headers' => array('X-SEOKILLER-SECRET' => $secret_pass),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('GET_PRODUCTS_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('GET_PRODUCTS_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative create product endpoint
     */
    public function create_product_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('CREATE_PRODUCT_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        if (!$params) {
            error_log('CREATE_PRODUCT_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('CREATE_PRODUCT_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        // Prepare product data
        $product_data = array();
        foreach ($params as $key => $value) {
            if ($key !== 'site_auth' && $key !== 'site_url' && $key !== 'secret_pass') {
                $product_data[$key] = $value;
            }
        }
        
        error_log('CREATE_PRODUCT_ALT: Product data: ' . json_encode($product_data));
        
        // Send request to client site
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products';
        $response = wp_remote_post($client_endpoint, array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SEOKILLER-SECRET' => $secret_pass,
            ),
            'body' => json_encode($product_data),
            'timeout' => 45,
        ));
        
        if (is_wp_error($response)) {
            error_log('CREATE_PRODUCT_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('CREATE_PRODUCT_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative update product endpoint
     */
    public function update_product_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('UPDATE_PRODUCT_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        $product_id = $request->get_param('productId');
        
        if (!$params) {
            error_log('UPDATE_PRODUCT_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('UPDATE_PRODUCT_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        if (empty($product_id)) {
            error_log('UPDATE_PRODUCT_ALT: Invalid product ID');
            return new WP_Error('invalid_product_id', 'Invalid product ID', array('status' => 400));
        }
        
        // Prepare product data
        $product_data = array();
        foreach ($params as $key => $value) {
            if ($key !== 'site_auth' && $key !== 'site_url' && $key !== 'secret_pass') {
                $product_data[$key] = $value;
            }
        }
        
        error_log('UPDATE_PRODUCT_ALT: Product data: ' . json_encode($product_data));
        
        // Send request to client site
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products/' . $product_id;
        $response = wp_remote_request($client_endpoint, array(
            'method' => 'PUT',
            'headers' => array(
                'Content-Type' => 'application/json',
                'X-SEOKILLER-SECRET' => $secret_pass,
            ),
            'body' => json_encode($product_data),
            'timeout' => 45,
        ));
        
        if (is_wp_error($response)) {
            error_log('UPDATE_PRODUCT_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('UPDATE_PRODUCT_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }

    /**
     * Alternative delete product endpoint
     */
    public function delete_product_alt($request) {
        $raw_data = file_get_contents('php://input');
        error_log('DELETE_PRODUCT_ALT: Raw data: ' . $raw_data);
        
        $params = json_decode($raw_data, true);
        $product_id = $request->get_param('productId');
        
        if (!$params) {
            error_log('DELETE_PRODUCT_ALT: JSON decode failed');
            return new WP_Error('invalid_json', 'Invalid JSON data', array('status' => 400));
        }
        
        // Extract site credentials
        $site_url = isset($params['site_auth']['site_url']) ? $params['site_auth']['site_url'] : (isset($params['site_url']) ? $params['site_url'] : '');
        $secret_pass = isset($params['site_auth']['secret_pass']) ? $params['site_auth']['secret_pass'] : (isset($params['secret_pass']) ? $params['secret_pass'] : '');
        
        if (empty($site_url) || empty($secret_pass)) {
            error_log('DELETE_PRODUCT_ALT: Missing credentials');
            return new WP_Error('missing_required_params', 'Missing site URL or secret pass', array('status' => 400));
        }
        
        if (empty($product_id)) {
            error_log('DELETE_PRODUCT_ALT: Invalid product ID');
            return new WP_Error('invalid_product_id', 'Invalid product ID', array('status' => 400));
        }
        
        $client_endpoint = trailingslashit($site_url) . 'wp-json/seokiller-wp/v1/products/' . $product_id;
        $response = wp_remote_request($client_endpoint, array(
            'method' => 'DELETE',
            'headers' => array('X-SEOKILLER-SECRET' => $secret_pass),
            'timeout' => 30,
        ));
        
        if (is_wp_error($response)) {
            error_log('DELETE_PRODUCT_ALT: Request failed: ' . $response->get_error_message());
            return new WP_Error('wp_request_failed', 'Failed to connect: ' . $response->get_error_message(), array('status' => 500));
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = json_decode(wp_remote_retrieve_body($response), true);
        
        error_log('DELETE_PRODUCT_ALT: Response code: ' . $response_code);
        
        return rest_ensure_response(array('status' => $response_code, 'body' => $response_body));
    }
}

// Initialize the plugin
function seokiller_action_init() {
    SEOKILLER_Action::get_instance();
}
add_action('plugins_loaded', 'seokiller_action_init'); 