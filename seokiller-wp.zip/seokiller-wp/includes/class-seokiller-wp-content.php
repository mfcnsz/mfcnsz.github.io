<?php
/**
 * SEOKILLER WP Content Handler
 *
 * @package SEOKILLER_WP
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Content handler class
 */
class SEOKILLER_WP_Content {
    /**
     * Create a new post
     *
     * @param array $post_data Post data
     * @return int|WP_Error Post ID on success, WP_Error on failure
     */
    public function create_post($post_data) {
        $post_id = wp_insert_post($post_data, true);
        
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        
        // Handle categories if provided
        if (!empty($post_data['categories']) && is_array($post_data['categories'])) {
            $this->set_post_categories($post_id, $post_data['categories']);
        }
        
        // Handle tags if provided
        if (!empty($post_data['tags']) && is_array($post_data['tags'])) {
            $this->set_post_tags($post_id, $post_data['tags']);
        }
        
        return $post_id;
    }
    
    /**
     * Update an existing post
     *
     * @param array $post_data Post data
     * @return int|WP_Error Post ID on success, WP_Error on failure
     */
    public function update_post($post_data) {
        // Extract categories and tags before wp_update_post
        $categories = !empty($post_data['categories']) ? $post_data['categories'] : array();
        $tags = !empty($post_data['tags']) ? $post_data['tags'] : array();
        
        // Remove non-post data
        unset($post_data['categories']);
        unset($post_data['tags']);
        
        $post_id = wp_update_post($post_data, true);
        
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        
        // Handle categories if provided
        if (!empty($categories) && is_array($categories)) {
            $this->set_post_categories($post_id, $categories);
        }
        
        // Handle tags if provided
        if (!empty($tags) && is_array($tags)) {
            $this->set_post_tags($post_id, $tags);
        }
        
        return $post_id;
    }
    
    /**
     * Set categories for a post
     *
     * @param int $post_id Post ID
     * @param array $categories Array of category IDs
     */
    public function set_post_categories($post_id, $categories) {
        wp_set_post_categories($post_id, $categories);
    }
    
    /**
     * Set tags for a post
     *
     * @param int $post_id Post ID
     * @param array $tags Array of tag names or IDs
     */
    public function set_post_tags($post_id, $tags) {
        wp_set_post_terms($post_id, $tags, 'post_tag');
    }
    
    /**
     * Set featured image for a post
     *
     * @param int $post_id Post ID
     * @param string $image_data URL or base64 encoded image data
     * @return int|WP_Error Attachment ID or WP_Error
     */
    public function set_featured_image($post_id, $image_data) {
        $attachment_id = $this->handle_image_upload($image_data);
        
        if (is_wp_error($attachment_id)) {
            return $attachment_id;
        }
        
        // Set as featured image
        set_post_thumbnail($post_id, $attachment_id);
        
        return $attachment_id;
    }
    
    /**
     * Handle image upload from URL or base64
     *
     * @param string $image_data URL or base64 encoded image data
     * @return int|WP_Error Attachment ID or WP_Error
     */
    public function handle_image_upload($image_data) {
        // Check if it's a valid URL
        if (filter_var($image_data, FILTER_VALIDATE_URL)) {
            return $this->upload_image_from_url($image_data);
        } 
        
        // Check if it's base64 encoded data
        if (preg_match('/^data:image\/(\w+);base64,/', $image_data, $matches)) {
            return $this->upload_image_from_base64($image_data, $matches[1]);
        }
        
        return new WP_Error(
            'invalid_image_data',
            'Invalid image data. Provide a valid URL or base64 encoded image data.',
            array('status' => 400)
        );
    }
    
    /**
     * Upload image from URL
     *
     * @param string $url Image URL
     * @return int|WP_Error Attachment ID or WP_Error
     */
    private function upload_image_from_url($url) {
        // Get the file name from URL
        $file_name = basename($url);
        
        // Check if file already exists in media library
        $attachment_id = $this->get_attachment_by_url($url);
        if ($attachment_id) {
            return $attachment_id;
        }
        
        // Download image
        $temp_file = download_url($url);
        
        if (is_wp_error($temp_file)) {
            return $temp_file;
        }
        
        $file_array = array(
            'name' => $file_name,
            'tmp_name' => $temp_file
        );
        
        // Move the temporary file to the uploads directory
        $attachment_id = media_handle_sideload($file_array, 0);
        
        // Clean up if there's an error
        if (is_wp_error($attachment_id)) {
            @unlink($temp_file);
            return $attachment_id;
        }
        
        return $attachment_id;
    }
    
    /**
     * Upload image from base64 encoded data
     *
     * @param string $base64_data Base64 encoded image data
     * @param string $image_type Image type (jpg, png, etc.)
     * @return int|WP_Error Attachment ID or WP_Error
     */
    private function upload_image_from_base64($base64_data, $image_type) {
        $upload_dir = wp_upload_dir();
        
        // Generate a unique file name
        $file_name = uniqid() . '.' . $image_type;
        $file_path = $upload_dir['path'] . '/' . $file_name;
        
        // Get the raw base64 data
        $base64_data = preg_replace('/^data:image\/\w+;base64,/', '', $base64_data);
        $base64_data = str_replace(' ', '+', $base64_data);
        $image_data = base64_decode($base64_data);
        
        // Save the image to the uploads directory
        $result = file_put_contents($file_path, $image_data);
        
        if ($result === false) {
            return new WP_Error(
                'image_upload_failed',
                'Failed to save image to uploads directory',
                array('status' => 500)
            );
        }
        
        // Prepare the attachment data
        $attachment = array(
            'post_mime_type' => 'image/' . $image_type,
            'post_title' => sanitize_file_name($file_name),
            'post_content' => '',
            'post_status' => 'inherit'
        );
        
        // Insert the attachment
        $attachment_id = wp_insert_attachment($attachment, $file_path);
        
        if (is_wp_error($attachment_id)) {
            return $attachment_id;
        }
        
        // Generate attachment metadata
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $attachment_data = wp_generate_attachment_metadata($attachment_id, $file_path);
        wp_update_attachment_metadata($attachment_id, $attachment_data);
        
        return $attachment_id;
    }
    
    /**
     * Get attachment ID by URL
     *
     * @param string $url Image URL
     * @return int|bool Attachment ID or false if not found
     */
    private function get_attachment_by_url($url) {
        global $wpdb;
        
        $attachment = $wpdb->get_col($wpdb->prepare("SELECT ID FROM $wpdb->posts WHERE guid='%s';", $url));
        
        if (!empty($attachment[0])) {
            return $attachment[0];
        }
        
        return false;
    }
} 