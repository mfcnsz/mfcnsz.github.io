<?php
/**
 * SEOKILLER WP Authentication
 *
 * @package SEOKILLER_WP
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Authentication class
 */
class SEOKILLER_WP_Auth {
    /**
     * Validate the API key from the request headers
     *
     * @param WP_REST_Request $request The request object
     * @return bool Whether the authentication is successful
     */
    public function validate_secret_key($request) {
        // İlk olarak X-SEOKILLER-API-KEY header'ını kontrol et (geriye dönük uyumluluk için)
        $auth_header = $request->get_header('X-SEOKILLER-API-KEY');
        
        // Eğer bulamazsan, X-SEOKILLER-SECRET header'ını kontrol et
        if (empty($auth_header)) {
            $auth_header = $request->get_header('X-SEOKILLER-SECRET');
        }
        
        if (empty($auth_header)) {
            return false;
        }
        
        $secret_key = get_option(SEOKILLER_WP_KEY_OPTION, '');
        
        if (empty($secret_key)) {
            // Try to get a key from the plugin instance as fallback
            $secret_key = seokiller_wp_init()->get_secret_key();
            if (empty($secret_key)) {
                return false;
            }
        }
        
        return hash_equals($secret_key, $auth_header);
    }
    
    /**
     * Check if the request is authenticated
     *
     * @param WP_REST_Request $request The request object
     * @return bool|WP_Error True if authenticated, WP_Error otherwise
     */
    public function check_auth($request) {
        if (!$this->validate_secret_key($request)) {
            return new WP_Error(
                'seokiller_auth_failed',
                'Authentication failed. Invalid or missing API key.',
                array('status' => 401)
            );
        }
        
        return true;
    }
    
    /**
     * Backwards compatibility method for check_secret_key
     *
     * @param WP_REST_Request $request The request object
     * @return bool|WP_Error True if authenticated, WP_Error otherwise
     */
    public function check_secret_key($request) {
        return $this->check_auth($request);
    }
} 