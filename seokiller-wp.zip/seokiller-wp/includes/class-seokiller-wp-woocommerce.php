<?php
/**
 * SEOKILLER WP WooCommerce Integration
 *
 * @package SEOKILLER_WP
 */

if (!defined('WPINC')) {
    die;
}

/**
 * WooCommerce integration class
 */
class SEOKILLER_WP_WooCommerce {
    /**
     * Content handler instance
     *
     * @var SEOKILLER_WP_Content
     */
    private $content;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->content = new SEOKILLER_WP_Content();
    }
    
    /**
     * Get products
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response Products data
     */
    public function get_products($request) {
        $args = array(
            'post_type' => 'product',
            'post_status' => 'publish',
            'posts_per_page' => 10
        );
        
        if (isset($request['per_page'])) {
            $args['posts_per_page'] = absint($request['per_page']);
        }
        
        if (isset($request['page'])) {
            $args['paged'] = absint($request['page']);
        }
        
        $query = new WP_Query($args);
        $products = $query->posts;
        $data = array();
        
        foreach ($products as $product) {
            $wc_product = wc_get_product($product->ID);
            
            if (!$wc_product) {
                continue;
            }
            
            $data[] = array(
                'id' => $wc_product->get_id(),
                'name' => $wc_product->get_name(),
                'slug' => $wc_product->get_slug(),
                'status' => $wc_product->get_status(),
                'description' => $wc_product->get_description(),
                'short_description' => $wc_product->get_short_description(),
                'price' => $wc_product->get_price(),
                'regular_price' => $wc_product->get_regular_price(),
                'sale_price' => $wc_product->get_sale_price(),
                'date_created' => $wc_product->get_date_created() ? $wc_product->get_date_created()->date('Y-m-d H:i:s') : '',
                'featured' => $wc_product->get_featured(),
                'permalink' => get_permalink($wc_product->get_id())
            );
        }
        
        return rest_ensure_response($data);
    }
    
    /**
     * Create product
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function create_product($request) {
        try {
            // Create the product
            $product = new WC_Product_Simple();
            $product->set_name(sanitize_text_field($request['name']));
            $product->set_description(wp_kses_post($request['description']));
            
            // Set optional fields
            if (!empty($request['short_description'])) {
                $product->set_short_description(sanitize_text_field($request['short_description']));
            }
            
            if (!empty($request['regular_price'])) {
                $product->set_regular_price(sanitize_text_field($request['regular_price']));
            }
            
            if (!empty($request['sale_price'])) {
                $product->set_sale_price(sanitize_text_field($request['sale_price']));
            }
            
            if (!empty($request['slug'])) {
                $product->set_slug(sanitize_title($request['slug']));
            }
            
            if (isset($request['featured'])) {
                $product->set_featured($request['featured']);
            }
            
            // Set status
            if (!empty($request['status']) && in_array($request['status'], array('publish', 'draft', 'pending'))) {
                $product->set_status($request['status']);
            }
            
            // Save the product to get an ID
            $product_id = $product->save();
            
            // Handle product categories
            if (!empty($request['categories']) && is_array($request['categories'])) {
                $this->set_product_categories($product_id, $request['categories']);
            }
            
            // Handle product tags
            if (!empty($request['tags']) && is_array($request['tags'])) {
                $this->set_product_tags($product_id, $request['tags']);
            }
            
            // Handle product images
            if (!empty($request['images']) && is_array($request['images'])) {
                $this->set_product_images($product_id, $request['images']);
            }
            
            // Get updated product
            $product = wc_get_product($product_id);
            
            $response = array(
                'status' => 'success',
                'id' => $product_id,
                'name' => $product->get_name(),
                'slug' => $product->get_slug(),
                'permalink' => get_permalink($product_id)
            );
            
            return rest_ensure_response($response);
        } catch (Exception $e) {
            return new WP_Error(
                'product_creation_failed',
                $e->getMessage(),
                array('status' => 500)
            );
        }
    }
    
    /**
     * Update product
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function update_product($request) {
        try {
            $product_id = (int) $request['id'];
            $product = wc_get_product($product_id);
            
            if (!$product) {
                return new WP_Error(
                    'product_not_found',
                    'Product not found',
                    array('status' => 404)
                );
            }
            
            // Update product data
            if (!empty($request['name'])) {
                $product->set_name(sanitize_text_field($request['name']));
            }
            
            if (!empty($request['description'])) {
                $product->set_description(wp_kses_post($request['description']));
            }
            
            if (!empty($request['short_description'])) {
                $product->set_short_description(sanitize_text_field($request['short_description']));
            }
            
            if (!empty($request['regular_price'])) {
                $product->set_regular_price(sanitize_text_field($request['regular_price']));
            }
            
            if (!empty($request['sale_price'])) {
                $product->set_sale_price(sanitize_text_field($request['sale_price']));
            }
            
            if (!empty($request['slug'])) {
                $product->set_slug(sanitize_title($request['slug']));
            }
            
            if (isset($request['featured'])) {
                $product->set_featured($request['featured']);
            }
            
            // Set status
            if (!empty($request['status']) && in_array($request['status'], array('publish', 'draft', 'pending'))) {
                $product->set_status($request['status']);
            }
            
            // Save the product
            $product->save();
            
            // Handle product categories
            if (!empty($request['categories']) && is_array($request['categories'])) {
                $this->set_product_categories($product_id, $request['categories']);
            }
            
            // Handle product tags
            if (!empty($request['tags']) && is_array($request['tags'])) {
                $this->set_product_tags($product_id, $request['tags']);
            }
            
            // Handle product images
            if (!empty($request['images']) && is_array($request['images'])) {
                $this->set_product_images($product_id, $request['images']);
            }
            
            // Get updated product
            $product = wc_get_product($product_id);
            
            $response = array(
                'status' => 'success',
                'id' => $product_id,
                'name' => $product->get_name(),
                'slug' => $product->get_slug(),
                'permalink' => get_permalink($product_id)
            );
            
            return rest_ensure_response($response);
        } catch (Exception $e) {
            return new WP_Error(
                'product_update_failed',
                $e->getMessage(),
                array('status' => 500)
            );
        }
    }
    
    /**
     * Delete product
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function delete_product($request) {
        $product_id = (int) $request['id'];
        $product = wc_get_product($product_id);
        
        if (!$product) {
            return new WP_Error(
                'product_not_found',
                'Product not found',
                array('status' => 404)
            );
        }
        
        $result = $product->delete(true);
        
        if (!$result) {
            return new WP_Error(
                'product_delete_failed',
                'Failed to delete product',
                array('status' => 500)
            );
        }
        
        $response = array(
            'status' => 'success',
            'id' => $product_id,
            'message' => 'Product deleted successfully'
        );
        
        return rest_ensure_response($response);
    }
    
    /**
     * Set product categories
     *
     * @param int $product_id Product ID
     * @param array $categories Array of category IDs
     */
    private function set_product_categories($product_id, $categories) {
        wp_set_object_terms($product_id, $categories, 'product_cat');
    }
    
    /**
     * Set product tags
     *
     * @param int $product_id Product ID
     * @param array $tags Array of tag names or IDs
     */
    private function set_product_tags($product_id, $tags) {
        wp_set_object_terms($product_id, $tags, 'product_tag');
    }
    
    /**
     * Set product images
     *
     * @param int $product_id Product ID
     * @param array $images Array of image URLs or base64 data
     * @return array Array of attachment IDs
     */
    private function set_product_images($product_id, $images) {
        if (empty($images) || !is_array($images)) {
            return array();
        }
        
        $attachment_ids = array();
        
        foreach ($images as $index => $image_data) {
            $attachment_id = $this->content->handle_image_upload($image_data);
            
            if (is_wp_error($attachment_id)) {
                continue;
            }
            
            $attachment_ids[] = $attachment_id;
            
            // Set the first image as the product thumbnail
            if ($index === 0) {
                set_post_thumbnail($product_id, $attachment_id);
            }
        }
        
        // Set product gallery images (excluding the first one which is the thumbnail)
        if (count($attachment_ids) > 1) {
            $gallery_ids = array_slice($attachment_ids, 1);
            update_post_meta($product_id, '_product_image_gallery', implode(',', $gallery_ids));
        }
        
        return $attachment_ids;
    }
} 