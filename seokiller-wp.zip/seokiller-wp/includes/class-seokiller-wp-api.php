<?php
/**
 * SEOKILLER WP API
 *
 * @package SEOKILLER_WP
 */

if (!defined('WPINC')) {
    die;
}

/**
 * API class for handling REST endpoints
 */
class SEOKILLER_WP_API {
    /**
     * The namespace for our API
     *
     * @var string
     */
    private $namespace = 'seokiller-wp/v1';
    
    /**
     * Authentication instance
     *
     * @var SEOKILLER_WP_Auth
     */
    private $auth;
    
    /**
     * Content handler instance
     *
     * @var SEOKILLER_WP_Content
     */
    private $content;
    
    /**
     * WooCommerce handler instance
     *
     * @var SEOKILLER_WP_WooCommerce
     */
    private $woocommerce;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->auth = new SEOKILLER_WP_Auth();
        $this->content = new SEOKILLER_WP_Content();
        
        // Initialize WooCommerce handler if WooCommerce is active
        if (seokiller_wp_init()->is_woocommerce_active()) {
            $this->woocommerce = new SEOKILLER_WP_WooCommerce();
        }
    }
    
    /**
     * Register all the REST API routes
     */
    public function register_routes() {
        // Site information endpoint
        register_rest_route($this->namespace, '/site-info', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_site_info'),
            'permission_callback' => array($this->auth, 'check_auth')
        ));
        
        // Categories endpoint
        register_rest_route($this->namespace, '/categories', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_categories'),
            'permission_callback' => array($this->auth, 'check_auth')
        ));
        
        // Authors endpoint
        register_rest_route($this->namespace, '/authors', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_authors'),
            'permission_callback' => array($this->auth, 'check_auth')
        ));
        
        // Posts endpoint - GET all posts
        register_rest_route($this->namespace, '/posts', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_posts'),
            'permission_callback' => array($this->auth, 'check_auth')
        ));
        
        // Create post endpoint - Create a new post
        register_rest_route($this->namespace, '/posts', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_post'),
            'permission_callback' => array($this->auth, 'check_auth'),
            'args' => $this->get_post_arguments()
        ));
        
        // Get single post endpoint
        register_rest_route($this->namespace, '/posts/(?P<id>\d+)', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_post'),
            'permission_callback' => array($this->auth, 'check_auth'),
            'args' => array(
                'id' => array(
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ),
            ),
        ));
        
        // Update post endpoint
        register_rest_route($this->namespace, '/posts/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_post'),
            'permission_callback' => array($this->auth, 'check_auth'),
            'args' => $this->get_post_arguments()
        ));
        
        // Delete post endpoint
        register_rest_route($this->namespace, '/posts/(?P<id>\d+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_post'),
            'permission_callback' => array($this->auth, 'check_auth'),
            'args' => array(
                'id' => array(
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ),
            ),
        ));
        
        // Create content endpoint (alias for create_post with more flexibility)
        register_rest_route($this->namespace, '/create-content', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_content'),
            'permission_callback' => array($this->auth, 'check_auth')
        ));
        
        // Update content endpoint
        register_rest_route($this->namespace, '/update-content/(?P<postId>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_content'),
            'permission_callback' => array($this->auth, 'check_auth'),
            'args' => array(
                'postId' => array(
                    'validate_callback' => function($param) {
                        return is_numeric($param);
                    }
                ),
            ),
        ));
        
        // Debug endpoint
        register_rest_route($this->namespace, '/debug', array(
            'methods' => 'GET',
            'callback' => function() {
                return rest_ensure_response(array(
                    'status' => 'success',
                    'message' => 'SEOKILLER WP API is working',
                    'time' => current_time('mysql')
                ));
            },
            'permission_callback' => '__return_true' // Herkes erişebilir
        ));
        
        // Register WooCommerce endpoints if active
        if (seokiller_wp_init()->is_woocommerce_active()) {
            $this->register_woocommerce_routes();
        }
    }
    
    /**
     * Register WooCommerce specific routes
     */
    public function register_woocommerce_routes() {
        // Products endpoint
        register_rest_route($this->namespace, '/products', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_products'),
            'permission_callback' => array($this->auth, 'check_auth')
        ));
        
        // Create product endpoint
        register_rest_route($this->namespace, '/products', array(
            'methods' => 'POST',
            'callback' => array($this, 'create_product'),
            'permission_callback' => array($this->auth, 'check_auth'),
            'args' => $this->get_product_arguments()
        ));
        
        // Update product endpoint
        register_rest_route($this->namespace, '/products/(?P<id>\d+)', array(
            'methods' => 'PUT',
            'callback' => array($this, 'update_product'),
            'permission_callback' => array($this->auth, 'check_auth'),
            'args' => $this->get_product_arguments()
        ));
        
        // Delete product endpoint
        register_rest_route($this->namespace, '/products/(?P<id>\d+)', array(
            'methods' => 'DELETE',
            'callback' => array($this, 'delete_product'),
            'permission_callback' => array($this->auth, 'check_auth')
        ));
    }
    
    /**
     * Get site information
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response Site information
     */
    public function get_site_info($request) {
        $site_info = array(
            'name' => get_bloginfo('name'),
            'description' => get_bloginfo('description'),
            'url' => get_site_url(),
            'post_count' => wp_count_posts()->publish,
            'version' => get_bloginfo('version'),
            'language' => get_bloginfo('language'),
            'timezone' => get_option('timezone_string')
        );
        
        // WooCommerce bilgisi ekle (eğer aktifse)
        if (seokiller_wp_init()->is_woocommerce_active()) {
            $product_count = wp_count_posts('product')->publish;
            $site_info['product_count'] = $product_count;
            $site_info['is_woocommerce_active'] = true;
        } else {
            $site_info['is_woocommerce_active'] = false;
        }
        
        return rest_ensure_response($site_info);
    }
    
    /**
     * Get categories
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response Categories data
     */
    public function get_categories($request) {
        $args = array(
            'hide_empty' => false
        );
        
        $categories = get_categories($args);
        $data = array();
        
        foreach ($categories as $category) {
            $data[] = array(
                'id' => $category->term_id,
                'name' => $category->name,
                'slug' => $category->slug,
                'description' => $category->description,
                'count' => $category->count
            );
        }
        
        return rest_ensure_response($data);
    }
    
    /**
     * Get authors
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response Authors data
     */
    public function get_authors($request) {
        $args = array(
            'who' => 'authors',
            'has_published_posts' => true
        );
        
        $authors = get_users($args);
        $data = array();
        
        foreach ($authors as $author) {
            $data[] = array(
                'id' => $author->ID,
                'username' => $author->user_login,
                'name' => $author->display_name,
                'email' => $author->user_email
            );
        }
        
        return rest_ensure_response($data);
    }
    
    /**
     * Get posts
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response Posts data
     */
    public function get_posts($request) {
        $args = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'posts_per_page' => 10
        );
        
        if (isset($request['per_page'])) {
            $args['posts_per_page'] = absint($request['per_page']);
        }
        
        if (isset($request['page'])) {
            $args['paged'] = absint($request['page']);
        }
        
        $query = new WP_Query($args);
        $posts = $query->posts;
        $data = array();
        
        foreach ($posts as $post) {
            $data[] = array(
                'id' => $post->ID,
                'title' => $post->post_title,
                'slug' => $post->post_name,
                'date' => $post->post_date,
                'status' => $post->post_status,
                'excerpt' => $post->post_excerpt
            );
        }
        
        return rest_ensure_response($data);
    }
    
    /**
     * Create post
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function create_post($request) {
        $post_data = $this->prepare_post_data_for_database($request);
        
        $post_id = $this->content->create_post($post_data);
        
        if (is_wp_error($post_id)) {
            return rest_ensure_response($post_id);
        }
        
        // Process featured image
        if (!empty($request['featured_image'])) {
            $featured_image_result = $this->content->set_featured_image($post_id, $request['featured_image']);
        }
        
        $post = get_post($post_id);
        
        $response = array(
            'status' => 'success',
            'id' => $post_id,
            'title' => $post->post_title,
            'slug' => $post->post_name,
            'link' => get_permalink($post_id)
        );
        
        return rest_ensure_response($response);
    }
    
    /**
     * Update post
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function update_post($request) {
        $post_id = (int) $request['id'];
        
        if (!get_post($post_id)) {
            return new WP_Error(
                'post_not_found',
                'Post not found',
                array('status' => 404)
            );
        }
        
        $post_data = $this->prepare_post_data_for_database($request);
        $post_data['ID'] = $post_id;
        
        $result = $this->content->update_post($post_data);
        
        if (is_wp_error($result)) {
            return rest_ensure_response($result);
        }
        
        // Process featured image
        if (!empty($request['featured_image'])) {
            $featured_image_result = $this->content->set_featured_image($post_id, $request['featured_image']);
        }
        
        $post = get_post($post_id);
        
        $response = array(
            'status' => 'success',
            'id' => $post_id,
            'title' => $post->post_title,
            'slug' => $post->post_name,
            'link' => get_permalink($post_id)
        );
        
        return rest_ensure_response($response);
    }
    
    /**
     * Delete post
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function delete_post($request) {
        $post_id = (int) $request['id'];
        
        if (!get_post($post_id)) {
            return new WP_Error(
                'post_not_found',
                'Post not found',
                array('status' => 404)
            );
        }
        
        $result = wp_delete_post($post_id, true);
        
        if (!$result) {
            return new WP_Error(
                'post_delete_failed',
                'Failed to delete post',
                array('status' => 500)
            );
        }
        
        $response = array(
            'status' => 'success',
            'id' => $post_id,
            'message' => 'Post deleted successfully'
        );
        
        return rest_ensure_response($response);
    }
    
    /**
     * Get products (WooCommerce)
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response Products data
     */
    public function get_products($request) {
        if (!$this->woocommerce) {
            return new WP_Error(
                'woocommerce_not_active',
                'WooCommerce is not active',
                array('status' => 400)
            );
        }
        
        return $this->woocommerce->get_products($request);
    }
    
    /**
     * Create product (WooCommerce)
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function create_product($request) {
        if (!$this->woocommerce) {
            return new WP_Error(
                'woocommerce_not_active',
                'WooCommerce is not active',
                array('status' => 400)
            );
        }
        
        return $this->woocommerce->create_product($request);
    }
    
    /**
     * Update product (WooCommerce)
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function update_product($request) {
        if (!$this->woocommerce) {
            return new WP_Error(
                'woocommerce_not_active',
                'WooCommerce is not active',
                array('status' => 400)
            );
        }
        
        return $this->woocommerce->update_product($request);
    }
    
    /**
     * Delete product (WooCommerce)
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response The response
     */
    public function delete_product($request) {
        if (!$this->woocommerce) {
            return new WP_Error(
                'woocommerce_not_active',
                'WooCommerce is not active',
                array('status' => 400)
            );
        }
        
        return $this->woocommerce->delete_product($request);
    }
    
    /**
     * Prepare post data for database
     *
     * @param WP_REST_Request $request The request object
     * @return array Sanitized post data
     */
    private function prepare_post_data_for_database($request) {
        $post_data = array(
            'post_title' => sanitize_text_field($request['title']),
            'post_content' => wp_kses_post($request['content']),
            'post_status' => 'publish',
            'post_type' => 'post'
        );
        
        // Handle post type
        if (!empty($request['type']) && in_array($request['type'], array('post', 'page'))) {
            $post_data['post_type'] = $request['type'];
        }
        
        // Handle status
        if (!empty($request['status']) && in_array($request['status'], array('publish', 'draft', 'pending', 'future'))) {
            $post_data['post_status'] = $request['status'];
        }
        
        // Handle scheduled publishing
        if ($post_data['post_status'] === 'future' && !empty($request['date'])) {
            $post_data['post_date'] = $request['date'];
            $post_data['post_date_gmt'] = get_gmt_from_date($request['date']);
        }
        
        // Handle slug
        if (!empty($request['slug'])) {
            $post_data['post_name'] = sanitize_title($request['slug']);
        }
        
        // Handle excerpt
        if (!empty($request['excerpt'])) {
            $post_data['post_excerpt'] = sanitize_text_field($request['excerpt']);
        }
        
        // Handle author
        if (!empty($request['author'])) {
            $post_data['post_author'] = absint($request['author']);
        }
        
        return $post_data;
    }
    
    /**
     * Get the schema for post arguments
     *
     * @return array Arguments schema
     */
    private function get_post_arguments() {
        return array(
            'title' => array(
                'required' => true,
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'content' => array(
                'required' => true,
                'type' => 'string',
                'sanitize_callback' => 'wp_kses_post'
            ),
            'type' => array(
                'type' => 'string',
                'enum' => array('post', 'page'),
                'default' => 'post',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'status' => array(
                'type' => 'string',
                'enum' => array('publish', 'draft', 'pending', 'future'),
                'default' => 'publish',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'date' => array(
                'type' => 'string',
                'format' => 'date-time',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'author' => array(
                'type' => 'integer',
                'sanitize_callback' => 'absint'
            ),
            'slug' => array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_title'
            ),
            'excerpt' => array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'featured_image' => array(
                'type' => 'string',
                'format' => 'uri',
                'description' => 'URL or base64 encoded image data'
            ),
            'categories' => array(
                'type' => 'array',
                'items' => array(
                    'type' => 'integer'
                ),
                'sanitize_callback' => function($categories) {
                    return array_map('absint', (array) $categories);
                }
            ),
            'tags' => array(
                'type' => 'array',
                'items' => array(
                    'type' => 'string'
                ),
                'sanitize_callback' => function($tags) {
                    return array_map('sanitize_text_field', (array) $tags);
                }
            )
        );
    }
    
    /**
     * Get the schema for product arguments
     *
     * @return array Arguments schema
     */
    private function get_product_arguments() {
        return array(
            'name' => array(
                'required' => true,
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'description' => array(
                'required' => true,
                'type' => 'string',
                'sanitize_callback' => 'wp_kses_post'
            ),
            'short_description' => array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'regular_price' => array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'sale_price' => array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'status' => array(
                'type' => 'string',
                'enum' => array('publish', 'draft', 'pending'),
                'default' => 'publish',
                'sanitize_callback' => 'sanitize_text_field'
            ),
            'slug' => array(
                'type' => 'string',
                'sanitize_callback' => 'sanitize_title'
            ),
            'featured' => array(
                'type' => 'boolean',
                'default' => false
            ),
            'categories' => array(
                'type' => 'array',
                'items' => array(
                    'type' => 'integer'
                ),
                'sanitize_callback' => function($categories) {
                    return array_map('absint', (array) $categories);
                }
            ),
            'tags' => array(
                'type' => 'array',
                'items' => array(
                    'type' => 'string'
                ),
                'sanitize_callback' => function($tags) {
                    return array_map('sanitize_text_field', (array) $tags);
                }
            ),
            'images' => array(
                'type' => 'array',
                'items' => array(
                    'type' => 'string',
                    'format' => 'uri'
                ),
                'description' => 'URLs or base64 encoded image data'
            )
        );
    }

    /**
     * Get a single post
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response|WP_Error Post data or error
     */
    public function get_post($request) {
        $post_id = $request['id'];
        $post = get_post($post_id);
        
        if (!$post || $post->post_status !== 'publish') {
            return new WP_Error(
                'post_not_found',
                'Post not found or not published',
                array('status' => 404)
            );
        }
        
        $data = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'date' => $post->post_date,
            'status' => $post->post_status,
            'author' => $post->post_author,
            'author_name' => get_the_author_meta('display_name', $post->post_author),
            'url' => get_permalink($post->ID),
            'categories' => wp_get_post_categories($post->ID, array('fields' => 'names')),
            'tags' => wp_get_post_tags($post->ID, array('fields' => 'names')),
            'featured_image' => get_the_post_thumbnail_url($post->ID, 'full')
        );
        
        return rest_ensure_response($data);
    }
    
    /**
     * Create content (alias for create_post with more flexibility)
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response|WP_Error New post data or error
     */
    public function create_content($request) {
        $params = $request->get_params();
        
        // Convert parameters to match WordPress API
        $post_data = array(
            'post_title' => isset($params['title']) ? sanitize_text_field($params['title']) : '',
            'post_content' => isset($params['content']) ? wp_kses_post($params['content']) : '',
            'post_excerpt' => isset($params['excerpt']) ? sanitize_text_field($params['excerpt']) : '',
            'post_status' => isset($params['status']) ? sanitize_text_field($params['status']) : 'publish',
            'post_author' => isset($params['author_id']) ? absint($params['author_id']) : get_current_user_id(),
            'post_type' => isset($params['post_type']) ? sanitize_text_field($params['post_type']) : 'post',
        );
        
        // Insert the post
        $post_id = wp_insert_post($post_data, true);
        
        if (is_wp_error($post_id)) {
            return $post_id;
        }
        
        // Set categories if provided
        if (isset($params['categories']) && is_array($params['categories'])) {
            wp_set_post_categories($post_id, array_map('absint', $params['categories']));
        }
        
        // Set tags if provided
        if (isset($params['tags']) && is_array($params['tags'])) {
            wp_set_post_tags($post_id, $params['tags']);
        }
        
        // Set featured image if provided
        if (isset($params['featured_image_url'])) {
            $this->set_featured_image_from_url($post_id, $params['featured_image_url']);
        }
        
        // Return the new post data
        $post = get_post($post_id);
        
        $data = array(
            'id' => $post->ID,
            'title' => $post->post_title,
            'content' => $post->post_content,
            'excerpt' => $post->post_excerpt,
            'date' => $post->post_date,
            'status' => $post->post_status,
            'author' => $post->post_author,
            'url' => get_permalink($post->ID),
            'message' => 'Content created successfully'
        );
        
        return rest_ensure_response($data);
    }
    
    /**
     * Update content
     *
     * @param WP_REST_Request $request The request object
     * @return WP_REST_Response|WP_Error Updated post data or error
     */
    public function update_content($request) {
        $post_id = $request['postId'];
        $post = get_post($post_id);
        
        if (!$post) {
            return new WP_Error(
                'post_not_found',
                'Post not found',
                array('status' => 404)
            );
        }
        
        $params = $request->get_params();
        
        // Convert parameters to match WordPress API
        $post_data = array(
            'ID' => $post_id,
        );
        
        if (isset($params['title'])) {
            $post_data['post_title'] = sanitize_text_field($params['title']);
        }
        
        if (isset($params['content'])) {
            $post_data['post_content'] = wp_kses_post($params['content']);
        }
        
        if (isset($params['excerpt'])) {
            $post_data['post_excerpt'] = sanitize_text_field($params['excerpt']);
        }
        
        if (isset($params['status'])) {
            $post_data['post_status'] = sanitize_text_field($params['status']);
        }
        
        if (isset($params['author_id'])) {
            $post_data['post_author'] = absint($params['author_id']);
        }
        
        // Update the post
        $result = wp_update_post($post_data, true);
        
        if (is_wp_error($result)) {
            return $result;
        }
        
        // Set categories if provided
        if (isset($params['categories']) && is_array($params['categories'])) {
            wp_set_post_categories($post_id, array_map('absint', $params['categories']));
        }
        
        // Set tags if provided
        if (isset($params['tags']) && is_array($params['tags'])) {
            wp_set_post_tags($post_id, $params['tags']);
        }
        
        // Set featured image if provided
        if (isset($params['featured_image_url'])) {
            $this->set_featured_image_from_url($post_id, $params['featured_image_url']);
        }
        
        // Return the updated post data
        $updated_post = get_post($post_id);
        
        $data = array(
            'id' => $updated_post->ID,
            'title' => $updated_post->post_title,
            'content' => $updated_post->post_content,
            'excerpt' => $updated_post->post_excerpt,
            'date' => $updated_post->post_date,
            'modified' => $updated_post->post_modified,
            'status' => $updated_post->post_status,
            'author' => $updated_post->post_author,
            'url' => get_permalink($updated_post->ID),
            'message' => 'Content updated successfully'
        );
        
        return rest_ensure_response($data);
    }
    
    /**
     * Helper function to set featured image from URL
     *
     * @param int $post_id Post ID
     * @param string $image_url Image URL
     * @return int|WP_Error Attachment ID or error
     */
    private function set_featured_image_from_url($post_id, $image_url) {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        
        // Download image
        $attachment_id = media_sideload_image($image_url, $post_id, null, 'id');
        
        if (!is_wp_error($attachment_id)) {
            // Set as featured image
            set_post_thumbnail($post_id, $attachment_id);
        }
        
        return $attachment_id;
    }
} 