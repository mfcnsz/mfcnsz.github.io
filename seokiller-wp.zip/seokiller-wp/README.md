# SEOKILLER WP

WordPress plugin to receive SEO-optimized content from SEOKILLER GPT via SEOKILLER ACTION bridge and publish it to the WordPress site.

## Description

SEOKILLER WP is a WordPress plugin that enables seamless integration between SEOKILLER GPT and your WordPress site. This plugin provides a secure API for SEOKILLER ACTION to create, update, and manage content on your WordPress website.

### Features

- **Secure API Authentication**: Secret key-based authentication system to secure all API requests
- **Content Management**: Create, update, and delete posts and pages
- **Media Handling**: Upload and manage featured images and media content
- **Category & Tag Support**: Assign categories and tags to content
- **WooCommerce Integration**: Create and manage product listings (when WooCommerce is active)
- **User-Friendly Admin Interface**: Easy key management and API documentation

## Installation

1. Upload the `seokiller-wp` directory to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the SEOKILLER WP menu in your admin dashboard to access your API key

## API Endpoints

All endpoints require the `X-SEOKILLER-API-KEY` header for authentication.

### Site Information

- `GET /wp-json/seokiller/v1/site-info` - Get general site information

### Content Management

- `GET /wp-json/seokiller/v1/categories` - Get all categories
- `GET /wp-json/seokiller/v1/authors` - Get all authors
- `GET /wp-json/seokiller/v1/posts` - Get posts list
- `POST /wp-json/seokiller/v1/posts` - Create a new post or page
- `PUT /wp-json/seokiller/v1/posts/{id}` - Update an existing post or page
- `DELETE /wp-json/seokiller/v1/posts/{id}` - Delete a post or page

### WooCommerce Endpoints (when WooCommerce is active)

- `GET /wp-json/seokiller/v1/products` - Get products list
- `POST /wp-json/seokiller/v1/products` - Create a new product
- `PUT /wp-json/seokiller/v1/products/{id}` - Update an existing product
- `DELETE /wp-json/seokiller/v1/products/{id}` - Delete a product

## Authentication

All API requests must include the following header:

```
X-SEOKILLER-API-KEY: your_secret_key_here
```

The secret key can be found in the SEOKILLER WP admin page in your WordPress dashboard.

## API Request Examples

### Create a new post

```
POST /wp-json/seokiller/v1/posts

Headers:
X-SEOKILLER-API-KEY: your_secret_key_here

Body:
{
  "title": "Sample Post Title",
  "content": "This is the content of the post.",
  "type": "post",
  "status": "publish",
  "author": 1,
  "categories": [1, 2],
  "tags": ["tag1", "tag2"],
  "featured_image": "https://example.com/image.jpg"
}
```

### Create a new product (requires WooCommerce)

```
POST /wp-json/seokiller/v1/products

Headers:
X-SEOKILLER-API-KEY: your_secret_key_here

Body:
{
  "name": "Sample Product",
  "description": "This is the product description.",
  "short_description": "Short product description.",
  "regular_price": "49.99",
  "sale_price": "39.99",
  "categories": [9, 10],
  "tags": ["product-tag1", "product-tag2"],
  "images": ["https://example.com/product-image.jpg"]
}
```

## Security Considerations

- Keep your API key secret and secure
- Regenerate your key if you suspect it has been compromised
- The plugin validates all incoming data to prevent security vulnerabilities

## Requirements

- WordPress 5.0 or higher
- PHP 7.2 or higher
- WooCommerce 3.0 or higher (for WooCommerce integration)

## License

GPL v2 or later 