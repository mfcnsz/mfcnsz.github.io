<?php
/**
 * Plugin Name: SEOKILLER WP
 * Plugin URI: https://seokiller.net/
 * Description: WordPress plugin to receive and process content from SEOKILLER GPT via SEOKILLER ACTION
 * Version: 1.0.1
 * Author: SEOKILLER
 * Author URI: https://seokiller.net/
 * License: GPL-2.0+
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

define('SEOKILLER_WP_VERSION', '1.0.1');
define('SEOKILLER_WP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SEOKILLER_WP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('SEOKILLER_WP_KEY_OPTION', 'seokiller_wp_secret_key');

/**
 * The core plugin class
 */
class SEOKILLER_WP {
    /**
     * The single instance of the class
     *
     * @var SEOKILLER_WP
     */
    private static $_instance = null;

    /**
     * Main SEOKILLER_WP Instance
     *
     * Ensures only one instance of SEOKILLER_WP is loaded or can be loaded.
     *
     * @return SEOKILLER_WP - Main instance
     */
    public static function get_instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        $this->load_dependencies();
        $this->init_hooks();
        
        // Ensure an API key exists
        $this->ensure_api_key_exists();
    }
    
    /**
     * Ensure API key exists on plugin initialization
     */
    private function ensure_api_key_exists() {
        $key = get_option(SEOKILLER_WP_KEY_OPTION, '');
        if (empty($key)) {
            $this->generate_secret_key();
        }
    }

    /**
     * Load the required dependencies
     */
    private function load_dependencies() {
        require_once SEOKILLER_WP_PLUGIN_DIR . 'includes/class-seokiller-wp-auth.php';
        require_once SEOKILLER_WP_PLUGIN_DIR . 'includes/class-seokiller-wp-api.php';
        require_once SEOKILLER_WP_PLUGIN_DIR . 'includes/class-seokiller-wp-content.php';
        require_once SEOKILLER_WP_PLUGIN_DIR . 'admin/class-seokiller-wp-admin.php';
        
        // Initialize admin
        new SEOKILLER_WP_Admin();
        
        // Load WooCommerce integration if WooCommerce is active
        if ($this->is_woocommerce_active()) {
            require_once SEOKILLER_WP_PLUGIN_DIR . 'includes/class-seokiller-wp-woocommerce.php';
        }
    }

    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Register activation hook
        register_activation_hook(__FILE__, array($this, 'activate'));
        
        // Register deactivation hook
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
        
        // Initialize REST API
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }

    /**
     * Plugin activation
     */
    public function activate() {
        // Generate initial secret key if not exists
        $key = get_option(SEOKILLER_WP_KEY_OPTION, '');
        if (empty($key)) {
            $this->generate_secret_key();
        }
    }

    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Cleanup if needed
    }

    /**
     * Generate a secure random string of specified length
     * 
     * @param int $length The length of the random string
     * @return string
     */
    private function generate_secure_random_string($length = 64) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_[]{}<>~`+=,.;:/?|';
        $str = '';
        
        if (function_exists('random_bytes')) {
            $bytes = random_bytes(ceil($length / 2));
            $str = substr(bin2hex($bytes), 0, $length);
        } elseif (function_exists('openssl_random_pseudo_bytes')) {
            $bytes = openssl_random_pseudo_bytes(ceil($length / 2));
            $str = substr(bin2hex($bytes), 0, $length);
        } else {
            // Fallback less secure method
            $max = strlen($chars) - 1;
            for ($i = 0; $i < $length; $i++) {
                $str .= $chars[mt_rand(0, $max)];
            }
        }
        
        return $str;
    }

    /**
     * Generate a new secret key
     * 
     * This method ensures a key is properly generated and stored
     */
    public function generate_secret_key() {
        // Delete existing key first to ensure clean state
        delete_option(SEOKILLER_WP_KEY_OPTION);
        
        // Generate secure key
        $key = $this->generate_secure_random_string(64);
        
        // Directly add the option first (no auto-loading)
        add_option(SEOKILLER_WP_KEY_OPTION, $key, '', 'no');
        
        // If adding failed, try updating
        if (get_option(SEOKILLER_WP_KEY_OPTION, '') !== $key) {
            update_option(SEOKILLER_WP_KEY_OPTION, $key);
        }
        
        // Final verification
        $stored_key = get_option(SEOKILLER_WP_KEY_OPTION, '');
        
        if ($stored_key !== $key) {
            // Log the error for debugging
            error_log('SEOKILLER WP: Failed to store API key in the database.');
            return false;
        }
        
        return $stored_key;
    }

    /**
     * Get the current secret key
     */
    public function get_secret_key() {
        $key = get_option(SEOKILLER_WP_KEY_OPTION, '');
        
        // If key is empty, try to generate one
        if (empty($key)) {
            $key = $this->generate_secret_key();
        }
        
        return $key;
    }

    /**
     * Check if WooCommerce is active
     */
    public function is_woocommerce_active() {
        return in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')));
    }

    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        $api = new SEOKILLER_WP_API();
        $api->register_routes();
    }
}

/**
 * Initialize the plugin
 */
function seokiller_wp_init() {
    return SEOKILLER_WP::get_instance();
}

// Start the plugin
add_action('plugins_loaded', 'seokiller_wp_init');

/**
 * Add debug API route for testing
 */
function seokiller_wp_debug_route() {
    register_rest_route('seokiller-wp/v1', '/test', array(
        'methods' => 'GET',
        'callback' => function() {
            return rest_ensure_response(array(
                'status' => 'ok',
                'message' => 'SEOKILLER WP REST API yüklendi ve çalışıyor.',
                'version' => SEOKILLER_WP_VERSION,
                'timestamp' => current_time('mysql')
            ));
        },
        'permission_callback' => '__return_true'
    ));
}

// Register debug endpoint (priority 1 to ensure it's registered early)
add_action('rest_api_init', 'seokiller_wp_debug_route', 1); 