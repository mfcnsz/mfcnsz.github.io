/**
 * SEOKILLER WP Admin JavaScript
 */
(function($) {
    'use strict';
    
    /**
     * Copy API key to clipboard
     */
    function copyApiKey() {
        const apiKeyField = document.getElementById('seokiller-wp-key');
        
        // Select the text
        apiKeyField.select();
        apiKeyField.setSelectionRange(0, 99999); // For mobile devices
        
        // Copy the text
        document.execCommand('copy');
        
        // Deselect the text
        apiKeyField.blur();
        
        // Show success message
        const copyButton = $('#seokiller-wp-copy-key');
        const originalText = copyButton.text();
        
        copyButton.text('Copied!');
        
        setTimeout(function() {
            copyButton.text(originalText);
        }, 2000);
    }
    
    /**
     * Regenerate API key
     */
    function regenerateApiKey() {
        if (!confirm('Are you sure you want to regenerate the API key? This will invalidate the current key and any applications using it will need to be updated.')) {
            return;
        }
        
        $.ajax({
            url: seokiller_wp_admin.ajax_url,
            type: 'POST',
            dataType: 'json', // Explicitly specify JSON dataType
            data: {
                action: 'seokiller_regenerate_key',
                nonce: seokiller_wp_admin.nonce
            },
            beforeSend: function() {
                $('#seokiller-wp-regenerate-key').prop('disabled', true).text('Regenerating...');
            },
            success: function(response) {
                console.log('AJAX Response:', response); // Debug için eklendi
                
                if (response && response.success && response.data && response.data.key) {
                    // Update the key field - check if key exists and is not empty
                    if (response.data.key.trim() !== '') {
                        $('#seokiller-wp-key').val(response.data.key);
                        
                        // Update the authentication example
                        $('pre').text('X-SEOKILLER-API-KEY: ' + response.data.key);
                        
                        // Show success message
                        const noticeContainer = $('.seokiller-wp-key-notice');
                        const originalHtml = noticeContainer.html();
                        
                        noticeContainer.html('<p class="description" style="color: #46b450;">API key regenerated successfully!</p>');
                        
                        setTimeout(function() {
                            noticeContainer.html(originalHtml);
                        }, 3000);
                    } else {
                        alert('Error: Generated API key is empty');
                    }
                } else {
                    const errorMsg = (response && response.data && response.data.message) ? 
                        response.data.message : 'Unknown error: Could not generate API key';
                    alert('Error: ' + errorMsg);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', xhr.responseText, status, error);
                alert('An error occurred while processing your request: ' + error);
            },
            complete: function() {
                $('#seokiller-wp-regenerate-key').prop('disabled', false).text('Regenerate API Key');
            }
        });
    }
    
    // Initialize when document is ready
    $(document).ready(function() {
        // Copy API key button
        $('#seokiller-wp-copy-key').on('click', copyApiKey);
        
        // Regenerate API key button
        $('#seokiller-wp-regenerate-key').on('click', regenerateApiKey);
        
        // Check if API key field is empty on page load
        const initialKey = $('#seokiller-wp-key').val();
        if (initialKey && initialKey.trim() === '') {
            console.log('Initial API key is empty, attempting to generate one...');
            // Optional: Auto-generate a key if the field is empty
            // regenerateApiKey();
        }
    });
    
})(jQuery); 