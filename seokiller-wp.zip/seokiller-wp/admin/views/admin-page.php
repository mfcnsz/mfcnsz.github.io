<div class="wrap">
    <h1>SEOKILLER WP</h1>
    <div class="notice notice-info">
        <p>
            <?php esc_html_e('This plugin allows SEOKILLER ACTION to create, update, and manage content on your WordPress site.', 'seokiller-wp'); ?>
        </p>
    </div>
    
    <div class="seokiller-wp-section">
        <h2><?php esc_html_e('API Key', 'seokiller-wp'); ?></h2>
        <p>
            <?php esc_html_e('The API key is used to authenticate requests from SEOKILLER ACTION. Keep it secure and do not share it with unauthorized parties.', 'seokiller-wp'); ?>
        </p>
        <div class="seokiller-wp-key-container">
            <label for="seokiller-wp-key"><?php esc_html_e('Your API Key:', 'seokiller-wp'); ?></label>
            <div class="seokiller-wp-key-display">
                <input type="text" id="seokiller-wp-key" readonly value="<?php echo esc_attr($secret_key); ?>">
                <button type="button" class="button button-secondary" id="seokiller-wp-copy-key">
                    <?php esc_html_e('Copy', 'seokiller-wp'); ?>
                </button>
            </div>
            <p>
                <button type="button" class="button button-primary" id="seokiller-wp-regenerate-key">
                    <?php esc_html_e('Regenerate API Key', 'seokiller-wp'); ?>
                </button>
            </p>
            <div class="seokiller-wp-key-notice">
                <p class="description">
                    <?php esc_html_e('Warning: Regenerating the API key will invalidate the current key. Any applications using the current key will need to be updated.', 'seokiller-wp'); ?>
                </p>
            </div>
        </div>
    </div>
    
    <div class="seokiller-wp-section">
        <h2><?php esc_html_e('API Endpoints', 'seokiller-wp'); ?></h2>
        <p>
            <?php esc_html_e('The following endpoints are available for SEOKILLER ACTION to interact with your WordPress site:', 'seokiller-wp'); ?>
        </p>
        <table class="widefat">
            <thead>
                <tr>
                    <th><?php esc_html_e('Endpoint', 'seokiller-wp'); ?></th>
                    <th><?php esc_html_e('Method', 'seokiller-wp'); ?></th>
                    <th><?php esc_html_e('Description', 'seokiller-wp'); ?></th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/site-info</code></td>
                    <td>GET</td>
                    <td><?php esc_html_e('Get general site information', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/categories</code></td>
                    <td>GET</td>
                    <td><?php esc_html_e('Get all categories', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/authors</code></td>
                    <td>GET</td>
                    <td><?php esc_html_e('Get all authors', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/posts</code></td>
                    <td>GET</td>
                    <td><?php esc_html_e('Get posts list', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/posts</code></td>
                    <td>POST</td>
                    <td><?php esc_html_e('Create a new post or page', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/create-content</code></td>
                    <td>POST</td>
                    <td><?php esc_html_e('Create content with more flexibility', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/posts/{id}</code></td>
                    <td>GET</td>
                    <td><?php esc_html_e('Get a specific post details', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/posts/{id}</code></td>
                    <td>PUT</td>
                    <td><?php esc_html_e('Update an existing post or page', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/update-content/{postId}</code></td>
                    <td>PUT</td>
                    <td><?php esc_html_e('Update content with more flexibility', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/posts/{id}</code></td>
                    <td>DELETE</td>
                    <td><?php esc_html_e('Delete a post or page', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/debug</code></td>
                    <td>GET</td>
                    <td><?php esc_html_e('Test API connection (no auth required)', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/test</code></td>
                    <td>GET</td>
                    <td><?php esc_html_e('Simple test endpoint (no auth required)', 'seokiller-wp'); ?></td>
                </tr>
                <?php if (seokiller_wp_init()->is_woocommerce_active()): ?>
                <tr>
                    <td colspan="3" class="seokiller-wp-section-title">
                        <strong><?php esc_html_e('WooCommerce Endpoints', 'seokiller-wp'); ?></strong>
                    </td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/products</code></td>
                    <td>GET</td>
                    <td><?php esc_html_e('Get products list', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/products</code></td>
                    <td>POST</td>
                    <td><?php esc_html_e('Create a new product', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/products/{id}</code></td>
                    <td>PUT</td>
                    <td><?php esc_html_e('Update an existing product', 'seokiller-wp'); ?></td>
                </tr>
                <tr>
                    <td><code>/wp-json/seokiller-wp/v1/products/{id}</code></td>
                    <td>DELETE</td>
                    <td><?php esc_html_e('Delete a product', 'seokiller-wp'); ?></td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <div class="seokiller-wp-section">
        <h2><?php esc_html_e('Authentication', 'seokiller-wp'); ?></h2>
        <p>
            <?php esc_html_e('All API requests must include one of the following headers:', 'seokiller-wp'); ?>
        </p>
        <pre>X-SEOKILLER-API-KEY: <?php echo esc_html($secret_key); ?></pre>
        <p><?php esc_html_e('or', 'seokiller-wp'); ?></p>
        <pre>X-SEOKILLER-SECRET: <?php echo esc_html($secret_key); ?></pre>
    </div>

    <div class="seokiller-wp-section">
        <h2><?php esc_html_e('API Test', 'seokiller-wp'); ?></h2>
        <p>
            <?php esc_html_e('Test your API is working correctly by visiting this URL:', 'seokiller-wp'); ?>
            <br>
            <a href="<?php echo esc_url(get_rest_url(null, 'seokiller-wp/v1/test')); ?>" target="_blank">
                <?php echo esc_html(get_rest_url(null, 'seokiller-wp/v1/test')); ?>
            </a>
        </p>
    </div>
</div> 