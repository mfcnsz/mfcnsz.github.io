<?php
/**
 * SEOKILLER WP Admin
 *
 * @package SEOKILLER_WP
 */

if (!defined('WPINC')) {
    die;
}

/**
 * Admin class
 */
class SEOKILLER_WP_Admin {
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'register_settings'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        
        // Handle Ajax request to regenerate key
        add_action('wp_ajax_seokiller_regenerate_key', array($this, 'ajax_regenerate_key'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_menu_page(
            'SEOKILLER WP',
            'SEOKILLER WP',
            'manage_options',
            'seokiller-wp',
            array($this, 'admin_page'),
            'dashicons-shield',
            99
        );
    }
    
    /**
     * Register settings
     */
    public function register_settings() {
        register_setting('seokiller_wp_settings', SEOKILLER_WP_KEY_OPTION);
    }
    
    /**
     * Enqueue scripts
     *
     * @param string $hook The current admin page
     */
    public function enqueue_scripts($hook) {
        if ('toplevel_page_seokiller-wp' !== $hook) {
            return;
        }
        
        wp_enqueue_script(
            'seokiller-wp-admin',
            SEOKILLER_WP_PLUGIN_URL . 'admin/js/admin.js',
            array('jquery'),
            SEOKILLER_WP_VERSION,
            true
        );
        
        wp_localize_script('seokiller-wp-admin', 'seokiller_wp_admin', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('seokiller_wp_admin_nonce'),
            'plugin_version' => SEOKILLER_WP_VERSION
        ));
        
        wp_enqueue_style(
            'seokiller-wp-admin',
            SEOKILLER_WP_PLUGIN_URL . 'admin/css/admin.css',
            array(),
            SEOKILLER_WP_VERSION
        );
    }
    
    /**
     * Admin page
     */
    public function admin_page() {
        // Get the secret key
        $secret_key = seokiller_wp_init()->get_secret_key();
        
        // If there's still no secret key, show error
        if (empty($secret_key)) {
            echo '<div class="notice notice-error"><p>Failed to generate API key. Please check your WordPress installation.</p></div>';
        }
        
        // Include admin page template
        include SEOKILLER_WP_PLUGIN_DIR . 'admin/views/admin-page.php';
    }
    
    /**
     * Ajax handler for regenerating the secret key
     */
    public function ajax_regenerate_key() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'seokiller_wp_admin_nonce')) {
            wp_send_json_error(array('message' => 'Security check failed.'));
            wp_die();
        }
        
        // Check if user has permission
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'You do not have permission to perform this action.'));
            wp_die();
        }
        
        try {
            // Directly use plugin instance to generate key
            $new_key = seokiller_wp_init()->generate_secret_key();
            
            if (empty($new_key)) {
                throw new Exception('Failed to generate or store API key. Please check your WordPress database permissions.');
            }
            
            // Verify the key was actually stored
            $stored_key = get_option(SEOKILLER_WP_KEY_OPTION, '');
            
            if (empty($stored_key) || $stored_key !== $new_key) {
                throw new Exception('API key verification failed. The key was not properly stored.');
            }
            
            wp_send_json_success(array(
                'message' => 'API key regenerated successfully.',
                'key' => $stored_key
            ));
        } catch (Exception $e) {
            error_log('SEOKILLER API Key Generation Error: ' . $e->getMessage());
            wp_send_json_error(array('message' => $e->getMessage()));
        }
        
        wp_die();
    }
} 